//
//  EdibleGuildPagingViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/19/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleGuildPagingViewController.h"
#import "AppDelegate.h"
#import "EdibleGuildViewController.h"

@implementation EdibleGuildPagingViewController

@synthesize app_delegate, current_page, pageControl, view_controllers_array, pagingScrollView;

#pragma mark Prompts Loading
//Views stuff

-(UIViewController *)createVC:(NSDictionary*)prompt posted:(NSString *)datePosted {
	
    EdibleGuildViewController *evc = [[EdibleGuildViewController alloc]
                                  initWithNibName:@"EdibleGuildViewController" 
                                  bundle:nil];
    //evc.dayMeasures = prompt;
    //evc.dateStr = datePosted;
    return evc;
	
}


#pragma mark - Paging

- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    // We don't want a "feedback loop" between the UIPageControl and the scroll delegate in
    // which a scroll event generated from the user hitting the page control triggers updates from
    // the delegate method. We use a boolean to disable the delegate logic when the page control is used.
    if (pageControlUsed)
    {				
        // do nothing - the scroll was initiated from the page control, not the user dragging
        return;
    }
	//take care of keyboard
    
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageWidth = pagingScrollView.frame.size.width;
    current_page = floor((pagingScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = current_page;
	
    // A possible optimization would be to unload the views+controllers which are no longer visible
}

// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

// At the end of scroll animation, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

- (IBAction)changePage:(id)sender
{
	//take care of kayboard
	current_page = pageControl.currentPage;
	
	// update the scroll view to the appropriate page
    CGRect frame = pagingScrollView.frame;
    frame.origin.x = frame.size.width * current_page;
    frame.origin.y = 0;
    [pagingScrollView scrollRectToVisible:frame animated:YES];
    
	// Set the boolean used when scrolls originate from the UIPageControl. See scrollViewDidScroll: above.
    pageControlUsed = YES;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString *plant = self.title;
    view_controllers_array = [[NSMutableArray alloc] init];
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *plistPath = [bundle pathForResource:@"SavedDataExample" ofType:@"plist"];
    
    NSDictionary *temporary_dictionary = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    NSDictionary *dataByDate = [temporary_dictionary valueForKey:plant];
    NSArray *allKeys = [dataByDate allKeys];
    UIViewController *uvc = [[UIViewController alloc] init];
    
    EdibleGuildViewController *dvc = [[EdibleGuildViewController alloc]
                                      initWithNibName:@"EdibleGuildViewController" 
                                      bundle:nil];
    [view_controllers_array addObject:dvc];
    NSMutableDictionary *xcurrent = [[NSMutableDictionary alloc]init];
    for (int i = 0; i < 8; i++) {
        xcurrent = [dataByDate valueForKey:[allKeys objectAtIndex:i]];
        NSString *datePosted = [allKeys objectAtIndex:i];
        uvc = [self createVC:xcurrent posted:datePosted];
        //NSLog(@" after create");
        [view_controllers_array addObject:uvc];
    }
    
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // a page is the width of the scroll view
    pagingScrollView.pagingEnabled = YES;
    pagingScrollView.contentSize = CGSizeMake(pagingScrollView.frame.size.width * [view_controllers_array count], 
                                              pagingScrollView.frame.size.height);
    pagingScrollView.showsHorizontalScrollIndicator = NO;
    pagingScrollView.showsVerticalScrollIndicator = NO;
    pagingScrollView.scrollsToTop = NO;
    pagingScrollView.delegate = self;
    pageControl.numberOfPages = [view_controllers_array count];
    pageControl.currentPage = 0;
    
    for (int i = 0; i < [view_controllers_array count]; i++) {
		
		UIViewController *uvc /*= [[UIViewController alloc]init]*/;
		uvc = [view_controllers_array objectAtIndex:i];
		// add the controller's view to the scroll view
		CGRect frame = pagingScrollView.frame;
		frame.origin.x = frame.size.width * i;
		frame.origin.y = 0;
		uvc.view.frame = frame;
		[pagingScrollView addSubview:uvc.view];
	}

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
