//
//  EdibleGuildMainPageViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/20/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleGuildMainPageViewController.h"
#import "EdibleGuildViewController.h"

#import "AppDelegate.h"



@implementation EdibleGuildMainPageViewController
@synthesize guildList, backgroundButton, percentCoveredSegControl, saveButton;
@synthesize numAnimalStepper, numAnimalField, app_delegate, table;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)backgroundButtonClose:(id)sender {
    //NSLog(@"background button pressed");
    //[self resignFirstResponder]; 
    [numAnimalField resignFirstResponder];
    numAnimalStepper.value = [numAnimalField.text doubleValue];
}

-(IBAction)saveButtonPressed:(id)sender {

    //NSLog(@"totally could save data right now... if we wanted to...");
    
    // save data for user_name, date_time, plant_name, percent_covered, num_species
    //[app_delegate.totalEdibleDataGathered addObjectsFromArray:app_delegate.guildArray]; 
    //app data for users
    NSMutableDictionary *thisPlantGuildInfo = [[NSMutableDictionary alloc] init];
    [thisPlantGuildInfo setValue:app_delegate.userNames forKey:@"user_name"];
    //NSLog(@"the users user name is %@, ", app_delegate.userNames);
    
    //app data for 
    [thisPlantGuildInfo setValue:app_delegate.plantAccession forKey:@"plant_accession"];
    //NSLog(@"the plant name is %@,", app_delegate.plantName);
    
    //app data for date and time
    [thisPlantGuildInfo setValue:[app_delegate.entryData valueForKey:@"date_time"]forKey:@"date_time"];
    //NSLog(@"the date and time is %@",[app_delegate.entryData valueForKey:@"date_time"]);
    
    //add data for num species
    [thisPlantGuildInfo setValue:[NSNumber numberWithDouble:numAnimalStepper.value] forKey:@"num_species"];
    //NSLog(@"the number of plants in mulched area is %@, ", numAnimalField);
    
    //app data for percent covered
    [thisPlantGuildInfo setValue:[NSNumber numberWithInt:[percentCoveredSegControl selectedSegmentIndex]] forKey:@"percent_covered"]; 
    //NSLog(@"the perecent_covered is %d, ",[percentCoveredSegControl selectedSegmentIndex]);
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *plistPath = [bundle pathForResource:@"EdibleEcoSys" ofType:@"plist"];
    
    NSDictionary *temporary_dictionary = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    //guildList = [[temporary_dictionary valueForKey:app_delegate.plantAccession] valueForKey:@"guild"];
    //NSLog(@"plant name is %@", app_delegate.plantAccession);
    //NSLog(@"current plant is %@", [temporary_dictionary valueForKey:app_delegate.plantAccession]);
    [thisPlantGuildInfo setValue:[[temporary_dictionary valueForKey:app_delegate.plantAccession] valueForKey:@"common_name"] forKey:@"plant_name"];
    [thisPlantGuildInfo setValue:app_delegate.guildArray forKey:@"species"];
    [app_delegate.totalEdibleGuildDataGathered addObject:thisPlantGuildInfo];
   // NSLog(@"saving guild info");

    
    //let the user know data was saved and they don't need to worry
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Success" message:@"Your data was saved successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    //can't pop unless viewWillDisapear has already been called or else data isn't saved
    [self.navigationController popViewControllerAnimated:YES]; 
}

#pragma mark - Stepper functions
-(IBAction) numAnimalStepperUpdate: (id)sender{
    //UIStepper *heightStepper = (UIStepper *)sender;
    numAnimalField.text = [NSString stringWithFormat:@"%d", (int)numAnimalStepper.value];
}

/*
-(IBAction)stemAnimalStepperUpdate:(id)sender{
    stemAnimalField.text = [NSString stringWithFormat:@"%d", (int) stemAnimalStepper.value];
}

-(IBAction)flowerAnimalStepperUpdate:(id)sender{
    flowerAnimalField.text = [NSString stringWithFormat:@"%d", (int) flowerAnimalStepper.value];
}
 */ 

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    //NSLog(@"view loaded");
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //app_delegate.guildArray = [[NSMutableArray alloc] init];
    NSDictionary *data = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EdibleEcoSys" ofType:@"plist"]];
    NSDictionary *guilds = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Guilds" ofType:@"plist"]];
    guildList = [guilds objectForKey:[[data objectForKey:app_delegate.plantAccession] objectForKey:@"guild"]];
    /*
    [self.stemAnimalField setDelegate:self];
    [self.stemAnimalField setReturnKeyType:UIReturnKeyDone];
    [self.stemAnimalField addTarget:self
                       action:@selector(textFieldFinished:)
             forControlEvents:UIControlEventEditingDidEndOnExit];
    [self.leafAnimalField setDelegate:self];
    [self.flowerAnimalField setDelegate:self];*/
    
    /*NSArray *allKeys = [dataByDate allKeys];
    UIViewController *uvc = [[UIViewController alloc] init];
    
    EdibleGuildViewController *dvc = [[EdibleGuildViewController alloc]
                                      initWithNibName:@"EdibleGuildViewController" 
                                      bundle:nil];
    [view_controllers_array addObject:dvc];
    NSMutableDictionary *xcurrent = [[NSMutableDictionary alloc]init];
    for (int i = 0; i < 8; i++) {
        xcurrent = [dataByDate valueForKey:[allKeys objectAtIndex:i]];
        NSString *datePosted = [allKeys objectAtIndex:i];
        uvc = [self createVC:xcurrent posted:datePosted];
        NSLog(@" after create");
        [view_controllers_array addObject:uvc];
     */
    }
    


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    //NSLog(@"view will appear");
    [self.navigationItem setHidesBackButton:YES];
    [self performSelector:@selector(resetCheckmarks) withObject:nil afterDelay:0.25];
    [super viewWillAppear:animated];
}

-(void) resetCheckmarks {
    NSLog(@"resetting checkmarks");
    [table reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

//contain data saving
- (void)viewWillDisappear:(BOOL)animated
{
        [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Understory species";
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [guildList count];;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.textLabel.text = [[guildList objectAtIndex: [indexPath row]] capitalizedString];
    // Configure the cell...
    //cell.textLabel.text = [[guildList objectAtIndex: [indexPath row]] capitalizedString];
    //NSLog(@"making cell for %@", cell.textLabel.text);
    //NSLog(@"guild array is %@", app_delegate.guildArray);
    for(int i = 0; i<[app_delegate.guildArray count]; i++) {
        NSString *currSpecies = [[app_delegate.guildArray objectAtIndex:i] objectForKey:@"species_name"];
        //NSLog(@"current species is %@",currSpecies);
        if ([cell.textLabel.text isEqualToString:currSpecies]) {
            NSLog(@"found the same species");
            //UITableViewCell *cell = [table cellForRowAtIndexPath:[NSIndexPath indexPathForRow:j inSection:1]];
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    return cell;
}


#pragma mark - Table view delegate


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    
     //EdibleGuildViewController *detailViewController = [[EdibleGuildViewController alloc] initWithNibName:@"EdibleGuildViewController" bundle:nil];
     // ...
    //detailViewController.title = [guildList objectAtIndex:[indexPath row]];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	
	if(cell.accessoryType != UITableViewCellAccessoryCheckmark)
		//cell.accessoryType = UITableViewCellAccessoryNone;//toggle check
	//else 
		cell.accessoryType = UITableViewCellAccessoryCheckmark;//check!
     // Pass the selected object to the new view controller.
     //[self.navigationController pushViewController:detailViewController animated:YES];
     [self performSegueWithIdentifier:@"guildPush" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSIndexPath *selectedIndexPath = [self.tableView indexPathForSelectedRow];
    //NSInteger rowNumber = selectedIndexPath.row;
    
    UIViewController *next = [segue destinationViewController];
    next.title = [guildList objectAtIndex:[selectedIndexPath row]];
    
}

@end
