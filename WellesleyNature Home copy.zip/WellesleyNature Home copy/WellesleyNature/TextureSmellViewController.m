//
//  TextureSmellViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "TextureSmellViewController.h"

@implementation TextureSmellViewController

@synthesize app_delegate;
@synthesize notesTextField, scrollViewForKeyboard;
@synthesize leafTextureAnswersSelected, leafSmellanswersSelected, floweranswersSelected;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark KeyboardStuff

- (void)resizeRestore {
	[notesTextField resignFirstResponder];
	[scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [notesTextField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", textField.text]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
	[scrollViewForKeyboard setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 120) animated:YES];	
}

- (IBAction) backgroundButton
{
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", text_field.text]];
	[notesTextField resignFirstResponder];
	[self resizeRestore];
}

#pragma mark - Data Collection

- (IBAction)scentSegmentControlChanged:(UISegmentedControl *)sender{
    
    switch (sender.selectedSegmentIndex) {
        case 0:
            [floweranswersSelected addObject:@"Unscented"];
            break;
        case 1:
            [floweranswersSelected addObject:@"Lightly Scented"];
            break;
        case 2:
            [floweranswersSelected addObject:@"Strongly Scented"];
            break;
        default:
            break;
    }
}

- (IBAction)sweetSpicyNuttySegmentControlChanged:(UISegmentedControl *)sender{

    switch (sender.selectedSegmentIndex) {
        case 0:
            [leafSmellanswersSelected addObject:@"Sweet"];
            break;
        case 1:
            [leafSmellanswersSelected addObject:@"Spicy"];
            break;
        case 2:
            [leafSmellanswersSelected addObject:@"Nutty"];
            break;
        default:
            break;
    }
}

- (IBAction)smoothSwitched:(UISwitch *)sender{
    [leafTextureAnswersSelected addObject:@"Smooth"];

}

- (IBAction)ridgesSwitch:(UISwitch *)sender{
    [leafTextureAnswersSelected addObject:@"Ridges"];

}

- (IBAction)bumpsSwitch:(UISwitch *)sender{
    [leafTextureAnswersSelected addObject:@"Bumps"];

}

- (IBAction)fuzzySwitch:(UISwitch *)sender{
    [leafTextureAnswersSelected addObject:@"Fuzzy"];

}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    floweranswersSelected = [[NSMutableArray alloc]init];
	leafTextureAnswersSelected = [[NSMutableArray alloc] init];
	leafSmellanswersSelected = [[NSMutableArray alloc] init];
    [notesTextField.delegate self];
}

-(void) viewWillDisappear:(BOOL)animated {

	[app_delegate.entryData setObject:leafTextureAnswersSelected forKey:@"leafTexture"];
	[app_delegate.entryData setObject:leafSmellanswersSelected forKey:@"leafSmell"];
	[app_delegate.entryData setObject:floweranswersSelected forKey:@"flowerSmell"];
    
    NSLog(@"%@", app_delegate.entryData);
    
	[super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
