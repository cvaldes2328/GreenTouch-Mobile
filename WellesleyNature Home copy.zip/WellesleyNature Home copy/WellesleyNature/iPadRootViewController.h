//
//  iPadRootViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 3/9/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;

@interface iPadRootViewController : UITableViewController{
    int *selected;
    NSArray *treeShrubArray;
    NSArray *guildArray;
    NSArray *guildNamesArray;
    
    UIImageView *plantImage;
    UIButton *saveButton; 
}

@property (nonatomic, retain) AppDelegate *app_delegate;
@property (nonatomic) int *selected;
@property (nonatomic, retain) NSArray *treeShrubArray;
@property (nonatomic, retain) NSArray *guildArray;
@property (nonatomic, retain) NSArray *guildNamesArray;

@property (nonatomic, retain) IBOutlet UIImageView *plantImage;
@property (nonatomic, retain) IBOutlet UIButton *saveButton;

@end
