//
//  ProductivityViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 2/27/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "ProductivityViewController.h"
#import "AppDelegate.h"

@implementation ProductivityViewController
@synthesize app_delegate, treeField, treeStepper, groundField, groundStepper, harvestField, harvestStepper, backgroundButton; 
@synthesize treeImageButton, groundImageButton, harvestImageButton; 
@synthesize scrollViewForKeyboard, picturesScrollView, viewPicturesLabel, pictures, answers; 
@synthesize lastMeasure, lastTree, lastGround, lastHarvest; 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}



#pragma mark - Stepper functions
-(IBAction) treeStepperUpdated: (id)sender{
    treeField.text = [NSString stringWithFormat:@"%d", (int)treeStepper.value];
}

-(IBAction) groundStepperUpdated: (id)sender{
    groundField.text = [NSString stringWithFormat:@"%d", (int)groundStepper.value];
}

-(IBAction) harvestStepperUpdated: (id)sender{
    harvestField.text = [NSString stringWithFormat:@"%d", (int)harvestStepper.value];
}


#pragma mark KeyboardStuff

- (void)resizeRestore {
	[treeField resignFirstResponder];
    [groundField resignFirstResponder];
    [harvestField resignFirstResponder];
	[scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"text field returning");
	[treeField resignFirstResponder];
    [groundField resignFirstResponder];
    [harvestField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	[app_delegate updateLog:[NSString stringWithFormat:@"%@: Typing in Productivity page", [NSDate date]]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
    NSLog(@"began editing");
	[scrollViewForKeyboard setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 150) animated:YES];	
}

-(IBAction)backgroundButtonClose:(id)sender {
    [treeField resignFirstResponder]; 
    [groundField resignFirstResponder];
    [harvestField resignFirstResponder];
    
    [treeStepper setValue:[treeField.text doubleValue]];
    [groundStepper setValue:[groundField.text doubleValue]];
    [harvestStepper setValue:[harvestField.text doubleValue]];
	[self resizeRestore];
}

-(IBAction)nextButtonPressed:(id)sender {
    [self viewWillDisappear:YES];
    [self.navigationController popViewControllerAnimated:YES];
    [app_delegate updateLog:[NSString stringWithFormat:@"%@: Next question in productivity", [NSDate date]]];
}

#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif  
        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
        NSLog(@"adding to scroll view");
		[viewPicturesLabel setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		[pictures addObject:image];
		UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
        //newView.frame = CGRectMake(45-40, 10, 40, 60);
		[self.picturesScrollView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
    
    
    -(IBAction) buttonPressed: (id)sender {
        //UIButton *button = (UIButton *)sender;
        NSLog(@"hit button for picture");
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        [app_delegate updateLog:[NSString stringWithFormat:@"%@: Taking picture in productivity", [NSDate date]]];
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        } else {
            return;
        }
        
        [self presentModalViewController:imagePicker animated:YES];
    }


#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    pictures = [[NSMutableArray alloc] init];
    
    if(app_delegate.lastMeasureDictionary){
        NSDictionary *accessionDictionary = [app_delegate.lastMeasureDictionary objectForKey:app_delegate.plantAccession]; 
        NSDictionary *animalsDictionary = [accessionDictionary objectForKey:@"fruit"];
        lastTree.text = [[animalsDictionary objectForKey:@"on_tree"] stringValue]; 
        lastGround.text = [[animalsDictionary objectForKey:@"on_ground"] stringValue]; 
        lastHarvest.text = [[animalsDictionary objectForKey:@"harvested"] stringValue]; 
    } else { //hide display
        lastMeasure.hidden = TRUE; 
        lastTree.hidden = TRUE;
        lastGround.hidden = TRUE;
        lastHarvest.hidden = TRUE;
    }
}

-(void) viewWillDisappear:(BOOL)animated {
    answers = [[NSMutableDictionary alloc] init];
    [answers setValue:[NSNumber numberWithInt:(int)treeStepper.value] forKey:@"on_tree"];
    [answers setValue:[NSNumber numberWithInt:(int)groundStepper.value] forKey:@"on_ground"];
    [answers setValue:[NSNumber numberWithInt:(int)harvestStepper.value] forKey:@"harvested"];
    [answers setValue:pictures forKey:@"images"];
    
    [app_delegate.entryData setObject:answers forKey:@"fruit"];
    
    NSLog(@"%@", app_delegate.entryData); 
    
    
    
    [super viewWillDisappear:animated];   
}
    
-(void) viewWillAppear:(BOOL)animated {
    [app_delegate updateLog:[NSString stringWithFormat:@"%@: Show productivity page", [NSDate date]]];    
    NSMutableDictionary *fruitDict = [app_delegate.entryData objectForKey:@"fruit"];
    if(fruitDict) {
        NSLog(@"had a dict, filling in old values");
        treeStepper.value = [[fruitDict objectForKey:@"on_tree"] doubleValue]; 
        groundStepper.value = [[fruitDict objectForKey:@"on_ground"] doubleValue]; 
        harvestStepper.value = [[fruitDict objectForKey:@"harvested"] doubleValue]; 

        pictures = [fruitDict objectForKey:@"images"];
        
        [treeField setText:[NSString stringWithFormat:@"%d", (int)treeStepper.value]];
        [groundField setText:[NSString stringWithFormat:@"%d", (int)groundStepper.value]];
        [harvestField setText:[NSString stringWithFormat:@"%d", (int)harvestStepper.value]];
    }
    [self.navigationItem setHidesBackButton:YES];
    [super viewWillAppear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
    


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
