//
//  EdiblePlantPicker.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/23/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdiblePlantPicker.h"
#import "AppDelegate.h"
#import <ZXingWidgetController.h>
#import <QRCodeReader.h>
#import "SBJson.h"
#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>
#import <SystemConfiguration/SCNetworkConnection.h>
#import "SBJsonParser.h"
//#import "ObjectiveFlickr.h"

@implementation EdiblePlantPicker
@synthesize plantNames, app_delegate/*, flickrRequest*/, responseData, scanButton;


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
/*
-(IBAction)buttonPressed:(id)sender {
    
    app_delegate.entryData = [[NSMutableDictionary alloc] init];
    [app_delegate.entryData setValue:@"TestPlant" forKey:@"plant_name"];
    [app_delegate.entryData setValue:app_delegate.userNames forKey:@"user_name"];
}
 */

-(IBAction) buttonPressed: (id) sender {
    
	ZXingWidgetController *widController = [[ZXingWidgetController alloc] 
											initWithDelegate:self 
											showCancel:YES 
											OneDMode:NO];
	QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
	NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];	
	widController.readers = readers;
	[self presentModalViewController:widController animated:YES];	
	
}
/*
- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	NSLog(@"Hi!");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inResponseDictionary);
    if (inRequest.sessionInfo == @"kGetAuthTokenStep") {
		[app_delegate setAndStoreFlickrAuthToken:[[inResponseDictionary valueForKeyPath:@"auth.token"] textContent]];
		NSLog(@"in if, did it braek?");
		NSString *temp = [inResponseDictionary valueForKeyPath:@"auth.user.username"];
		NSLog(@"%@", temp);
		//self.flickrUserName = temp;
	}
	else if (inRequest.sessionInfo == @"kCheckTokenStep") {
		NSLog(@"in else, did it braek?");
		//self.flickrUserName = [inResponseDictionary valueForKeyPath:@"auth.user.username"];
	}
    else if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//snapPictureDescriptionLabel.text = @"Setting properties...";
		
        //NSLog(@"Hi 2");
        NSLog(@"%@", inResponseDictionary);
        NSString *photoID = [[inResponseDictionary valueForKeyPath:@"photoid"] textContent];
		
        flickrRequest.sessionInfo = @"kSetImagePropertiesStep";
        [flickrRequest callAPIMethodWithPOST:@"flickr.photos.setMeta" arguments:[NSDictionary dictionaryWithObjectsAndKeys:photoID, @"photo_id", @"Snap and Run", @"title", @"Uploaded from my iPhone/iPod Touch", @"description", nil]];        		        
	}
    else if ([inRequest.sessionInfo isEqualToString: @"kSetImagePropertiesStep"]) {
		//[self updateUserInterface:nil];		
		//snapPictureDescriptionLabel.text = @"Done";
        
		[UIApplication sharedApplication].idleTimerDisabled = NO;		
        
    }
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didFailWithError:(NSError *)inError
{
	NSLog(@"Hi 3");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inError);
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Flickr problem" 
													message:@"Flickr is having technical difficulties, so your pictures were not uploaded.  All other information has been uploaded successfully." 
												   delegate:nil 
										  cancelButtonTitle:@"OK" 
										  otherButtonTitles:nil];
	[alert show];
	//[alert release];
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest imageUploadSentBytes:(NSUInteger)inSentBytes totalBytes:(NSUInteger)inTotalBytes
{
	if (inSentBytes == inTotalBytes) {
		//snapPictureDescriptionLabel.text = @"Waiting for Flickr...";
	}
	else {
		//snapPictureDescriptionLabel.text = [NSString stringWithFormat:@"%lu/%lu (KB)", inSentBytes / 1024, inTotalBytes / 1024];
	}
}
*/
- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller {
	[self dismissModalViewControllerAnimated:NO];
}

-(BOOL) connectedToNetwork
{
    
	//Create zero addy
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	
	//Recover reachability flags
	SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr*)&zeroAddress);
	SCNetworkReachabilityFlags flags;
	
	BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
	CFRelease(defaultRouteReachability);
	
	if (!didRetrieveFlags) {
		printf("Error. Could not recover network reachability flags\n");
		return 0;
	}
	
	BOOL isReachable = flags & kSCNetworkFlagsReachable;
	BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
	return (isReachable && !needsConnection) ? YES : NO;
}


/*
- (IBAction)authorizeAction
{	
	//authorizeButton.enabled = NO;
	//authorizeDescriptionLabel.text = @"Logging in...";
    
    NSURL *loginURL = [app_delegate.flickrContext loginURLFromFrobDictionary:nil requestedPermission:OFFlickrWritePermission];
    [[UIApplication sharedApplication] openURL:loginURL];
}
*/

-(IBAction)submit{
    //time to submit
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Data uploading!" message:@"Don't be concerned if the device freezes up; that's just the data" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
    [self performSegueWithIdentifier:@"startDataCollection" sender:self];
	if ([self connectedToNetwork]) {
		for (int i = 0; i<[app_delegate.totalEdibleTreeDataGathered count]; i++) {
			//creating the data we actually want to upload

			NSString *pleasepleaseplease = [[app_delegate.totalEdibleTreeDataGathered objectAtIndex:i] JSONRepresentation];
			NSString *paramDataString = [[[NSString stringWithFormat:@"entry=%@", pleasepleaseplease] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""];
			NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
			//NSLog(@"this is the log: %@", paramDataString);
			
			//connecting to the internet
			NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
			[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_new_phenology_tree"]];
			[request setHTTPMethod:@"POST"];
			[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
			[request setHTTPBody: paramData];
			
			NSURLResponse *urlResponse;	
			NSError *error;
			NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
			if(!data) {
				//NSLog(@"%@", [error localizedDescription]);
			}
			//NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
			//NSLog(@"made it to end of addLog");
			
		}
    
    //repeat, since we've got the guild data to upload also
    for(int i = 0; i<[app_delegate.totalEdibleGuildDataGathered count]; i++) {
        NSString *pleasepleaseplease = [[app_delegate.totalEdibleGuildDataGathered objectAtIndex:i] JSONRepresentation];
        NSString *paramDataString = [NSString stringWithFormat:@"entry=%@", pleasepleaseplease];
        NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
        //NSLog(@"this is the log: %@", paramDataString);
        
        //connecting to the internet
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_new_phenology_guild"]];
        [request setHTTPMethod:@"POST"];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
        [request setHTTPBody: paramData];
        
        NSURLResponse *urlResponse;	
        NSError *error;
        NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
        if(!data) {
            //NSLog(@"%@", [error localizedDescription]);
        }
        //NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"made it to end of adding a piece of guild data");
    
    }
		//next, flickr
		/*
		if ([app_delegate.flickrContext.authToken length]<1) {
			[self authorizeAction];
		}
		//NSString *authToken;
		
		NSLog(@"auth token is %@", app_delegate.flickrContext.authToken);
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:app_delegate.flickrContext];
		flickrRequest.delegate = self;
		flickrRequest.requestTimeoutInterval = 60.0;
		
		NSLog(@"delegate is %@", flickrRequest.delegate);
		NSLog(@"going to upload all pics");*/
        
        //app_delegate.totalEdibleTreeDataGathered = [[NSMutableArray alloc] init];
        //app_delegate.totalEdibleGuildDataGathered = [[NSMutableArray alloc] init];
		
	}
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)result {
	//NSLog(@"scanned result");
	//self.resultsToDisplay = result;
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *plistPath = [bundle pathForResource:@"EdibleEcoSys" ofType:@"plist"];
    
    NSDictionary *temporary_dictionary = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    
    NSString *prefix= [[temporary_dictionary valueForKey:result] valueForKey:@"common_name"];
    
    if (prefix) {
        app_delegate.entryData = [[NSMutableDictionary alloc] init];
        [app_delegate.entryData setValue:result forKey:@"plant_accession"];
        [app_delegate.entryData setValue:app_delegate.userNames forKey:@"user_name"];
        app_delegate.plantAccession = result;
        [self performSegueWithIdentifier:@"startDataCollection" sender:self];
		
	} else if([@"wellesleycollegebio108" isEqualToString:result]){
        [self submit];
        //open survey
        NSURL *url = [ [ NSURL alloc ] initWithString: @"https://docs.google.com/spreadsheet/viewform?pli=1&formkey=dHpYRE8wMUtEWFVPblZmU3ZKUm91cGc6MA#gid=0" ];
        [[UIApplication sharedApplication] openURL:url];	
        
    }
    else {
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" 
													   message:@"The ID you entered doesn't exist in our database. Please check your entry and try again!" 
													  delegate:nil 
											 cancelButtonTitle:@"OK" 
											 otherButtonTitles:nil];
		[alert show];
		
	}
	
	[self dismissModalViewControllerAnimated:NO];	
}


#pragma mark Connection Methods

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	//[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    NSLog(@"in didReceiveData");
    //[responseData appendData:data];
    //NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    //create dictionary from string
    //app_delegate.lastMeasureDictionary = [responseString JSONValue];
    
    //NSLog(@"%@",[app_delegate.lastMeasureDictionary objectForKey:@"CoAvG01"]);
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	//label.text = [NSString stringWithFormat:@"Connection failed: %@", [error description]];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    //get response string
	//NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    //create dictionary from string
    //app_delegate.lastMeasureDictionary = [responseString JSONValue];
    
    //NSLog(@"%@",[app_delegate.lastMeasureDictionary objectForKey:@"CoAvG01"]);
    

}



#pragma mark - View lifecycle

- (void)viewDidLoad
{
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if ([self connectedToNetwork]) {
        
        NSLog(@"connected to network, getting old data");
        responseData = [NSData data];
        NSString *requestURL = @"http://flowerpowerwebapp.appspot.com/get_recent"; 
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:requestURL]]; 

        NSLog(@"make connection");
        responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
        NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
        app_delegate.lastMeasureDictionary = [responseString JSONValue];
        NSLog(@"%@",[app_delegate.lastMeasureDictionary objectForKey:@"CoAvG01"]);
        
    }
    scanButton.hidden = FALSE; 
    
    //[app_delegate.lastMeasureDictionary count];
    
    [super viewDidLoad];
    
	
	/*app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate];
     avgHeight = [[AvgHeight alloc] initWithNibName:@"AvgHeight" bundle:nil]; 
     [app_delegate.navigationController pushViewController:avgHeight animated:YES]; 
     */

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];    

    /**
    ZXingWidgetController *widController = [[ZXingWidgetController alloc] 
											initWithDelegate:self 
											showCancel:YES 
											OneDMode:NO];
	QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
	NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];	
	widController.readers = readers;
	[self presentModalViewController:widController animated:YES];
     **/
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
