//
//  TextureSmellViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface TextureSmellViewController : UIViewController <UITextFieldDelegate>{
    AppDelegate *app_delegate;

    NSMutableArray *leafTextureAnswersSelected;
    NSMutableArray *leafSmellanswersSelected;
    NSMutableArray *floweranswersSelected;
    
    UITextField *notesTextField;
    UIScrollView *scrollViewForKeyboard;
    
}

@property (nonatomic, retain) AppDelegate *app_delegate;

@property (nonatomic, retain) NSMutableArray *leafTextureAnswersSelected;
@property (nonatomic, retain) NSMutableArray *leafSmellanswersSelected;
@property (nonatomic, retain) NSMutableArray *floweranswersSelected;

@property (nonatomic, retain) IBOutlet UITextField *notesTextField;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForKeyboard;


- (IBAction)backgroundButton;
- (IBAction)scentSegmentControlChanged:(UISegmentedControl *)sender;
- (IBAction)sweetSpicyNuttySegmentControlChanged:(UISegmentedControl *)sender;
- (IBAction)smoothSwitched:(UISwitch *)sender;
- (IBAction)ridgesSwitch:(UISwitch *)sender;
- (IBAction)bumpsSwitch:(UISwitch *)sender;
- (IBAction)fuzzySwitch:(UISwitch *)sender;

@end
