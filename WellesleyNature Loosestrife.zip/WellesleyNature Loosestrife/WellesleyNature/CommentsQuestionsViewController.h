//
//  CommentsQuestionsViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface CommentsQuestionsViewController : UIViewController <UITextFieldDelegate>{

    AppDelegate *app_delegate;

    UITextField *comments;
    UITextField *questions;
    UIScrollView *scrollViewForKeyboard;
}

@property (nonatomic, retain) AppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UITextField *comments;
@property (nonatomic, retain) IBOutlet UITextField *questions;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForKeyboard;

-(IBAction)keyboardButtonPresed:(id)sender;
- (IBAction) backgroundButton;

@end
