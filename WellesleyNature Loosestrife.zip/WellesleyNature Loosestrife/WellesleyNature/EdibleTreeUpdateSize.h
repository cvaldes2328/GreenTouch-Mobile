//
//  EdibleTreeUpdateSize.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/23/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;
@interface EdibleTreeUpdateSize : UIViewController <UITextFieldDelegate>{
    UITextField *heightField;
    UITextField *widthField;

    UIStepper *heightStepper;
    UIStepper *widthStepper;
    
    UIButton *backgroundButton;
    
    AppDelegate *app_delegate;
    
    UILabel *lastMeasure;
    UILabel *lastHeight;
    UILabel *lastWidth; 
}

@property (nonatomic, retain) IBOutlet UITextField *heightField;
@property (nonatomic, retain) IBOutlet UITextField *widthField;
@property (nonatomic, retain) IBOutlet UIStepper *heightStepper;
@property (nonatomic, retain) IBOutlet UIStepper *widthStepper;
@property (nonatomic, retain) IBOutlet UIButton *backgroundButton; 

@property (nonatomic, retain) AppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UILabel *lastMeasure;
@property (nonatomic, retain) IBOutlet UILabel *lastHeight;
@property (nonatomic, retain) IBOutlet UILabel *lastWidth; 

-(IBAction) heightStepperUpdated: (id)sender;
-(IBAction) widthStepperUpdated: (id)sender;
-(IBAction)backgroundButtonClose:(id)sender;

@end
