//
//  EdibleGuildViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/19/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleGuildViewController.h"
#import "AppDelegate.h"
#import "EdibleGuildMainPageViewController.h"

@implementation EdibleGuildViewController

@synthesize totalCoverTableView, occupationPercentTableView, contentScrollView, selected, totalCoverOptionsArray, occupationPercentOptionsArray, backgroundButton;
@synthesize healthSegControl, holesSegControl, spotsSegControl, browsedSegControl, otherSegControl; 
@synthesize leafAnimalField, leafAnimalStepper, stemAnimalField, stemAnimalStepper, flowerAnimalField, flowerAnimalStepper; 
@synthesize app_delegate, scientificLabel, plantImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    NSUInteger row = [indexPath row];
    
    if(tableView == totalCoverTableView)   {
        NSString *option = [totalCoverOptionsArray objectAtIndex:row]; 
        cell.textLabel.text = option;
    }else{
        NSString *option = [occupationPercentOptionsArray objectAtIndex:row]; 
        cell.textLabel.text = option;
    }    
    return cell;        
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Stepper method from hell

-(IBAction)stepperValueChanged:(id)sender {
    
}

#pragma mark - Stepper functions
-(IBAction) leafAnimalStepperUpdate: (id)sender{
    leafAnimalField.text = [NSString stringWithFormat:@"%d", (int)leafAnimalStepper.value];
}

 -(IBAction)stemAnimalStepperUpdate:(id)sender{
 stemAnimalField.text = [NSString stringWithFormat:@"%d", (int) stemAnimalStepper.value];
 }
 
 -(IBAction)flowerAnimalStepperUpdate:(id)sender{
 flowerAnimalField.text = [NSString stringWithFormat:@"%d", (int) flowerAnimalStepper.value];
 }

-(IBAction)backgroundButtonClose:(id)sender {
   // NSLog(@"background button pressed");
    [self resignFirstResponder]; 
    [leafAnimalField resignFirstResponder];
    [stemAnimalField resignFirstResponder];
    [flowerAnimalField resignFirstResponder];
    
    [leafAnimalStepper setValue:[leafAnimalField.text doubleValue]];
    [stemAnimalStepper setValue:[stemAnimalField.text doubleValue]];
    [flowerAnimalStepper setValue:[flowerAnimalField.text doubleValue]];
}

#pragma mark KeyboardStuff

- (void)resizeRestore {
	[leafAnimalField resignFirstResponder];
    [flowerAnimalField resignFirstResponder];
    [stemAnimalField resignFirstResponder];
	
    [contentScrollView setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //NSLog(@"text field returning");
	[leafAnimalField resignFirstResponder];
    [flowerAnimalField resignFirstResponder];
    [stemAnimalField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	[app_delegate updateLog:[NSString stringWithFormat:@"%@: Typed in own answer to Guild Animal evidence",[NSDate date]]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
    //NSLog(@"text field began editing");
	[contentScrollView setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 150) animated:YES];	
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//deselect row
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
   
    if(tableView == totalCoverTableView) {
        //NSLog(@"total cover");
        if(cell.accessoryType == UITableViewCellAccessoryCheckmark) { //unchecking 
            cell.accessoryType = UITableViewCellAccessoryNone;//toggle check
        } else { //if other check, uncheck it, and check new row
            for(int i = 0; i<[totalCoverTableView numberOfRowsInSection:0]; i++) {
                UITableViewCell *cell = [totalCoverTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
                if(cell.accessoryType == UITableViewCellAccessoryCheckmark) cell.accessoryType = UITableViewCellAccessoryNone; //if checked, uncheck
            }
            cell.accessoryType = UITableViewCellAccessoryCheckmark;//check!
        }
    } else { //must be occupationPercentTableView
        //NSLog(@"occupation");
        if(cell.accessoryType == UITableViewCellAccessoryCheckmark) { //unchecking 
            cell.accessoryType = UITableViewCellAccessoryNone;//toggle check
        } else { //if other check, uncheck it, and check new row
            for(int i = 0; i<[occupationPercentTableView numberOfRowsInSection:0]; i++) {
                UITableViewCell *cell = [occupationPercentTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
                if(cell.accessoryType == UITableViewCellAccessoryCheckmark) cell.accessoryType = UITableViewCellAccessoryNone; //if checked, uncheck
            }
            cell.accessoryType = UITableViewCellAccessoryCheckmark;//check!
        }
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    totalCoverOptionsArray = [[NSArray alloc] initWithObjects:@"still emerging", @"leaves open", @"flower buds", @"flowers open", @"fruits senescing", nil];
    
    occupationPercentOptionsArray = [[NSArray alloc] initWithObjects:@"0", @"10-25%", @"25-50%", @"50-75%", @"75-100%",nil];
    
    contentScrollView.contentSize = CGSizeMake(320, 1300);
    
        
    NSString *resourcePath = [[NSBundle mainBundle] resourcePath];
    NSString *pathForImageFile = [resourcePath stringByAppendingPathComponent:[[self.title stringByAppendingString:@".png"] lowercaseString]];
    NSData *imageData = [[NSData alloc] initWithContentsOfFile:pathForImageFile];
    //NSLog(@"%@",pathForImageFile);
    UIImage *image = [[UIImage alloc] initWithData:imageData];
    
    plantImage.image = image;    

}

-(void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    //NSLog(@"title is %@", self.title);
    for(int i = 0; i<[app_delegate.guildArray count]; i++) {
        if ([[[app_delegate.guildArray objectAtIndex:i] objectForKey:@"species_name"] isEqualToString:self.title]) { //it's a repeat
            //NSLog(@"Reloading Seg Controls");
            NSDictionary *dict = [app_delegate.guildArray objectAtIndex:i];

            [healthSegControl setSelectedSegmentIndex:[[dict objectForKey:@"health"] intValue]];
            NSDictionary *reloadDamage = [dict objectForKey:@"damage"];
            [holesSegControl setSelectedSegmentIndex:[[reloadDamage objectForKey:@"holes"] intValue]];
            [spotsSegControl setSelectedSegmentIndex:[[reloadDamage objectForKey:@"spots"] intValue]];
            [browsedSegControl setSelectedSegmentIndex:[[reloadDamage objectForKey:@"browsed"] intValue]];
            [otherSegControl setSelectedSegmentIndex:[[reloadDamage objectForKey:@"other"] intValue]];
            //reload animal data
            NSDictionary *reloadAnimals = [dict objectForKey:@"animals"];
            leafAnimalField.text = [[reloadAnimals objectForKey:@"leaf"] stringValue];
            stemAnimalField.text = [[reloadAnimals objectForKey:@"stem"] stringValue];
            flowerAnimalField.text = [[reloadAnimals objectForKey:@"flower"] stringValue];
            
            [leafAnimalStepper setValue:[leafAnimalField.text doubleValue]];
            [stemAnimalStepper setValue:[stemAnimalField.text doubleValue]];
            [flowerAnimalStepper setValue:[flowerAnimalField.text doubleValue]];
            //get rid of old data, so there aren't duplicates
            [app_delegate.guildArray removeObjectAtIndex:i];
            break;
        }
        
    }
    [self.navigationItem setHidesBackButton:YES];

}

-(void) viewWillDisappear:(BOOL)animated {

    //percent_understory
   // [occupationPercentTableView]
    
    //num_species
   // [totalCoverTableView]
    
    //get most advanced stage
    int totalCovered = -1;
    for(int i = 0; i<[totalCoverTableView numberOfRowsInSection:0]; i++) {
        UITableViewCell *cell = [totalCoverTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        
        if(cell.accessoryType == UITableViewCellAccessoryCheckmark) totalCovered = i;
    
    }
    
    //get percent occupied
    int percentOccupied = -1;
    for(int i = 0; i<[occupationPercentTableView numberOfRowsInSection:0]; i++) {
        UITableViewCell *cell = [occupationPercentTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        if(cell.accessoryType == UITableViewCellAccessoryCheckmark) percentOccupied = i;
    }
    //get health and damage data
    NSMutableDictionary *damageDictionary = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                    [NSNumber numberWithInt:[holesSegControl selectedSegmentIndex]], @"holes",
                                    [NSNumber numberWithInt:[spotsSegControl selectedSegmentIndex]], @"spots",
                                    [NSNumber numberWithInt:[browsedSegControl selectedSegmentIndex]], @"browsed",
                                    [NSNumber numberWithInt:[otherSegControl selectedSegmentIndex]], @"other",
                                    nil];
    
    //get animal data
    NSMutableDictionary *animalsDictionary = [[NSMutableDictionary alloc] init]; 
    [animalsDictionary setValue:[NSNumber numberWithInt:leafAnimalStepper.value] forKey:@"leaf"];
    [animalsDictionary setValue:[NSNumber numberWithInt:stemAnimalStepper.value] forKey:@"stem"];
    [animalsDictionary setValue:[NSNumber numberWithInt:flowerAnimalStepper.value] forKey:@"flower"];
    
    //accumulate all data
    NSMutableDictionary *guildPlantDictionary = [[NSMutableDictionary alloc] init];
    [guildPlantDictionary setValue:[app_delegate.entryData objectForKey:@"date_time"] forKey: @"date_time"];
    [guildPlantDictionary setValue: [NSNumber numberWithInt:[healthSegControl selectedSegmentIndex]] forKey: @"health"]; //works
    [guildPlantDictionary setValue: damageDictionary forKey: @"damage"]; //works
    [guildPlantDictionary setValue: [NSDictionary dictionaryWithDictionary:animalsDictionary] forKey: @"animals"]; //works
    [guildPlantDictionary setValue: self.title forKey: @"species_name"];
    [guildPlantDictionary setValue:[NSNumber numberWithInt:totalCovered] forKey:@"phenology"];
    [guildPlantDictionary setValue:[NSNumber numberWithInt:percentOccupied] forKey:@"percent_understory"];
    //NSLog(@"the guild dictionary has data is %@", guildPlantDictionary);      
    [app_delegate.guildArray addObject:guildPlantDictionary];; 
    
    [super viewWillDisappear:animated];
    
}

-(IBAction)saveButtonPressed:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Success" message:@"Your data was saved successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    //can't pop unless viewWillDisapear has already been called or else data isn't saved...true statement?
    //answer: yes, true statement, but viewWillDisappear will automatically be called!  Hooray for built-in events!
     [self.navigationController popViewControllerAnimated:YES]; 
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



@end
