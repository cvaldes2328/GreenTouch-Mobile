//
//  EdibleTreeMainPage.m
//  WellesleyNature
//
//  Created by HCI Lab on 2/17/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleTreeMainPage.h"
#import "AppDelegate.h"
@implementation EdibleTreeMainPage
@synthesize app_delegate, saveButton, nameLabel, plantNames, picture, picturePhenology,pictureHealth, pictureProductivity, pictureAnimals, sizeButton, pictureSize;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)saveButtonPressed:(id)sender{
    //first, change all the uiimages in entryData to strings
    NSMutableArray *imagesArray = [[app_delegate.entryData objectForKey:@"animals"] objectForKey:@"images"];
    for(int i = 0; i<[imagesArray count]; i++) {
        //NSLog(@"replacing animals");
        [imagesArray replaceObjectAtIndex:i withObject: [NSString stringWithFormat:@"%@", UIImageJPEGRepresentation([imagesArray objectAtIndex:i], 0.5f)]];
    }
    //NSLog(@"%@", imagesArray);
    imagesArray = [[app_delegate.entryData objectForKey:@"phenology"] objectForKey:@"images"];
    for(int i = 0; i<[imagesArray count]; i++) {
        //NSLog(@"replacing phenology");
        [imagesArray replaceObjectAtIndex:i withObject: [NSString stringWithFormat:@"%@", UIImageJPEGRepresentation([imagesArray objectAtIndex:i], 0.5f)]];
    }
    imagesArray = [[app_delegate.entryData objectForKey:@"fruit"] objectForKey:@"images"];
    for(int i = 0; i<[imagesArray count]; i++) {
        //NSLog(@"replacing productivity");
        [imagesArray replaceObjectAtIndex:i withObject: [NSString stringWithFormat:@"%@", UIImageJPEGRepresentation([imagesArray objectAtIndex:i], 0.5f)]];
    }
    imagesArray = [[app_delegate.entryData objectForKey:@"health"] objectForKey:@"images"];
    for(int i = 0; i<[imagesArray count]; i++) {
        //NSLog(@"replacing health");
        [imagesArray replaceObjectAtIndex:i withObject: [NSString stringWithFormat:@"%@", UIImageJPEGRepresentation([imagesArray objectAtIndex:i], 0.5f)]];
    }
    [app_delegate.totalEdibleTreeDataGathered addObject:app_delegate.entryData];
    app_delegate.entryData = nil;
    
    // Loosestrife Data
    //[app_delegate.totalEntries addObject:app_delegate.currentDataEntry];
    //app_delegate.currentDataEntry = nil; 
    NSLog(@"saved currentDataEntry in Edible Tree Main Page");
    
    
    //let the user know data was saved and they don't need to worry
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Success" message:@"Your data was saved successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];

    //saveButton.hidden = TRUE; 
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(IBAction)ActionButtonPressed:(UIButton*)sender{
    
    if([@"Productivity" isEqualToString:sender.titleLabel.text])
    {
        pictureProductivity.hidden = NO;
    } else if([@"Health" isEqualToString:sender.titleLabel.text])
    {
        pictureHealth.hidden = NO;
    } else if([@"Phenology" isEqualToString:sender.titleLabel.text])
    {
        picturePhenology.hidden = NO;
    } else if([@"Update Size" isEqualToString:sender.titleLabel.text])
    {
        pictureSize.hidden = NO;
    }else{
        pictureAnimals.hidden = NO;
    }
        
        
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [saveButton setEnabled:NO]; 
    NSLog(@"%@", [app_delegate.currentDataEntry objectForKey:@"plantNumber"]);
    if ([app_delegate.currentDataEntry objectForKey:@"plantNumber"]) {
        NSLog(@"Loosestrife");
        self.title = @"LOOSESTRIFE";
        picture.image = [UIImage imageNamed:@"purple_loosestrife.jpg"];
    } else {
        plantNames = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"names" ofType:@"plist"]];
        //[plantNames objectForKey:[app_delegate.entryData objectForKey:@"plant_accession"]]; 
        self.title = [app_delegate.entryData objectForKey:@"plant_name"];
        picture.image = [UIImage imageNamed:[app_delegate.plantAccession substringToIndex:[app_delegate.plantAccession length]-2]];
    }
    [self.navigationItem setHidesBackButton:YES];
    
    //if Kristina, show size button
    if ([app_delegate.userNames rangeOfString:@"Kristina Jones"].location != NSNotFound) {
        [sizeButton setHidden:NO];
    } else [sizeButton setHidden:YES];
    
    if([app_delegate.entryData objectForKey:@"animals"]) pictureAnimals.hidden = NO;
    if([app_delegate.entryData objectForKey:@"health"]) pictureHealth.hidden = NO;
    if([app_delegate.entryData objectForKey:@"phenology"]) picturePhenology.hidden = NO;
    if([app_delegate.entryData objectForKey:@"fruit"]) pictureProductivity.hidden = NO;

    [app_delegate updateLog:[NSString stringWithFormat:@"%@: Loaded main page", [NSDate date]]];
    [super viewDidLoad];
}


-(void) resetPictureStuff {
    if([app_delegate.entryData objectForKey:@"animals"]) pictureAnimals.hidden = NO;
    if([app_delegate.entryData objectForKey:@"health"]) pictureHealth.hidden = NO;
    if([app_delegate.entryData objectForKey:@"phenology"]) picturePhenology.hidden = NO;
    if([app_delegate.entryData objectForKey:@"fruit"]) pictureProductivity.hidden = NO;
    if (!(picturePhenology.hidden||pictureAnimals.hidden||pictureHealth.hidden||pictureProductivity.hidden)) {
        [saveButton setEnabled:YES];
    } else [saveButton setEnabled:NO];
}
-(void) viewWillAppear:(BOOL)animated {
    
    //try to check for the entry data info

    if (!(picturePhenology.hidden||pictureAnimals.hidden||pictureHealth.hidden||pictureProductivity.hidden)) {
        [saveButton setEnabled:YES];
    } else [saveButton setEnabled:NO];
    [app_delegate updateLog:[NSString stringWithFormat:@"%@: Main page view appeared", [NSDate date]]];
    [self performSelector:@selector(resetPictureStuff) withObject: nil afterDelay:0.25];
    [super viewWillAppear:animated];
    //enter condition to make save button appear
    //NSLog(@"the dictionary has data: %@", (app_delegate.entryData));
    
    }  

-(void) viewWillDisappear:(BOOL)animated {
    //[app_delegate.totalEdibleTreeDataGathered addObject:app_delegate.entryData];
    //app_delegate.entryData = nil;
    [super viewWillDisappear:animated];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
