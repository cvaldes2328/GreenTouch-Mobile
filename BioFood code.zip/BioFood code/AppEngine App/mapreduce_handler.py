from symbol import except_clause
import logging
import model

# Leaf Phenology 
LeafPhenologyCase0 = "bud dormant"
LeafPhenologyCase1 = "bud expanded"
LeafPhenologyCase2 = "leaf < 0.5cm long"
LeafPhenologyCase3 = "leaf between 0.5 and 1 cm"
LeafPhenologyCase4 = "leaf between 1 and 2cm"
LeafPhenologyCase5 = "leaf between 2 and 4 cm"
LeafPhenologyCase6 = "leaf > 4cm long"

# /* Flower Phenology */
FlowerPhenologyCase0 = "none"
FlowerPhenologyCase1 = "bud without color"
FlowerPhenologyCase2 = "bud with color"
FlowerPhenologyCase3 = "in bloom"
FlowerPhenologyCase4 = "post-bloom"

# /* Overall Phenology */
OverallPhenologyCase0 = "none"
OverallPhenologyCase1 = "beginning (<10% blooming)"
OverallPhenologyCase2 = "early (10-33%)"
OverallPhenologyCase3 = "peak (33-67%)"
OverallPhenologyCase4 = "late (few buds remaining)"
OverallPhenologyCase5 = "post-bloom"

class LeafConversionError(Exception):
    pass

class FlowerConversionError(Exception):
    pass

class OverallConversionError(Exception):
    pass

def leaf_str_to_int(leaf_str):
    if leaf_str == LeafPhenologyCase0:
        return 0
    elif leaf_str == LeafPhenologyCase1:
        return 1
    elif leaf_str == LeafPhenologyCase2:
        return 2
    elif leaf_str == LeafPhenologyCase3:
        return 3
    elif leaf_str == LeafPhenologyCase4:
        return 4
    elif leaf_str == LeafPhenologyCase5:
        return 5
    elif leaf_str == LeafPhenologyCase6:
        return 6
    else:
        raise LeafConversionError()
    
def flower_str_to_int(flower_str):
    logging.info("attempting to convert flower_str '%s'" % flower_str)
    if flower_str == FlowerPhenologyCase0:
        return 0
    elif flower_str == FlowerPhenologyCase1:
        return 1
    elif flower_str == FlowerPhenologyCase2:
        return 2
    elif flower_str == FlowerPhenologyCase3:
        return 3
    elif flower_str == FlowerPhenologyCase4:
        return 4
    else:
        raise FlowerConversionError()
    
def overall_str_to_int(overall_str):
    if overall_str == OverallPhenologyCase0:
        return 0
    elif overall_str == OverallPhenologyCase1:
        return 1
    elif overall_str == OverallPhenologyCase2:
        return 2
    elif overall_str == OverallPhenologyCase3:
        return 3
    elif overall_str == OverallPhenologyCase4:
        return 4
    elif overall_str == OverallPhenologyCase5:
        return 5
    else:
        raise OverallConversionError()

def make_phenology2(phenology):
    """ arg:     a phenologymodel instance
        returns: a phenologymodel2 instance which has not been put yet
    """
    
    flower_str = phenology.flower
    flower_int = flower_str_to_int(flower_str.lower())
    
    leaf_str = phenology.leaf
    leaf_int = leaf_str_to_int(leaf_str.lower())
    
    overall_str = phenology.overall
    overall_int = overall_str_to_int(overall_str.lower())
    
    return model.PhenologyModel2(flower = flower_int, leaf = leaf_int, overall = overall_int)

def make_animal_evidence2(animal_evidence, entry):
    return model.AnimalEvidenceModel2(entry = entry, description = animal_evidence.description, photo_url = animal_evidence.photo_url)

def from_entrymodel_to_entrymodel2(entry):
    phenology1 = entry.phenology
    if phenology1 is not None:
        try:
            phenology2 = make_phenology2(phenology1)
            phenology2.put()
        except LeafConversionError:
            logging.error("Unable to convert leaf phenology: " + str(entry))
            return
        except FlowerConversionError:
            logging.error("Unable to convert flower phenology: " + str(entry))
            return
        except OverallConversionError:
            logging.error("Unable to convert overall phenology: " + str(entry))
            return
    else:
        phenology2 = None
    
    entry = model.EntryModel2(user = entry.user,
                              common_name = entry.common_name.lower(),
                              datetime = entry.datetime,
                              weather = entry.weather,
                              photo_url = entry.photo_url,  
                              color = entry.color,
                              phenology = phenology2,
                              sketches = entry.sketches,
                              leaf_texture = entry.leaf_texture,
                              leaf_smell = entry.leaf_smell,
                              flower_smell = entry.flower_smell,
                              comments = entry.comments,
                              questions = entry.comments,
                              location = entry.location)
    entry.put()
    
    for animal_evidence1 in entry.animal_evidence:
        animal_evidence2 = make_animal_evidence2(animal_evidence1, entry)
        animal_evidence2.put()
    logging.info("Successfully converted data to entry2: " + str(entry))
    