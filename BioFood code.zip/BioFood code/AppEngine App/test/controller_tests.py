import unittest, datetime
import model
from controller import EntryDataParser

class TestEntryDataParser(unittest.TestCase):
        
    def setUp(self):
        self.color = model.ColorModel(flower = 0, stem = 0, leaf = 0)
        self.color.put()
        
        self.phenology = model.PhenologyModel(leaf = "", flower = "", overall = "")
        self.phenology.put()
        
        self.entry = model.EntryModel(user = "foo", 
                                 common_name = "foo", 
                                 datetime = datetime.datetime.now(),
                                 color = self.color,
                                 phenology = self.phenology)
        self.parser = EntryDataParser()
    
    def test_create_color(self):
        
        flower = 0x010101
        leaf = 0x111111
        stem = 0x444444
        
        color = self.parser.create_color(flower = flower, leaf = leaf, stem = stem)
        self.assertEqual(color.flower, flower)
        self.assertEqual(color.leaf, leaf)
        self.assertEqual(color.stem, stem)
        
    def test_create_phenology(self):
       
        leaf = "leaf ph"
        flower = "flower ph"
        overall = "overall ph"
        
        color = self.parser.create_phenology(leaf = leaf, flower = flower, overall = overall)
        self.assertEqual(color.flower, flower)
        self.assertEqual(color.leaf, leaf)
        self.assertEqual(color.overall, overall)
        
    def test_create_entry(self):
        user = "0"
        common_name = "1"
        weather = "2"
        photo_url = "3"
        color = self.color
        phenology = self.phenology
        sketches = "4"
        leaf_texture = ["", ""]
        leaf_smell = ["", ""]
        flower_smell = [""]
        comments = "8"
        questions = "9"
        location = "10"
        
        entry = self.parser.create_entry(user = user,
                                         common_name = common_name,
                                         weather = weather,
                                         photo_url = photo_url,
                                         color = color,
                                         phenology = phenology,
                                         sketches = sketches,
                                         leaf_texture = leaf_texture,
                                         leaf_smell = leaf_smell,
                                         flower_smell = flower_smell,
                                         comments = comments,
                                         questions = questions,
                                         location = location)
                

        

    


