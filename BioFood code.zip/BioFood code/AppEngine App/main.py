from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from controller import MainPageController, NewEntryController, PrintAllEntriesController, \
                        SetDeviceCommonNameMappingController, PrintDeviceCommonNameMappingController, \
                        GetCommonNameFromDeviceIdController, GetAllPlantEntriesController, \
                        PrintAllLooseStrifeEntries, GetAllLoosestrifeEntriesController, \
                        GetNewLoosestrifeEntriesController
                        
from loosestrife_controller import LoosestrifeController, NewLoosestrifeController, NewLoosestrifeWithDateController
from new_phenology_controller import NewPhenologyTreeController, NewPhenologyGuildController, \
                              GetNewPhenologyEntriesController, PrintNewPhenologyTreeCSV, PrintNewPhenologyGuildCSV, \
                              GetAnImage, GetRecent, GetCount
from beast_controller import PutBeastData, GetBeastData
#this is .your main spec url and it runs the "class" you associate with it

application = webapp.WSGIApplication(
                                     [('/put_entry', NewEntryController),
                                      ('/print_entries', PrintAllEntriesController),
                                      ('/set_device_mapping', SetDeviceCommonNameMappingController),
                                      ('/print_mappings', PrintDeviceCommonNameMappingController),
                                      ('/get_common_name', GetCommonNameFromDeviceIdController),
                                      ('/get_plant_entries', GetAllPlantEntriesController),
                                      ('/put_loosestrife_entry', LoosestrifeController),
                                      ('/put_new_loosestrife_entry', NewLoosestrifeController),
                                      ('/put_new_loosestrife_entry_date', NewLoosestrifeWithDateController),
                                      ('/print_loosestrife_entries', PrintAllLooseStrifeEntries),
                                      ('/get_new_loosestrife_entries', GetNewLoosestrifeEntriesController),
                                      ('/', MainPageController),
                                      ('/get_loosestrife_entries', GetAllLoosestrifeEntriesController),
                                      ('/put_new_phenology_tree', NewPhenologyTreeController),
                                      ('/put_new_phenology_guild', NewPhenologyGuildController),
                                      ('/get_new_phenology', GetNewPhenologyEntriesController),
                                      ('/print_new_phenology_tree_csv', PrintNewPhenologyTreeCSV),
                                      ('/print_new_phenology_guild_csv', PrintNewPhenologyGuildCSV),
                                      ('/get_image', GetAnImage),
                                      ('/put_new_beast_data', PutBeastData),
                                      ('/get_recent', GetRecent),
                                      ('/get_count', GetCount),
                                      ('/get_beast_data',GetBeastData) ])
                                      

def main():
    run_wsgi_app(application)

if __name__ == "__main__":
    main()