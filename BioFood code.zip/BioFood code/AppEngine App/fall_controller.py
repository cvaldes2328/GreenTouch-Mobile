from controller import EntryDataParser
import fall_model

OVERALL = "overall"
COLOR = "color"
FALLEN = "fallen"
FALLPHENOLOGY = "fallPhenology"

class FallEntryDataParser(EntryDataParser):
    
    def finished_parse_and_put_entry_str(self, entry_str, entry_instance):
        fall_phenology_dict = entry_str[FALLPHENOLOGY]
        overall = fall_phenology_dict[OVERALL]
        fallen = fall_phenology_dict[FALLEN]
        color = fall_phenology_dict[COLOR]
        fall_phenology = fall_model.FallPhenologyModel(overall = overall, fallen = fallen, color = color)
        
        entry_instance.fall_phenology = fall_phenology
        entry_instance.put()
    
    def parse_and_put_fall_entry_str(self, entry_str):
        super(FallEntryDataParser, self).parse_and_put_entry_str(self, entry_str, entry_class = fall_model.FallEntryModel)
        