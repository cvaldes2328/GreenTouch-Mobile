from google.appengine.ext import db
from model import EntryModel2

class FallPhenologyModel(db.Model):
    overall = db.IntegerProperty()  
    color = db.IntegerProperty()
    fallen = db.IntegerProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("overall_phenology = " + str(self.flower))
        str_buf.append("color = " + str(self.color))
        str_buf.append("fallen = " + str(self.fallen))  
        return "(" + ", ".join(str_buf) + ")"

class FallEntryModel(EntryModel2):
    fall_phenology = FallPhenologyModel()
    
    def __str__(self):
        parent_str = super(FallEntryModel, self).__str__(self)
        parent_str += "/n"
        parent_str += "Fall Phenology = "
        parent_str += str(self.fall_phenology)
        