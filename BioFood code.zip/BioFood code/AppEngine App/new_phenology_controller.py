'''Created by Michelle in January 2012
Based on the LoosestrifeController class'''
from google.appengine.ext import webapp
import logging, sys, datetime
from django.utils import simplejson
#from loosestrife_model import LooseStrifeEntryModel
from new_phenology_model import NewPhenologyTreeEntryModel, NewPhenologyGuildEntryModel, PhenologyModel3, \
HealthModel, AnimalModel, ProductivityModel, GuildDamage, GuildSpeciesModel, GuildAnimals, PhenologyImage, HealthImage, AnimalImage, ProductivityImage
from controller import AppRequestHandler
from google.appengine.ext import db

ENTRY_POST_KEY = "entry"
BAD_REQUEST = 400

class PrintNewPhenologyTreeCSV (AppRequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/csv'
        self.response.headers['Content-Disposition'] = 'attachment;filename=PhenologyTreeData.csv'
        
        phenologies = NewPhenologyTreeEntryModel.all()
        response_buf = []
        
        header_buf = []
        header_buf.append("Id")
        header_buf.append("Date")
        header_buf.append("Plant Name")
        header_buf.append("Plant Accession")
        header_buf.append("User Name")
        header_buf.append("Height")
        header_buf.append("Widest Width")
        header_buf.append("Overall Phenology")
        header_buf.append("Leaf Phenology")
        header_buf.append("Fruit Phenology")
        header_buf.append("Flower Phenology")
        header_buf.append("Overall Health")
        header_buf.append("Stem Tip Damage")
        header_buf.append("Bark Damage")
        header_buf.append("Leaf Damage")
        header_buf.append("Leaf Discoloration")
        header_buf.append("Flower Damage")
        header_buf.append("Fruit Damage")
        header_buf.append("Animals on Leaf")
        header_buf.append("Animals on Stem")
        header_buf.append("Animals on Flower")
        header_buf.append("Animals on Fruit")
        header_buf.append("Fruit on Tree")
        header_buf.append("Fruit on Ground")
        header_buf.append("Fruit Harvested")
        header_buf.append("Total Fruit")
        response_buf.append(", ".join(header_buf))
        
        for phenology in phenologies:
            phenology_buf = []
            phenology_buf.append(str(phenology.key().id()))
            phenology_buf.append(str(phenology.date_time))
            phenology_buf.append(str(phenology.plant_name))
            phenology_buf.append(str(phenology.plant_accession))
            phenology_buf.append(str(phenology.user_name))
            phenology_buf.append(str(phenology.height))
            phenology_buf.append(str(phenology.widest_width))
            phenology_buf.append(str(phenology.phenology.overall))
            phenology_buf.append(str(phenology.phenology.leaf))
            phenology_buf.append(str(phenology.phenology.fruit))
            phenology_buf.append(str(phenology.phenology.flower))
            phenology_buf.append(str(phenology.health.overall))
            phenology_buf.append(str(phenology.health.stem_tip))
            phenology_buf.append(str(phenology.health.bark))
            phenology_buf.append(str(phenology.health.leaf_damage))
            phenology_buf.append(str(phenology.health.leaf_discoloration))
            phenology_buf.append(str(phenology.health.flower))
            phenology_buf.append(str(phenology.health.fruit))
            phenology_buf.append(str(phenology.animals.leaf))
            phenology_buf.append(str(phenology.animals.stem))
            phenology_buf.append(str(phenology.animals.flower))
            phenology_buf.append(str(phenology.animals.fruit))
            phenology_buf.append(str(phenology.fruit.on_tree))
            phenology_buf.append(str(phenology.fruit.on_ground))
            phenology_buf.append(str(phenology.fruit.harvested))
            phenology_buf.append(str(phenology.fruit.harvested + phenology.fruit.on_ground + phenology.fruit.on_tree))
            response_buf.append(", ".join(phenology_buf))
            
        self.response.out.write("\n".join(response_buf))
        
        
class PrintNewPhenologyGuildCSV (AppRequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/csv'
        self.response.headers['Content-Disposition'] = 'attachment;filename=PhenologyGuildData.csv'
        
        guilds = GuildSpeciesModel.all()
        response_buf = []
        header_buf = []
        header_buf.append("Understory Species")
        header_buf.append("Date")
        header_buf.append("Woody Species")
        header_buf.append("Woody Accession")
        header_buf.append("User Name")
        header_buf.append("Woody % Cover")
        header_buf.append("Woody # Species")
        header_buf.append("Phenology")
        header_buf.append("% of Understory")
        header_buf.append("Health")
        header_buf.append("Holes")
        header_buf.append("Spots")
        header_buf.append("Browsed")
        header_buf.append("Other Damage")
        header_buf.append("Leaf Animals")
        header_buf.append("Stem Animals")
        header_buf.append("Flower Animals")
        response_buf.append(", ".join(header_buf))
        
        for guild in guilds:
            guild_buf = []
            guild_buf.append(str(guild.species_name))
            guild_buf.append(str(guild.guild.date_time))
            guild_buf.append(str(guild.guild.plant_name))
            guild_buf.append(str(guild.guild.plant_accession))
            guild_buf.append(str(guild.guild.user_name))
            guild_buf.append(str(guild.guild.percent_cover))
            guild_buf.append(str(guild.guild.num_species))
            guild_buf.append(str(guild.phenology))
            guild_buf.append(str(guild.percent_understory))
            guild_buf.append(str(guild.health))
            guild_buf.append(str(guild.damage.holes))
            guild_buf.append(str(guild.damage.spots))
            guild_buf.append(str(guild.damage.browsed))
            guild_buf.append(str(guild.damage.other))
            guild_buf.append(str(guild.animals.leaf))
            guild_buf.append(str(guild.animals.stem))
            guild_buf.append(str(guild.animals.flower))
            response_buf.append(", ".join(guild_buf))
            
        self.response.out.write("\n".join(response_buf))

class PrintNewPhenologyGuildCSVBySpecies (AppRequestHandler):
    def get(self):
        
        if not self.validate_request_arguments("plant_name"):
            self.error(BAD_REQUEST)
            return
        plant_name = self.request.get("plant_name")
        self.response.headers['Content-Type'] = 'text/csv'
        self.response.headers['Content-Disposition'] = 'attachment;filename=PhenologyGuildData_'+plant_name+'.csv'
        
        guilds = GuildSpeciesModel.all().filter("species_name =", plant_name)
        response_buf = []
        header_buf = []
        header_buf.append("Understory Species")
        header_buf.append("Date")
        header_buf.append("Woody Species")
        header_buf.append("Woody Accession")
        header_buf.append("User Name")
        header_buf.append("Woody % Cover")
        header_buf.append("Woody # Species")
        header_buf.append("Phenology")
        header_buf.append("% of Understory")
        header_buf.append("Health")
        header_buf.append("Holes")
        header_buf.append("Spots")
        header_buf.append("Browsed")
        header_buf.append("Other Damage")
        header_buf.append("Leaf Animals")
        header_buf.append("Stem Animals")
        header_buf.append("Flower Animals")
        response_buf.append(", ".join(header_buf))
        
        for guild in guilds:
            guild_buf = []
            guild_buf.append(str(guild.species_name))
            guild_buf.append(str(guild.guild.date_time))
            guild_buf.append(str(guild.guild.plant_name))
            guild_buf.append(str(guild.guild.plant_accession))
            guild_buf.append(str(guild.guild.user_name))
            guild_buf.append(str(guild.guild.percent_cover))
            guild_buf.append(str(guild.guild.num_species))
            guild_buf.append(str(guild.phenology))
            guild_buf.append(str(guild.percent_understory))
            guild_buf.append(str(guild.health))
            guild_buf.append(str(guild.damage.holes))
            guild_buf.append(str(guild.damage.spots))
            guild_buf.append(str(guild.damage.browsed))
            guild_buf.append(str(guild.damage.other))
            guild_buf.append(str(guild.animals.leaf))
            guild_buf.append(str(guild.animals.stem))
            guild_buf.append(str(guild.animals.flower))
            response_buf.append(", ".join(guild_buf))
            
        self.response.out.write("\n".join(response_buf))
class NewPhenologyTreeController(webapp.RequestHandler):
    
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)

    def post(self):
        json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            logging.debug(json_str)
            entry_dict = simplejson.loads(json_str)

            model = NewPhenologyTreeEntryModel()
            model.user_name = entry_dict["user_name"]
            try:
                month = entry_dict["month"]
                model.date_time = datetime.datetime(entry_dict["year"], month, entry_dict["day"])
            except KeyError:
                model.date_time = datetime.datetime.now()   
            model.plant_name = entry_dict["plant_name"]
            model.plant_accession = entry_dict["plant_accession"]
            try:
                model.height = entry_dict["height"]
                model.widest_width = entry_dict["widest_width"]
            except KeyError:
                model.height = -1
                model.widest_width = -1
            #widest_width = db.IntegerProperty()
            phenodict = entry_dict["phenology"]
            magicphenology = PhenologyModel3()
            #model.phenology = PhenologyModel3()
            magicphenology.leaf = phenodict["leaf"]
            magicphenology.flower = phenodict["flower"]
            magicphenology.fruit = phenodict["fruit"]
            magicphenology.overall = phenodict["overall"]
            magicphenology.comment = phenodict["comment"]
            magicphenology.put()
            images = phenodict["images"]
            for image in images:
                newImage = PhenologyImage(phenology = magicphenology, image = db.Blob(str(image)))
                newImage.put()
            model.phenology = magicphenology
            
            magichealth = HealthModel()
            healthdict = entry_dict["health"]
            magichealth.overall = healthdict["overall"]
            magichealth.stem_tip = healthdict["stem_tip"]
            magichealth.bark = healthdict["bark"]
            magichealth.leaf_damage = healthdict["leaf_damage"]
            magichealth.leaf_discoloration = healthdict["leaf_discoloration"]
            magichealth.flower = healthdict["flower"]
            magichealth.fruit = healthdict["fruit"]
            magichealth.comment = healthdict["comment"]
            magichealth.put()
            images = healthdict["images"]
            for image in images:
                newImage = HealthImage(health = magichealth, image = db.Blob(str(image)))
                newImage.put()
            model.health = magichealth
            
            magicanimals = AnimalModel()
            animalsdict = entry_dict["animals"]
            magicanimals.leaf = animalsdict["leaf"]
            magicanimals.stem = animalsdict["stem"]
            magicanimals.flower = animalsdict["flower"]
            magicanimals.fruit = animalsdict["fruit"]
            images = animalsdict["images"]
            magicanimals.comment = animalsdict["comment"]
            for image in images:
                newImage = AnimalImage(animal = magicanimals, image = db.Blob(str(image)))
                newImage.put()
            magicanimals.put()
            model.animals = magicanimals
            
            magicfruit = ProductivityModel()
            fruitdict = entry_dict["fruit"]
            magicfruit.on_ground = fruitdict["on_ground"]
            magicfruit.on_tree = fruitdict["on_tree"]
            magicfruit.harvested = fruitdict["harvested"]
            images = fruitdict['images']
            magicfruit.comment = fruitdict["comment"]
            for image in images:
                newImage = ProductivityImage(productivity = magicfruit, image = db.Blob(str(image)))
                newImage.put()
            magicfruit.put()
            model.fruit = magicfruit
            
            model.put()
            
            logging.info("Added NewPhenology tree entry: %s" % str(model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return
        
class NewPhenologyGuildController(webapp.RequestHandler):
    
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def parseSpecies(self, model, speciesList):
        for species in speciesList:
            currSpecies = GuildSpeciesModel(guild=model)
            currSpecies.species_name = species["species_name"]
            currSpecies.phenology = species["phenology"]
            currSpecies.percent_understory = species["percent_understory"]
            currSpecies.health = species["health"]
            damagedict = species["damage"]
            guildDamage = GuildDamage(holes = damagedict["holes"], spots = damagedict["spots"], browsed = damagedict["browsed"], other = damagedict["other"])
            guildDamage.put()
            currSpecies.damage = guildDamage
            animalsdict = species["animals"]
            guildAnimals = GuildAnimals(leaf = animalsdict["leaf"], stem = animalsdict["stem"], flower = animalsdict["flower"])
            guildAnimals.put()
            currSpecies.animals = guildAnimals;
            currSpecies.put()
            
            
    def post(self):
        json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            entry_dict = simplejson.loads(json_str)

            model = NewPhenologyGuildEntryModel()
            
            model.user_name = entry_dict["user_name"]
            try:
                month = entry_dict["month"]
                model.date_time = datetime(entry_dict["year"], month, entry_dict["date"])
            except KeyError:
                model.date_time = datetime.datetime.now()   
            model.plant_name = entry_dict["plant_name"]
            model.plant_accession = entry_dict["plant_accession"]
            model.percent_covered = entry_dict["percent_covered"]
            model.num_species = entry_dict["num_species"]
            #widest_width = db.IntegerProperty()
            
            model.put()
            
            self.parseSpecies(model, entry_dict["species"])
            logging.info("Added NewPhenology tree entry: %s" % str(model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return

   
class GetAnImage(AppRequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/plain'
        #self.response.headers['Content-Disposition'] = 'attachment;filename=getImagePicture.jpg'
        image = (NewPhenologyTreeEntryModel.all().filter("plant_accession =", "RiSi04"))
        logging.debug(image)
        for singleImage in image:
            logging.info("we have one")
            toWrite = singleImage.health.images
            logging.debug(str(toWrite))
            for justWriteIt in toWrite:
                logging.info("writing %s" % justWriteIt)
                #im = Image.open(BytesIO(base64.b64decode(justWriteIt))) 
                #im.save('accept.jpg', 'JPEG') 

                self.response.out.write(justWriteIt)
                '''picture = db.Blob(urlfetch.Fetch('http://upload.wikimedia.org/wikipedia/commons/0/04/Balloons_in_the_sky.jpg').content)
                logging.info('picture is %s' % picture)
                self.response.out.write(picture)'''
                return
class GetNewPhenologyEntriesController(AppRequestHandler):
    
    def tree_entry_to_dict(self, entry):
        entry_dict = dict();
        entry_dict["user_name"] = entry.user_name
        entry_dict["date_time"] = unicode(entry.date_time)
        entry_dict["plant_name"] = entry.plant_name
        entry_dict["height"] = entry.height
        entry_dict["widest_width"] = entry.widest_width
        
        entry_dict["phenology"] = dict()
        #if entry.color is not None:
        entry_dict["phenology"]["overall"] = entry.phenology.overall
        entry_dict["phenology"]["flower"] = entry.phenology.flower
        entry_dict["phenology"]["fruit"] = entry.phenology.fruit
        entry_dict["phenology"]["leaf"] = entry.phenology.leaf
        entry_dict["phenology"]["comment"] = entry.phenology.comment
        entry_dict["phenology"]["images"] = [str(x) for x in entry.phenology.images]
        
        entry_dict["health"] = dict()
        entry_dict["health"]["overall"] = entry.health.overall
        entry_dict["health"]["flower"] = entry.health.flower
        entry_dict["health"]["fruit"] = entry.health.fruit
        entry_dict["health"]["leaf_damage"] = entry.health.leaf_damage
        entry_dict["health"]["leaf_discoloration"] = entry.health.leaf_discoloration
        entry_dict["health"]["stem_tip"] = entry.health.stem_tip
        entry_dict["health"]["bark"] = entry.health.bark
        entry_dict["health"]["comment"] = entry.health.comment
        entry_dict['health']['images'] = [str(x) for x in entry.health.images]
        
        entry_dict["animals"] = dict()
        entry_dict["animals"]["leaf"] = entry.animals.leaf
        entry_dict["animals"]["stem"] = entry.animals.stem
        entry_dict["animals"]["flower"] = entry.animals.flower
        entry_dict["animals"]["fruit"] = entry.animals.fruit
        entry_dict["animals"]["comment"] = entry.animals.comment
        entry_dict['animals']['images'] = [str(x) for x in entry.animals.images]
        
        entry_dict["fruit"] = dict()
        entry_dict["fruit"]["on_tree"] = entry.fruit.on_tree
        entry_dict["fruit"]["on_ground"] = entry.fruit.on_ground
        entry_dict["fruit"]["harvested"] = entry.fruit.harvested
        entry_dict["fruit"]["comment"] = entry.fruit.comment
        entry_dict['fruit']['images'] = [str(x) for x in entry.fruit.images]
        return entry_dict        
    
    def guild_entry_to_dict(self, entry):
        entry_dict = dict()
        entry_dict["user_name"] = entry.user_name
        entry_dict["date_time"] = unicode(entry.date_time)
        entry_dict["plant_name"] = entry.plant_name
        entry_dict["percent_covered"] = entry.percent_covered
        entry_dict["num_species"] = entry.num_species
        species = []
        for sp in entry.species:
            species_dict = dict()
            species_dict["species_name"] = sp.species_name
            species_dict["phenology"] = sp.phenology
            species_dict["percent_understory"] = sp.percent_understory
            species_dict["health"] = sp.health
            
            damage = dict()
            damage["holes"] = sp.damage.holes
            damage["spots"] = sp.damage.spots
            damage["browsed"] = sp.damage.browsed
            damage["other"] = sp.damage.other
            species_dict["damage"] = damage
            
            animals = dict()
            animals["leaf"] = sp.animals.leaf
            animals["stem"] = sp.animals.stem
            animals["flower"] = sp.animals.flower
            species_dict["animals"] = animals
            
            species.append(species_dict)
            
        entry_dict["species"] = species
        
        return entry_dict
        
    def get(self):
        if not self.validate_request_arguments("plant_name"):
            self.error(BAD_REQUEST)
            return
        plant_number = self.request.get("plant_name")
        treequery = NewPhenologyTreeEntryModel.all().filter("plant_accession =", plant_number) 
        entry_dicts = []
        for entry in treequery:
            entry_dict = self.tree_entry_to_dict(entry)
            entry_dicts.append(entry_dict)
        
        understory_dicts = []
        understoryquery = NewPhenologyGuildEntryModel.all().filter("plant_accession =", plant_number)
        for entry in understoryquery:
            entry_dict = self.guild_entry_to_dict(entry)
            understory_dicts.append(entry_dict)
            
        total_dicts = dict()
        total_dicts["tree"] = entry_dicts
        total_dicts["guild"] = understory_dicts
        json_body = simplejson.dumps(total_dicts)
        
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.out.write(json_body)
        return

class GetRecent(AppRequestHandler):
    
    def tree_entry_to_dict(self, entry):
        #doesn't include images
        entry_dict = dict();
        entry_dict["user_name"] = entry.user_name
        entry_dict["date_time"] = unicode(entry.date_time)
        entry_dict["plant_name"] = entry.plant_name
        entry_dict["height"] = entry.height
        entry_dict["widest_width"] = entry.widest_width
        entry_dict['plant_accession'] = entry.plant_accession
        
        entry_dict["phenology"] = dict()
        #if entry.color is not None:
        entry_dict["phenology"]["overall"] = entry.phenology.overall
        entry_dict["phenology"]["flower"] = entry.phenology.flower
        entry_dict["phenology"]["fruit"] = entry.phenology.fruit
        entry_dict["phenology"]["leaf"] = entry.phenology.leaf
        
        entry_dict["health"] = dict()
        entry_dict["health"]["overall"] = entry.health.overall
        entry_dict["health"]["flower"] = entry.health.flower
        entry_dict["health"]["fruit"] = entry.health.fruit
        entry_dict["health"]["leaf_damage"] = entry.health.leaf_damage
        entry_dict["health"]["leaf_discoloration"] = entry.health.leaf_discoloration
        entry_dict["health"]["stem_tip"] = entry.health.stem_tip
        entry_dict["health"]["bark"] = entry.health.bark
        
        entry_dict["animals"] = dict()
        entry_dict["animals"]["leaf"] = entry.animals.leaf
        entry_dict["animals"]["stem"] = entry.animals.stem
        entry_dict["animals"]["flower"] = entry.animals.flower
        entry_dict["animals"]["fruit"] = entry.animals.fruit
        
        entry_dict["fruit"] = dict()
        entry_dict["fruit"]["on_tree"] = entry.fruit.on_tree
        entry_dict["fruit"]["on_ground"] = entry.fruit.on_ground
        entry_dict["fruit"]["harvested"] = entry.fruit.harvested
        return entry_dict        
    
    def get(self):
        
        accessions = set([x.plant_accession for x in NewPhenologyTreeEntryModel.all() if x.plant_accession!=None])
        logging.debug(str(accessions))
        recents = {}
        for accession in accessions:
            recents[accession] = self.tree_entry_to_dict(max(NewPhenologyTreeEntryModel.all().filter("plant_accession =", accession), key=(lambda x:x.date_time)))
        json_body = simplejson.dumps(recents)
        
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.out.write(json_body)
        return
    
class GetCount(AppRequestHandler):
    def get(self):
        if not self.validate_request_arguments("plant_name"):
            self.error(BAD_REQUEST)
            return
        plant_number = self.request.get("plant_name")
        count = NewPhenologyTreeEntryModel.all().filter("plant_accession =", plant_number).count()
        
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.out.write(count)
        return