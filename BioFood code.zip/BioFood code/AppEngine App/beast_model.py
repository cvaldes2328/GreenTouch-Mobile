'''
Created by Michelle on March 15, 2012
based on NewLoosestrifeEntryModel

'''


from google.appengine.ext import db

    
class SessionModel (db.Model):
    filename = db.StringProperty()
    date_time = db.DateTimeProperty()
    
    def str(self):
        str_buf = []
        str_buf.append("filename = "+self.filename)
        str_buf.append("date_time = "+self.date_time)
        str_buf.append('lenses = '+self.lenses)
        str_buf.append('pics = '+self.pics)
        return ', '.join(str_buf)
    
    def toDict(self):
        entry_dict= {}
        entry_dict['filename']= self.filename
        entry_dict['date_time']= str(self.date_time)
        entry_dict['lenses']= [x.toDict() for x in self.lenses]
        return entry_dict

class LensModel (db.Model):
    plant_accession = db.StringProperty()
    active = db.StringProperty()
    animals = db.StringProperty()
    phenology = db.StringProperty()
    damage = db.StringProperty()
    hypothesis= db.StringProperty()
    paired = db.StringProperty()
    position_x= db.IntegerProperty()
    position_y= db.IntegerProperty()
    session = db.ReferenceProperty(SessionModel, collection_name = 'lenses')
    
    def str(self):
        str_buf = []
        str_buf.append("plant_accession = "+ self.plant_accession)
        str_buf.append("active = "+ self.active)
        str_buf.append("animals = "+ self.animals)
        str_buf.append("phenology = "+ self.phenology)
        str_buf.append("damage = "+ self.damage)
        str_buf.append("hypothesis = "+ self.hypothesis)
        str_buf.append("position_x = "+ self.position_x)
        str_buf.append("position_y = "+ self.position_y)
        str_buf.append("session = "+self.session)
        return ", ".join(str_buf)
    
    def toDict(self):
        
        
        entry_dict = dict();
        entry_dict["plant_accession"] = self.plant_accession
        entry_dict["active"]=self.active
        entry_dict["animals"]= self.animals
        entry_dict["phenology"]= self.phenology
        entry_dict["damage"]= self.damage
        entry_dict["hypothesis"]=self.hypothesis
        entry_dict["position_x"]=self.position_x
        entry_dict["position_y"]=self.position_y
        
        return entry_dict        
    
    