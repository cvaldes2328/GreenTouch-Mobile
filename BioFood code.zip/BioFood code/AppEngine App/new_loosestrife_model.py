'''
Created on Sep 17, 2011

@author: Michelle Ferreirae
'''

from google.appengine.ext import db

class NewLoosestrifeEntryModel(db.Model):
    user_name = db.StringProperty()
    date_time = db.DateTimeProperty()
    plant_number = db.StringProperty()
    leaf_damage = db.IntegerProperty()
    average_height = db.IntegerProperty()
    condition_rank = db.IntegerProperty()
    adult_beetles = db.BooleanProperty()
    eggs = db.BooleanProperty()
    larvae = db.BooleanProperty()
    num_beetles = db.IntegerProperty()
    others_are_equally_affected = db.BooleanProperty()
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("date_time = " + str(self.date_time))
        string_buffer.append("user_name = " + str(self.user_name))
        string_buffer.append("plant_number = " + str(self.plant_number))
        string_buffer.append("leaf_damage = " + str(self.leaf_damage))
        string_buffer.append("average_height = " + str(self.average_height))
        string_buffer.append("condition_rank = " + str(self.condition_rank))
        string_buffer.append("adult_beetles = " + str(self.adult_beetles))
        string_buffer.append("eggs = " + str(self.eggs))
        string_buffer.append("larvae = " + str(self.larvae))
        string_buffer.append("num_beetles = " + str(self.num_beetles))
        string_buffer.append("others_are_equally-affected = " + str(self.others_are_equally_affected))
        return ", ".join(string_buffer)
