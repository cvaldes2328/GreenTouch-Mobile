'''Created by Michelle in January 2012
Based on the NewPhenologyController class'''
#from google.appengine.ext import webapp
import logging, sys, datetime
from django.utils import simplejson
#from loosestrife_model import LooseStrifeEntryModel
from beast_model import LensModel, SessionModel
from controller import AppRequestHandler
#from google.appengine.ext import db

class PutBeastData(AppRequestHandler):
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(400)
        
    def post(self):
        logging.debug('putting beast data')
        json_str = self.request.get('entry')
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            entry_dict = simplejson.loads(json_str)

            model = SessionModel()
            model.filename = entry_dict["filename"]
            model.date_time = datetime.datetime.now()
            model.put()
            
            for lens in entry_dict['lenses']:
                lensmodel = LensModel()
                lensmodel.animals = lens['animals']
                lensmodel.plant_accession = lens['plant_accession']
                lensmodel.session = model
                lensmodel.active = lens['active']
                lensmodel.phenology = lens['phenology']
                lensmodel.damage = lens['damage']
                lensmodel.hypothesis = lens['hypothesis']
                lensmodel.position_x = lens['position_x']
                lensmodel.position_y = lens['position_y']
                lensmodel.paired = lens['paired']
                lensmodel.put()
                
            logging.info("Added Beast data: %s" % str(model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            self.debug(json_str)
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return
        
class GetBeastData (AppRequestHandler):
    
    def get(self):
        beastEntries = SessionModel.all()
        json_body = simplejson.dumps([x.toDict() for x in beastEntries])
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.out.write(json_body)
        return