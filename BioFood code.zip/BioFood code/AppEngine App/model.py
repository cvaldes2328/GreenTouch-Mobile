from google.appengine.ext import db
    
class ColorModel(db.Model):
    flower = db.IntegerProperty()
    stem = db.IntegerProperty()
    leaf = db.IntegerProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("flower_color = " + str(self.flower))
        str_buf.append("stem_color = " + str(self.stem))
        str_buf.append("leaf_color = " + str(self.leaf))
        return "(" + ", ".join(str_buf) + ")"

class PhenologyModel2(db.Model):
    leaf = db.IntegerProperty()
    flower = db.IntegerProperty()
    overall = db.IntegerProperty()  
    
    def __str__(self):
        str_buf = []
        str_buf.append("flower_phenology = " + str(self.flower))
        str_buf.append("overall_phenology = " + str(self.overall))
        str_buf.append("leaf_phenology = " + str(self.leaf))  
        return "(" + ", ".join(str_buf) + ")"

class EntryModel2(db.Model):
    user = db.StringProperty(required = True)
    common_name = db.StringProperty(required = True)
    datetime = db.DateTimeProperty(required = True)
    weather = db.StringProperty()
    photo_url = db.StringProperty()  
    color = db.ReferenceProperty(reference_class = ColorModel)
    phenology = db.ReferenceProperty(reference_class = PhenologyModel2)
    sketches = db.StringProperty()
    leaf_texture = db.StringListProperty()
    leaf_smell = db.StringListProperty()
    flower_smell = db.StringListProperty()
    comments = db.TextProperty()
    questions = db.TextProperty()
    location = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("user = " + str(self.user))
        str_buf.append("common_name = " + str(self.common_name))
        str_buf.append("datetime = " + str(self.datetime))  
        str_buf.append("weather = " + str(self.weather))
        str_buf.append("photo_url = " + str(self.photo_url))
        str_buf.append("color = " + str(self.color))  
        str_buf.append("phenology = " + str(self.phenology))
        str_buf.append("sketches = " + str(self.sketches))
        str_buf.append("leaf_texture = " + str(self.leaf_texture))  
        str_buf.append("leaf_smell = " + str(self.leaf_smell))
        str_buf.append("flower_smell = " + str(self.flower_smell))
        str_buf.append("comments = " + str(self.comments))  
        str_buf.append("questions = " + str(self.questions))
        str_buf.append("location = " + str(self.location))
        for evidence in self.animal_evidence:
            str_buf.append("animal_evidence = " + str(evidence))
        
        return "\n".join(str_buf)

class AnimalEvidenceModel2(db.Model):
    entry = db.ReferenceProperty(reference_class = EntryModel2, required = True, collection_name = "animal_evidence")
    description = db.StringProperty(required = True)
    photo_url = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("animal_evidence_description = " + str(self.description))
        str_buf.append("animal_evidence_photo = " + str(self.photo_url))
        return "(" + ", ".join(str_buf) + ")"

""" 
PhenologyModel is deprecated... use PhenologyModel2 now
"""
class PhenologyModel(db.Model):
    leaf = db.StringProperty()
    flower = db.StringProperty()
    overall = db.StringProperty()  
    
    def __str__(self):
        str_buf = []
        str_buf.append("flower_phenology = " + str(self.flower))
        str_buf.append("overall_phenology = " + str(self.overall))
        str_buf.append("leaf_phenology = " + str(self.leaf))  
        return "(" + ", ".join(str_buf) + ")"
    
""" 
EntryModel is deprecated... use EntryModel2 now
"""
class EntryModel(db.Model):
    user = db.StringProperty(required = True)
    common_name = db.StringProperty(required = True)
    datetime = db.DateTimeProperty(required = True, auto_now = True)
    weather = db.StringProperty()
    photo_url = db.StringProperty()  
    color = db.ReferenceProperty(reference_class = ColorModel)
    phenology = db.ReferenceProperty(reference_class = PhenologyModel)
    sketches = db.StringProperty()
    leaf_texture = db.StringListProperty()
    leaf_smell = db.StringListProperty()
    flower_smell = db.StringListProperty()
    comments = db.TextProperty()
    questions = db.TextProperty()
    location = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("user = " + str(self.user))
        str_buf.append("common_name = " + str(self.common_name))
        str_buf.append("datetime = " + str(self.datetime))  
        str_buf.append("weather = " + str(self.weather))
        str_buf.append("photo_url = " + str(self.photo_url))
        str_buf.append("color = " + str(self.color))  
        str_buf.append("phenology = " + str(self.phenology))
        str_buf.append("sketches = " + str(self.sketches))
        str_buf.append("leaf_texture = " + str(self.leaf_texture))  
        str_buf.append("leaf_smell = " + str(self.leaf_smell))
        str_buf.append("flower_smell = " + str(self.flower_smell))
        str_buf.append("comments = " + str(self.comments))  
        str_buf.append("questions = " + str(self.questions))
        str_buf.append("location = " + str(self.location))
        for evidence in self.animal_evidence:
            str_buf.append("animal_evidence = " + str(evidence))
        
        return "\n".join(str_buf)
            
 
        
""" AnimalEvidenceModel is deprecated... use AnimalEvidenceModel2 """
class AnimalEvidenceModel(db.Model):
    entry = db.ReferenceProperty(reference_class = EntryModel, required = True, collection_name = "animal_evidence")
    description = db.StringProperty(required = True)
    photo_url = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("animal_evidence_description = " + str(self.description))
        str_buf.append("animal_evidence_photo = " + str(self.photo_url))
        return "(" + ", ".join(str_buf) + ")"
    
class DeviceToCommonNameMappingModel(db.Model):
    #key_name is the device id
    common_name = db.StringProperty()
    
    def __str__(self):
        return "%s -> %s" % (self.key().name(), self.common_name)
