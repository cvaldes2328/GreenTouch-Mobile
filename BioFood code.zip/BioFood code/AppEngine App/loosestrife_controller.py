from google.appengine.ext import webapp
import logging, sys, datetime
from django.utils import simplejson
from loosestrife_model import LooseStrifeEntryModel
from new_loosestrife_model import NewLoosestrifeEntryModel

ENTRY_POST_KEY = "entry"
BAD_REQUEST = 400

PLANT_NUMBER = "plantNumber"
LEAF_DAMAGE = "leafDamage"
AVERAGE_HEIGHT = "averageHeight"
CONDITION_RANK = "conditionRank"
ADULT_BEETLES = "adultBeetles"
EGGS = "eggs"
LARVAE = "larvae"
NUM_BEETLES = "numBeetles"
OTHERS_ARE_EQUALLY_AFFECTED = "othersAreEquallyAffected"
USER_NAME = "user_name"

class LoosestrifeController(webapp.RequestHandler):
    
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def post(self):
        json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            entry_dict = simplejson.loads(json_str)

            loosestrife_model = LooseStrifeEntryModel()
            
            loosestrife_model.plant_number = entry_dict[PLANT_NUMBER]
            loosestrife_model.leaf_damage = entry_dict[LEAF_DAMAGE]
            loosestrife_model.average_height = entry_dict[AVERAGE_HEIGHT]
            loosestrife_model.condition_rank = entry_dict[CONDITION_RANK]
            loosestrife_model.adult_beetles = bool(entry_dict[ADULT_BEETLES])
            loosestrife_model.eggs = bool(entry_dict[EGGS])
            loosestrife_model.larvae = bool(entry_dict[LARVAE])
            loosestrife_model.num_beetles = entry_dict[NUM_BEETLES]
            loosestrife_model.others_are_equally_affected = bool(entry_dict[OTHERS_ARE_EQUALLY_AFFECTED])
            loosestrife_model.put()
            
            logging.info("Added new loosestrife entry: %s" % str(loosestrife_model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return
        
        
        #LOOOOOOOOKKKKKKKK HEEEEEEEERRRRRRRRRREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
        #MICHELLE"S CODE MAKES SENSE
class NewLoosestrifeController (webapp.RequestHandler):
    #copy all of loosestrife controller original then modify :)
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def post(self):
        #logging.error('wtf')
        logging.info('got a new loosestrife post!')
        json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            entry_dict = simplejson.loads(json_str)
            loosestrife_model = NewLoosestrifeEntryModel()
            loosestrife_model.date_time = datetime.datetime.now()
            loosestrife_model.user_name = entry_dict[USER_NAME]
            loosestrife_model.plant_number = entry_dict[PLANT_NUMBER]
            loosestrife_model.leaf_damage = entry_dict[LEAF_DAMAGE]
            loosestrife_model.average_height = entry_dict[AVERAGE_HEIGHT]
            loosestrife_model.condition_rank = entry_dict[CONDITION_RANK]
            loosestrife_model.adult_beetles = bool(entry_dict[ADULT_BEETLES])
            loosestrife_model.eggs = bool(entry_dict[EGGS])
            loosestrife_model.larvae = bool(entry_dict[LARVAE])
            loosestrife_model.num_beetles = entry_dict[NUM_BEETLES]
            loosestrife_model.others_are_equally_affected = bool(entry_dict[OTHERS_ARE_EQUALLY_AFFECTED])
            loosestrife_model.put()
            
            logging.info("Added a super new loosestrife entry: %s" % str(loosestrife_model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return
        
        
class NewLoosestrifeWithDateController (webapp.RequestHandler):
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def post(self):
        #logging.error('wtf')
        logging.info('got a new loosestrife post with a date!')
        json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        
        try:
            entry_dict = simplejson.loads(json_str)
            loosestrife_model = NewLoosestrifeEntryModel()
            loosestrife_model.date_time = datetime.datetime(entry_dict["year"], entry_dict["month"], entry_dict["day"])
            loosestrife_model.user_name = entry_dict[USER_NAME]
            loosestrife_model.plant_number = entry_dict[PLANT_NUMBER]
            loosestrife_model.leaf_damage = entry_dict[LEAF_DAMAGE]
            loosestrife_model.average_height = entry_dict[AVERAGE_HEIGHT]
            loosestrife_model.condition_rank = entry_dict[CONDITION_RANK]
            loosestrife_model.adult_beetles = bool(entry_dict[ADULT_BEETLES])
            loosestrife_model.eggs = bool(entry_dict[EGGS])
            loosestrife_model.larvae = bool(entry_dict[LARVAE])
            loosestrife_model.num_beetles = entry_dict[NUM_BEETLES]
            loosestrife_model.others_are_equally_affected = bool(entry_dict[OTHERS_ARE_EQUALLY_AFFECTED])
            loosestrife_model.put()
            
            logging.info("Added a super new loosestrife entry: %s" % str(loosestrife_model))
            
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return
class ChangeOverController (webapp.RequestHandler):
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def get(self):
        '''json_str = self.request.get(ENTRY_POST_KEY)
        if not json_str:
            self.set_unsuccessful_response("No 'entry' argument found in request body")
            return
        '''
        try:
            loosestrifes = LooseStrifeEntryModel.all()
            for loosestrife in loosestrifes:
                loosestrife_model = NewLoosestrifeEntryModel()
                #need to figure out what i'm doing about date and time
                loosestrife_model.date_time = datetime.datetime.now()
                loosestrife_model.user_name = "Alex French"
                loosestrife_model.plant_number = loosestrife.plant_number
                loosestrife_model.leaf_damage = loosestrife.leaf_damage
                loosestrife_model.average_height = loosestrife.average_height
                loosestrife_model.condition_rank = loosestrife.condition_rank
                loosestrife_model.adult_beetles = loosestrife.adult_beetles
                loosestrife_model.eggs = loosestrife.eggs
                loosestrife_model.larvae = loosestrife.larvae
                loosestrife_model.num_beetles = loosestrife.num_beetles
                loosestrife_model.others_are_equally_affected = loosestrife.others_are_equally_affected
                loosestrife_model.put()
            
            logging.info("Added a super new loosestrife entry: %s" % str(loosestrife_model))
            return
        except KeyError:
            missing_key = sys.exc_info()[1]
            self.set_unsuccessful_response("JSON string missing '%s' key" % (missing_key))
            return
                
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return