import model
import loosestrife_model
import sys, datetime, logging
from google.appengine.ext import webapp
from django.utils import simplejson
from google.appengine.api.datastore_errors import BadValueError
from google.appengine.ext import db
from google.appengine.api import memcache
from new_loosestrife_model import NewLoosestrifeEntryModel
import google.appengine.ext.db

# A couple of random constants
ENTRY_POST_KEY = "entry"
BAD_REQUEST = 400
ENTITY_CREATED = 201
INTERNAL_SERVER_ERROR = 500
OK = 200
NOT_FOUND = 404

PLAIN_TEXT_MIME = 'text/plain'
JSON_MIME = 'application/json'

DEVICE_ID_POST_KEY = "deviceId"
COMMON_NAME_POST_KEY = "commonName"
LOOSESTRIFE_POST_KEY = "plant_number"

# Keys for entry dict
USER = "user"
COMMON_NAME = "commonName"
DATETIME = "dateTime"
WEATHER = "weather"
MAIN_PHOTO = "photo"
ANIMAL_EVIDENCE = "animalEvidence"
ANIMAL_EVIDENCE_DESCRIPTION = "description"
ANIMAL_EVIDENCE_PHOTO = "photo"
COLORS = "colors"
FLOWER_COLOR = "flowers"
STEM_COLOR = "stem"
LEAF_COLOR = "leaves"
PHENOLOGY = "phenology"
PHENOLOGY_LEAF = "leaf"
PHENOLOGY_FLOWER = "flower"
PHENOLOGY_OVERALL = "overall"
SKETCHES = "sketches"
LEAF_TEXTURE = "leafTexture"
LEAF_SMELL = "leafSmell"
FLOWER_SMELL = "flowerSmell"
COMMENTS = "comments"
QUESTIONS = "questions"
LOCATION = "location"

#more keys, but for Loosestrife
PLANT_NUMBER = "plant_number"
LEAF_DAMAGE = "leaf_damage"
AVERAGE_HEIGHT = "average_height"
CONDITION_RANK = "condition_rank"
ADULT_BEETLES = "adult_beetles"
EGGS = "eggs"
LARVAE = "larvae"
NUMBER_BEETLES = "num_beetles"
EQUALLY_AFFECTED = "others_are_equally_affected"
ENTRY_ID = "entry_id"

class EntryParseException(Exception):
    pass

class AppRequestHandler(webapp.RequestHandler):
    
    def validate_request_arguments(self, *expected_args):
        request_is_valid = True
        for arg in expected_args:
            if '' == self.request.get(arg):
                request_is_valid = False
                logging.warning("Missing argument in request: %s" % arg)
                break
        return request_is_valid
    
    def generate_device_id_memcache_key(self, deviceId):
        return DEVICE_ID_POST_KEY + deviceId

class EntryDataParser(object):
    
    def create_color(self, flower, stem, leaf):
        color = model.ColorModel(flower = flower, stem = stem, leaf = leaf)
        return color
    
    def create_phenology(self, leaf, flower, overall):
        phrenology = model.PhenologyModel2(leaf = leaf, flower = flower, overall = overall)
        return phrenology
    
    def create_animal_evidence(self, entry, description, photo_url):
        animal_evidence = model.AnimalEvidenceModel2(description = description, entry = entry, photo_url = photo_url)
        return animal_evidence
    
    def parse_and_put_entry_str(self, entry_str, entry_class = model.EntryModel2):
        entry_dict = simplejson.loads(entry_str)
            
        try:
            user = entry_dict[USER]
            common_name = entry_dict[COMMON_NAME].lower()
            now = datetime.datetime.now()
            entry = entry_class(user = user, common_name = common_name, datetime = now)
                 
            entry.weather = entry_dict.get(WEATHER)
            entry.photo_url = entry_dict.get(MAIN_PHOTO)
            
            colors = entry_dict.get(COLORS)
            if colors:            
                flower_color = colors[FLOWER_COLOR]
                stem_color = colors[STEM_COLOR]
                leaf_color = colors[LEAF_COLOR]
                color_model = self.create_color(flower_color, stem_color, leaf_color)
                color_model.put()
                entry.color = color_model
            
            phenology = entry_dict.get(PHENOLOGY)
            if phenology:
                leaf_phenology = phenology[PHENOLOGY_LEAF]
                flower_phenology = phenology[PHENOLOGY_FLOWER]
                overall_phenology = phenology[PHENOLOGY_OVERALL]
                phenology_model = self.create_phenology(leaf_phenology, flower_phenology, overall_phenology)
                phenology_model.put()
                entry.phenology = phenology_model                
            
            entry.sketches = entry_dict.get(SKETCHES)
            entry.leaf_texture = entry_dict.get(LEAF_TEXTURE, [])
            entry.leaf_smell = entry_dict.get(LEAF_SMELL, [])
            entry.flower_smell = entry_dict.get(FLOWER_SMELL, [])
            entry.comments = entry_dict.get(COMMENTS)
            entry.questions = entry_dict.get(QUESTIONS)
            entry.location = entry_dict.get(LOCATION)
            
            entry.put()

            animal_evidence = entry_dict.get(ANIMAL_EVIDENCE, [])
            if animal_evidence is not None:
                for instance in animal_evidence:   
                    description = instance[ANIMAL_EVIDENCE_DESCRIPTION]
                    animal_evidence_photo = instance.get(ANIMAL_EVIDENCE_PHOTO)
                    animal_evidence = self.create_animal_evidence(entry = entry, description = description, photo_url = animal_evidence_photo)
                    animal_evidence.put()
                    
            self.finished_parse_and_put_entry_str(entry_str, entry)

        except KeyError:
            exc_value = sys.exc_info()[1]
            raise EntryParseException("EntryModel object missing %s data" % (exc_value))
        
    def finished_parse_and_put_entry_str(self, entry_str, entry_instance):
        """ A hook method for finished_parse_and_put_entry_str() """
        pass
                        
class PrintAllLooseStrifeEntries(AppRequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/csv'
        self.response.headers['Content-Disposition'] = 'attachment;filename=LooseStrifeData.csv'
        
        loosestrifes = loosestrife_model.LooseStrifeEntryModel.all()
        response_buf = []
        
        header_buf = []
        header_buf.append("Id")
        header_buf.append("PlantNumber")
        header_buf.append("LeafDamage")
        header_buf.append("AverageHeight")
        header_buf.append("ConditionRank")
        header_buf.append("AdultBeetles")
        header_buf.append("Eggs")
        header_buf.append("Larvae")
        header_buf.append("NumBeetles")
        header_buf.append("OthersAreEquallyAffected")
        response_buf.append(", ".join(header_buf))
        
        for loosestrife in loosestrifes:
            loosestrife_buf = []
            loosestrife_buf.append(str(loosestrife.key().id()))
            loosestrife_buf.append(str(loosestrife.plant_number))
            loosestrife_buf.append(str(loosestrife.leaf_damage))
            loosestrife_buf.append(str(loosestrife.average_height))
            loosestrife_buf.append(str(loosestrife.condition_rank))
            loosestrife_buf.append(str(loosestrife.adult_beetles))
            loosestrife_buf.append(str(loosestrife.eggs))
            loosestrife_buf.append(str(loosestrife.larvae))
            loosestrife_buf.append(str(loosestrife.num_beetles))
            loosestrife_buf.append(str(loosestrife.others_are_equally_affected))
            response_buf.append(", ".join(loosestrife_buf))
            
        self.response.out.write("\n".join(response_buf))
                                
                        
class NewEntryController(AppRequestHandler, EntryDataParser):
    def set_unsuccessful_response(self, msg):
        logging.warning(msg)
        self.error(BAD_REQUEST)
    
    def set_successful_response(self):
        logging.info("Successfully created new entry");
        self.response.set_status(ENTITY_CREATED)
    
    def post(self):
        if self.validate_request_arguments(ENTRY_POST_KEY) == False:
            self.set_unsuccessful_response("'entry' post data was empty")
            return
        
        entry_str = self.request.get(ENTRY_POST_KEY)
        logging.info("Entry string: %s" % entry_str)
        try:
            self.parse_and_put_entry_str(entry_str)
            
        except EntryParseException:
            err_str = sys.exc_info()[1]
            self.set_unsuccessful_response(err_str)
            return
        
        except BadValueError:
            err_str = sys.exc_info()[1]
            self.set_unsuccessful_response(err_str)
            return
        
        except ValueError:
            exc_value = sys.exc_info()[1]
            self.set_unsuccessful_response(exc_value)
            return

        
        self.set_successful_response()            
        
class PrintAllEntriesController(AppRequestHandler):
    def get(self):
        entries = model.EntryModel2.all().order("-datetime")
        self.response.headers['Content-Type'] = 'text/plain'
        str_buf = []
        for entry in entries:
            str_buf.append(str(entry))
            
        self.response.out.write('Printing all entries (%d)\n\n' % entries.count())
        self.response.out.write('\n\n'.join(str_buf))
        
    
class MainPageController(AppRequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.out.write('Flower power server is running')
        
class SetDeviceCommonNameMappingController(AppRequestHandler):    
    
    def create_or_update_mapping(self, device_id, common_name):
        mapping = model.DeviceToCommonNameMappingModel.get_or_insert(device_id)
        mapping.common_name = common_name;
        mapping.put()
                    
    def post(self):
        if self.validate_request_arguments(DEVICE_ID_POST_KEY, COMMON_NAME_POST_KEY) == False:
            self.error(BAD_REQUEST)
            return
        device_id = str(int(self.request.get(DEVICE_ID_POST_KEY)))
        common_name = self.request.get(COMMON_NAME_POST_KEY)
        memcache.set(self.generate_device_id_memcache_key(device_id), common_name)
        self.create_or_update_mapping(device_id, common_name)
        logging.info("Set device mapping (%s -> %s)" % (device_id, common_name))
        
class PrintDeviceCommonNameMappingController(AppRequestHandler):    
                    
    def get(self):
        mappings = model.DeviceToCommonNameMappingModel.all()
        self.response.headers['Content-Type'] = 'text/plain'
        str_buf = []
        for mapping in mappings:
            str_buf.append(str(mapping))
            
        self.response.out.write('Printing all mappings (%d)\n\n' % mappings.count())
        self.response.out.write('\n'.join(str_buf))
        
class GetCommonNameFromDeviceIdController(AppRequestHandler):
    def get(self):
        if not self.validate_request_arguments(DEVICE_ID_POST_KEY):
            self.error(BAD_REQUEST)
            return
        device_id = str(int(self.request.get(DEVICE_ID_POST_KEY)))
        
        common_name = memcache.get(self.generate_device_id_memcache_key(device_id))
        if common_name is None:    
            mapping = model.DeviceToCommonNameMappingModel.get_by_key_name(device_id)
            if mapping:
                common_name = mapping.common_name
                memcache.set(self.generate_device_id_memcache_key(device_id), common_name)
            else:
                self.response.set_status(NOT_FOUND)
        self.response.out.write(common_name)

class GetAllPlantEntriesController(AppRequestHandler):

    def entry_to_dict(self, entry):
        entry_dict = dict()
        entry_dict[USER] = entry.user
        entry_dict[COMMON_NAME] = entry.common_name
        entry_dict[DATETIME] = unicode(entry.datetime)
        entry_dict[WEATHER] = entry.weather
        entry_dict[MAIN_PHOTO] = entry.photo_url
        entry_dict[ANIMAL_EVIDENCE] = []
        for evidence in entry.animal_evidence:
            evidence_dict = dict()
            evidence_dict[ANIMAL_EVIDENCE_DESCRIPTION] = evidence.description
            evidence_dict[ANIMAL_EVIDENCE_PHOTO] = evidence.photo_url
            entry_dict[ANIMAL_EVIDENCE].append(evidence_dict)
        
        entry_dict[COLORS] = dict()
        if entry.color is not None:
            entry_dict[COLORS][FLOWER_COLOR] = entry.color.flower
            entry_dict[COLORS][STEM_COLOR] = entry.color.stem
            entry_dict[COLORS][LEAF_COLOR] = entry.color.leaf
        
        entry_dict[PHENOLOGY] = dict()
        if entry.phenology is not None:
            entry_dict[PHENOLOGY][PHENOLOGY_LEAF] = entry.phenology.leaf
            entry_dict[PHENOLOGY][PHENOLOGY_FLOWER] = entry.phenology.flower
            entry_dict[PHENOLOGY][PHENOLOGY_OVERALL] = entry.phenology.overall
        
        entry_dict[SKETCHES] = entry.sketches
        entry_dict[LEAF_TEXTURE] = entry.leaf_texture
        entry_dict[LEAF_SMELL] = entry.leaf_smell
        entry_dict[FLOWER_SMELL] = entry.flower_smell
        entry_dict[COMMENTS] = entry.comments
        entry_dict[QUESTIONS] = entry.questions
        entry_dict[LOCATION] = entry.location
        
        return entry_dict        
    
    def get(self):
        if not self.validate_request_arguments(COMMON_NAME_POST_KEY):
            self.error(BAD_REQUEST)
            return
        
        common_name = self.request.get(COMMON_NAME_POST_KEY)
        query = model.EntryModel2.all().filter("common_name =", common_name.lower()).order("-datetime") 
        entry_dicts = []
        for entry in query:
            entry_dict = self.entry_to_dict(entry)
            entry_dicts.append(entry_dict)
            
        json_body = simplejson.dumps(entry_dicts)
        
        self.response.headers['Content-Type'] = JSON_MIME
        self.response.out.write(json_body)

        
#This is the part where Michelle kills everything.
class GetAllLoosestrifeEntriesController(AppRequestHandler):
    
    def loosestrife_entry_to_dict(self, entry):
        entry_dict = dict()
        #entry_dict[USER] = entry.user
        entry_dict[ENTRY_ID] = entry.key().id()
        entry_dict[PLANT_NUMBER] = entry.plant_number
        entry_dict[LEAF_DAMAGE] = entry.leaf_damage
        entry_dict[AVERAGE_HEIGHT] = entry.average_height
        entry_dict[CONDITION_RANK] = entry.condition_rank
        entry_dict[ADULT_BEETLES] = entry.adult_beetles
        entry_dict[EGGS] = entry.eggs
        entry_dict[LARVAE] = entry.larvae
        entry_dict[NUMBER_BEETLES] = entry.num_beetles
        entry_dict[EQUALLY_AFFECTED] = entry.others_are_equally_affected

        return entry_dict        
    
    def get(self):
        if not self.validate_request_arguments(LOOSESTRIFE_POST_KEY):
            logging.warning("missing the post key")
            self.error(BAD_REQUEST)
            return
        logging.info("has a post key, going to do stuff")
        plant_number = self.request.get(LOOSESTRIFE_POST_KEY)
        query = loosestrife_model.LooseStrifeEntryModel.all().filter("plant_number =", plant_number) 
        entry_dicts = []
        for entry in query:
            entry_dict = self.loosestrife_entry_to_dict(entry)
            entry_dicts.append(entry_dict)
            
        json_body = simplejson.dumps(entry_dicts)
        
        self.response.headers['Content-Type'] = PLAIN_TEXT_MIME
        self.response.out.write(json_body)
        return
        
class GetNewLoosestrifeEntriesController(AppRequestHandler):
    
    def loosestrife_entry_to_dict(self, entry):
        entry_dict = dict();
        entry_dict[USER] = entry.user_name
        entry_dict[DATETIME] = unicode(entry.date_time)
        entry_dict[PLANT_NUMBER] = entry.plant_number
        entry_dict[LEAF_DAMAGE] = entry.leaf_damage
        entry_dict[AVERAGE_HEIGHT] = entry.average_height
        entry_dict[CONDITION_RANK] = entry.condition_rank
        entry_dict[ADULT_BEETLES] = entry.adult_beetles
        entry_dict[EGGS] = entry.eggs
        entry_dict[LARVAE] = entry.larvae
        entry_dict[NUMBER_BEETLES] = entry.num_beetles
        entry_dict[EQUALLY_AFFECTED] = entry.others_are_equally_affected
        entry_dict[ENTRY_ID] = entry.key().id()

        return entry_dict        
    
    def get(self):
        if not self.validate_request_arguments(LOOSESTRIFE_POST_KEY):
            self.error(BAD_REQUEST)
            return
        plant_number = self.request.get(LOOSESTRIFE_POST_KEY)
        query = NewLoosestrifeEntryModel.all().filter("plant_number =", plant_number) 
        entry_dicts = []
        for entry in query:
            entry_dict = self.loosestrife_entry_to_dict(entry)
            entry_dicts.append(entry_dict)
            
        json_body = simplejson.dumps(entry_dicts)
        
        self.response.headers['Content-Type'] = PLAIN_TEXT_MIME
        self.response.out.write(json_body)
        return
