'''
Created by Michelle on January 13
based on NewLoosestrifeEntryModel

'''

from google.appengine.ext import db


class PhenologyModel3(db.Model):
    leaf = db.IntegerProperty()
    fruit = db.IntegerProperty()
    flower = db.IntegerProperty()
    overall = db.IntegerProperty()  
    comment = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("flower_phenology = " + str(self.flower))
        str_buf.append("overall_phenology = " + str(self.overall))
        str_buf.append("leaf_phenology = " + str(self.leaf))  
        str_buf.append("fruit_phenology = "+str(self.fruit))
        str_buf.append("images = "+str(self.images))
        str_buf.append("comment = "+str(self.comment))
        return "(" + ", ".join(str_buf) + ")"

class PhenologyImage (db.Model):
    phenology = db.ReferenceProperty(PhenologyModel3, collection_name = "images")
    image =  db.BlobProperty(default = None)
    
    def __str__(self):
        return str(self.image)

class HealthModel (db.Model):
    overall = db.IntegerProperty()
    stem_tip = db.IntegerProperty()
    bark = db.IntegerProperty()
    leaf_damage = db.IntegerProperty()
    leaf_discoloration = db.IntegerProperty()
    flower = db.IntegerProperty()
    fruit = db.IntegerProperty()
    comment = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("overall_health = " + str(self.overall))
        str_buf.append("stem_tip = " + str(self.stem_tip))
        str_buf.append("leaf_damage = " + str(self.leaf_damage))  
        str_buf.append("fruit_discoloration = "+str(self.leaf_discoloration))
        str_buf.append("bark = "+str(self.bark))
        str_buf.append("flower = "+str(self.flower))
        str_buf.append("fruit = "+str(self.fruit))
        str_buf.append("images = "+str(self.images))
        str_buf.append("comment = "+str(self.comment))
        return "(" + ", ".join(str_buf) + ")"
    

class HealthImage (db.Model):
    health = db.ReferenceProperty(HealthModel, collection_name = "images")
    image =  db.BlobProperty(default = None)
    
    def __str__(self):
        return str(self.image)


class AnimalModel (db.Model):
    leaf = db.IntegerProperty()
    stem = db.IntegerProperty()
    flower = db.IntegerProperty()
    fruit = db.IntegerProperty()
    comment = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("flower_animals = " + str(self.flower))
        str_buf.append("stem_animals = " + str(self.stem))
        str_buf.append("leaf_animals = " + str(self.leaf))  
        str_buf.append("fruit_animals = "+str(self.fruit))
        str_buf.append("images = "+str(self.images))
        str_buf.append("comment = "+str(self.comment))
        return "(" + ", ".join(str_buf) + ")"

class AnimalImage (db.Model):
    health = db.ReferenceProperty(AnimalModel, collection_name = "images")
    image =  db.BlobProperty(default = None)
    
    def __str__(self):
        return str(self.image)


class ProductivityModel (db.Model):
    on_tree = db.IntegerProperty()
    on_ground = db.IntegerProperty()
    harvested = db.IntegerProperty()
    comment = db.StringProperty()
    
    def __str__(self):
        str_buf = []
        str_buf.append("fruits_on_tree = "+str(self.on_tree))
        str_buf.append("fruits_on_ground = "+str(self.on_ground))
        str_buf.append("fruits_harvested = "+str(self.harvested))
        str_buf.append("images = "+str(self.images))
        str_buf.append("comment = "+str(self.comment))
        return "(" + ", ".join(str_buf) + ")"

class ProductivityImage (db.Model):
    health = db.ReferenceProperty(ProductivityModel, collection_name = "images")
    image =  db.BlobProperty(default = None)
    
    def __str__(self):
        return str(self.image)


class NewPhenologyTreeEntryModel(db.Model):
    user_name = db.StringProperty()
    date_time = db.DateTimeProperty()
    plant_accession = db.StringProperty()
    plant_name = db.StringProperty()
    height = db.IntegerProperty()
    widest_width = db.IntegerProperty()
    phenology = db.ReferenceProperty(reference_class = PhenologyModel3)
    health = db.ReferenceProperty(reference_class = HealthModel)
    animals = db.ReferenceProperty(reference_class = AnimalModel)
    fruit = db.ReferenceProperty(reference_class = ProductivityModel)
    
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("date_time = " + str(self.date_time))
        string_buffer.append("user_name = " + str(self.user_name))
        string_buffer.append("plant_accession = " + str(self.plant_accession))
        string_buffer.append("plant_name = " + str(self.plant_name))
        string_buffer.append("height = " + str(self.height))
        string_buffer.append("widest_width = " + str(self.widest_width))
        string_buffer.append("phenology = " + str(self.phenology))
        string_buffer.append("health = " + str(self.health))
        string_buffer.append("animals = " + str(self.animals))
        string_buffer.append("fruit = " + str(self.fruit))
        return ", ".join(string_buffer)

class NewPhenologyGuildEntryModel (db.Model):
    user_name = db.StringProperty()
    date_time = db.DateTimeProperty()
    plant_accession = db.StringProperty()
    plant_name = db.StringProperty()
    percent_covered = db.IntegerProperty()
    num_species = db.IntegerProperty()
    comment = db.StringProperty()
    #volunteers = db.ListProperty(db.Key)
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("date_time = " + str(self.date_time))
        string_buffer.append("user_name = " + str(self.user_name))
        string_buffer.append("plant_accession = " + str(self.plant_accession))
        string_buffer.append("plant_name = " + str(self.plant_name))
        string_buffer.append("percent_covered = " + str(self.percent_covered))
        string_buffer.append("num_species = " + str(self.num_species))
        string_buffer.append("species = " + str(self.species))
        string_buffer.append("comment = "+str(self.comment))
        return ", ".join(string_buffer)
    
class GuildDamage (db.Model):
    
    holes = db.IntegerProperty()
    spots = db.IntegerProperty()
    browsed = db.IntegerProperty()
    other = db.IntegerProperty()
    comment = db.StringProperty()
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("holes = " + str(self.holes))
        string_buffer.append("spots = " + str(self.spots))
        string_buffer.append("browsed = " + str(self.browsed))
        string_buffer.append("other = " + str(self.other))
        string_buffer.append("comment = "+str(self.comment))
        return ", ".join(string_buffer)
    

class GuildAnimals (db.Model):
    leaf = db.IntegerProperty()
    stem = db.IntegerProperty()
    flower = db.IntegerProperty()
    comment= db.StringProperty()
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("leaf = " + str(self.leaf))
        string_buffer.append("stem = " + str(self.stem))
        string_buffer.append("flower = " + str(self.flower))
        string_buffer.append("comment = "+str(self.comment))
        return ", ".join(string_buffer)
    
class GuildSpeciesModel (db.Model):
    guild = db.ReferenceProperty(NewPhenologyGuildEntryModel,
                                 collection_name = "species")
    species_name = db.StringProperty()
    phenology = db.IntegerProperty()
    percent_understory = db.IntegerProperty()
    health = db.IntegerProperty()
    damage = db.ReferenceProperty(reference_class = GuildDamage)
    animals = db.ReferenceProperty(reference_class = GuildAnimals)
    
    def __str__(self):
        string_buffer = []
        string_buffer.append("species_name = " + str(self.species_name))
        string_buffer.append("phenology = " + str(self.phenology))
        string_buffer.append("percent_understory = " + str(self.percent_understory))
        string_buffer.append("health = "+str(self.health))
        string_buffer.append("damage = "+str(self.damage))
        string_buffer.append("animals = "+str(self.animals))
        return ", ".join(string_buffer)
    
    
    