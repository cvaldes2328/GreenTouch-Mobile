//
//  PhenologyReferenceViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 3/6/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhenologyReferenceViewController : UIViewController{
    UIScrollView *scrollView;
}

@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;

@end
