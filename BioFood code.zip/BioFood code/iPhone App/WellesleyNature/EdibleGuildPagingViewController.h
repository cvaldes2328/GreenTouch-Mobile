//
//  EdibleGuildPagingViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/19/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface EdibleGuildPagingViewController : UIViewController<UIScrollViewDelegate>{
    
    AppDelegate *app_delegate;
    double current_page;
    BOOL pageControlUsed;
    NSMutableArray *view_controllers_array;    
    
    UIScrollView *pagingScrollView;
    UIPageControl *pageControl;
}


@property (nonatomic, retain) AppDelegate *app_delegate;
@property (nonatomic) double current_page;
@property (nonatomic, retain) NSMutableArray *view_controllers_array;    

@property (nonatomic, retain) IBOutlet UIScrollView *pagingScrollView;
@property (nonatomic, retain) IBOutlet UIPageControl *pageControl;


@end
