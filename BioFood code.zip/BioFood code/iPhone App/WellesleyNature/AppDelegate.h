//
//  AppDelegate.h
//  WellesleyNature
//
//  Created by HCI Lab on 12/29/11.
//  Copyright (c) 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
//#import "ObjectiveFlickr.h"
#define knamesFilename
#define kdataFilename   @"dataGathered.plist"

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
    NSMutableDictionary *entryData;
    NSMutableArray *totalSpringDataGathered;
    NSMutableArray *totalEdibleTreeDataGathered;
    NSMutableArray *totalEdibleGuildDataGathered;
    NSMutableArray *guildArray; 
    NSString *plantAccession;
    NSMutableString *userNames;

//    OFFlickrAPIRequest *flickrRequest;
//    OFFlickrAPIContext *flickrContext;
}

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, retain) NSMutableString *userNames;
@property (nonatomic, retain) NSString *plantAccession;
@property (nonatomic, retain) NSMutableDictionary *entryData;
@property (nonatomic, retain) NSMutableArray *totalSpringDataGathered;
@property (nonatomic, retain) NSMutableArray *totalEdibleTreeDataGathered;
@property (nonatomic, retain) NSMutableArray *totalEdibleGuildDataGathered;
@property (nonatomic, retain) NSMutableArray *guildArray; 

//@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;
//@property (nonatomic, retain) OFFlickrAPIContext *flickrContext;

//- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken;

@end
