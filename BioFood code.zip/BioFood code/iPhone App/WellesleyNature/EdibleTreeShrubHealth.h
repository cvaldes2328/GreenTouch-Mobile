//
//  EdibleTreeShrubHealth.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/31/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate; 


@interface EdibleTreeShrubHealth : UIViewController{
    
    AppDelegate *app_delegate;
    
    UIScrollView *scrollView; 
    
    UISegmentedControl *overall;
    UISegmentedControl *stemTip;
    UISegmentedControl *bark;
    UISegmentedControl *leafDamage;
    UISegmentedControl *leafDiscolor;
    UISegmentedControl *fruit;
    UISegmentedControl *flower;
    
    UIImage *image;
    UIButton *imageButton;
}
@property (nonatomic, retain) AppDelegate *app_delegate; 

@property (nonatomic, retain) IBOutlet UIScrollView *scrollView; 

@property (nonatomic, retain) IBOutlet UISegmentedControl *overall;
@property (nonatomic, retain) IBOutlet UISegmentedControl *stemTip;
@property (nonatomic, retain) IBOutlet UISegmentedControl *bark;
@property (nonatomic, retain) IBOutlet UISegmentedControl *leafDamage;
@property (nonatomic, retain) IBOutlet UISegmentedControl *leafDiscolor;
@property (nonatomic, retain) IBOutlet UISegmentedControl *fruit;
@property (nonatomic, retain) IBOutlet UISegmentedControl *flower;

@property (nonatomic, retain) IBOutlet UIButton *imageButton; 
@property (nonatomic, retain) UIImage *image;

-(IBAction)nextButtonPressed:(id)sender;
@end
