//
//  PickerSegControlViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/18/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "PickerSegControlViewController.h"

@implementation PickerSegControlViewController

@synthesize app_delegate, /*questions,*/ segments, plistName, questionLabel, questionSegControl, optionsPicker, measuresDictionary, imageButton, nextButton, picturesDictionary;



#pragma mark - SegControl

/*
 Update label and picker based on measure selected
 */
-(IBAction)QuestionChanged:(UISegmentedControl *)sender{
    
    NSDictionary *currQuestion = [segments objectAtIndex:questionSegControl.selectedSegmentIndex];
    [questionLabel setText:[currQuestion valueForKey:@"Question"]];
    
    //update next/done button title
    if(questionSegControl.selectedSegmentIndex<2) {
        [nextButton setTitle:@"Next" forState:UIControlStateNormal]; 
    } else {
        [nextButton setTitle:@"Done" forState:UIControlStateNormal];
    }
    
    NSLog(@"about to reload components");
    [optionsPicker reloadAllComponents];
        //now, find the saved value
    int lastVal = [[measuresDictionary objectForKey:[currQuestion valueForKey:@"upload-key"]] intValue];
    NSLog(@"lastVal is %d", lastVal);
    for(int i = 0; i<[[currQuestion objectForKey:@"Options"] intValue]; i++) {
        if (i==0) { //tens place
            [optionsPicker selectRow:(lastVal%10) inComponent:[optionsPicker numberOfComponents]-i-1 animated:NO];
            // NSLog(@"i=1 and the ones place should be %d", (lastVal%10));
        } else { //ones place
            [optionsPicker selectRow:((lastVal-(lastVal%10))/10) inComponent:[optionsPicker numberOfComponents]-i-1 animated:NO];
            //NSLog(@"i=0 and the tens place should be %d", (lastVal-(lastVal%10))/10);
        }
    }
    NSLog(@"finished");
}

-(IBAction)nextButtonPressed:(id)sender {
    if (questionSegControl.selectedSegmentIndex==0) {
        questionSegControl.selectedSegmentIndex++;
        [self QuestionChanged:questionSegControl];
    } else if (questionSegControl.selectedSegmentIndex==1) {
        questionSegControl.selectedSegmentIndex++;
        [nextButton setTitle:@"Done" forState:UIControlStateNormal]; 
        [self QuestionChanged:questionSegControl];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - PickerView

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return [[[segments objectAtIndex:questionSegControl.selectedSegmentIndex] objectForKey:@"Options"] intValue];
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
    return 10;
    
}

- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{	
    
    return [NSString stringWithFormat:@"%d", row];
	
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSDictionary *currQuestion = [segments objectAtIndex:questionSegControl.selectedSegmentIndex];
	//NSLog(@"%@", [NSNumber numberWithInt:[pickerView selectedRowInComponent:0]]);
    //NSLog(@"currQuestion is %@", currQuestion);
    //pulls out the old digit at the component's digit in the number, then replaces it
    component = [pickerView numberOfComponents] - component - 1;
    NSLog(@"component is %d", component);
    int lastSelected = [[measuresDictionary objectForKey:[currQuestion objectForKey:@"upload-key"]] intValue];
    int mod = (lastSelected % (int)(pow(10, component+1)))- (lastSelected % (int)pow(10, component));
    NSLog(@"mod is %d", mod);
    lastSelected -= mod;
    lastSelected += row*(int)(pow(10, component));
    [measuresDictionary setValue:[NSNumber numberWithInt:lastSelected] forKey:[currQuestion objectForKey:@"upload-key"]];
    
    NSLog(@"measures dictionary is %@", measuresDictionary);

    //NSNumber *selected = [NSNumber numberWithInt:[pickerView selectedRowInComponent:0]];
    
    /*    if (questionSegControl.selectedSegmentIndex == 0){
     //[springMeasuresDictionary setObject:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:0]] forKey:@"leaf"];
     [phenologyDictionary setValue:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:component]] forKey:@"leaf"];
     }else if (questionSegControl.selectedSegmentIndex == 1){
     //flower
     [phenologyDictionary setValue:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:component]] forKey:@"flower"];  
     } if (questionSegControl.selectedSegmentIndex == 2){
     //flower
     [phenologyDictionary setValue:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:component]] forKey:@"fruit"];
     }else {
     //overall bloom
     [phenologyDictionary setValue:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:component]] forKey:@"overall"];            
     }*/
    
}


#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewPicturesLabel setHidden:YES];
		//[self dismissModalViewControllerAnimated:YES];
		//[pictures addObject:[[NSArray alloc] initWithObjects: image, selectedType, nil]];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		//newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
        //newView.frame = CGRectMake(45-40, 10, 40, 60);
		//[self.picturesScrollView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		[imageButton setImage:image forState:UIControlStateNormal];
        [imageButton setImage:image forState:UIControlStateHighlighted];
        [imageButton setHidden:NO];
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
    
    
    -(IBAction) buttonPressed: (id)sender {
        //UIButton *button = (UIButton *)sender;
        
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        } else {
            return;
        }
        
        [self presentModalViewController:imagePicker animated:YES];
    }


#pragma mark - Init stuff

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //for now, we're hardcoding the name of the plist; can be set when you initialize the view, then comment out the following line
    plistName = @"Productivity";
    NSBundle *bundle = [NSBundle mainBundle];
    segments = [[NSArray alloc] initWithContentsOfFile:[bundle pathForResource:plistName ofType:@"plist"]];
    //start with the question from the first one
    [questionLabel setText:[[segments objectAtIndex:0] valueForKey:@"Question"]];
    
    //measuresDictionary = 
    //the rest of this is old code
    
    //NSDictionary *temporary = [[NSDictionary alloc] initWithContentsOfFile:[bundle pathForResource:plistName ofType:@"plist"]];
    //phenologyDictionary = [[NSDictionary alloc] init];
    //phenologyDictionary = [temporary valueForKey:@"EdibleEcosystem"];
    if([app_delegate.entryData objectForKey:@"fruit"]){
        measuresDictionary = [app_delegate.entryData objectForKey:@"fruit"];
    } else {
        measuresDictionary = [[NSMutableDictionary alloc] init];
        for (int i = 0; i<[segments count]; i++) {
            [measuresDictionary setValue:[NSNumber numberWithInt:0] forKey:[[segments objectAtIndex:i] valueForKey:@"upload-key"]];
        }
    }
    
    NSLog(@"Measures dictionary is %@", measuresDictionary);
    //measuresDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
    //                        0, @"leaf",
    //                        0, @"flower",
    //                        0, @"fruit",
    //                         0, @"overall", nil];
    
    //start with leaf
    //NSDictionary *leafStart = [phenologyDictionary valueForKey:@"Leaf"];
    //[questionLabel setText:[leafStart valueForKey:@"Question"]];
    
    
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");	
    
    //this is hardcoded at the moment... fix sometime?
	[app_delegate.entryData setValue:measuresDictionary forKey:@"fruit"];
    NSLog(@"%@", app_delegate.entryData);
	[super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
