//
//  EdibleChooseTreeOrGuild.h
//  WellesleyNature
//
//  Created by HCI Lab on 3/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;
@interface EdibleChooseTreeOrGuild : UIViewController {
    UILabel *plantNameLabel;
    UIImageView *plantPicView;
    
    UIImageView *treeCheck;
    UIImageView *guildCheck;
    
    UIButton *doneButton;
    
    AppDelegate *app_delegate;
}

@property (nonatomic, retain) IBOutlet UILabel *plantNameLabel;
@property (nonatomic, retain) IBOutlet UIImageView *plantPicView;
@property (nonatomic, retain) IBOutlet UIImageView *treeCheck;
@property (nonatomic, retain) IBOutlet UIImageView *guildCheck;
@property (nonatomic, retain) IBOutlet UIButton *doneButton;

@property (nonatomic, retain) AppDelegate *app_delegate;

-(IBAction)doneButtonPressed:(id)sender;
-(IBAction)woodyButtonPressed:(id)sender;
-(IBAction)ActionButtonPressed:(UIButton*)sender;

@end
