//
//  EdibleTreeUpdateSize.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/23/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleTreeUpdateSize.h"
#import "AppDelegate.h"
@implementation EdibleTreeUpdateSize

@synthesize heightField, widthField, heightStepper, widthStepper, app_delegate, backgroundButton;



#pragma mark - Init stuff

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)backgroundButtonClose:(id)sender {
    [widthField resignFirstResponder]; 
    [heightField resignFirstResponder];
    
    [widthStepper setValue:[widthField.text doubleValue]];
    [heightStepper setValue:[heightField.text doubleValue]];
}

#pragma mark - Stepper functions
-(IBAction) heightStepperUpdated: (id)sender{
    //UIStepper *heightStepper = (UIStepper *)sender;
 //   double value = [sender value];
    heightField.text = [NSString stringWithFormat:@"%d", (int)heightStepper.value];
}

-(IBAction) widthStepperUpdated: (id)sender{
    //UIStepper *widthStepper = (UIStepper *)sender;
 //   double value = [sender value];
    widthField.text = [NSString stringWithFormat:@"%d", (int)widthStepper.value];
    //NSLog(@"updated width to %@", widthStepper.value);
}

#pragma mark KeyboardStuff

- (void)resizeRestore {
	[heightField resignFirstResponder];
    [widthField resignFirstResponder];
	//[scrollView setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"text field returning");
	[heightField resignFirstResponder];
    [widthField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", textField.text]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
    NSLog(@"began editing");
	//[scrollView setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 100) animated:YES];	
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [super viewDidLoad];
}

-(void) viewWillDisappear:(BOOL)animated {
    [app_delegate.entryData setValue:[NSNumber numberWithInt:heightStepper.value] forKey:@"height"];
    [app_delegate.entryData setValue:[NSNumber numberWithInt:widthStepper.value] forKey:@"widest_width"];

    [super viewWillDisappear:animated];
}

-(void) viewWillAppear:(BOOL)animated {
    if ([app_delegate.entryData valueForKey:@"height"]) {
        heightStepper.value = [[app_delegate.entryData valueForKey:@"height"] doubleValue];
        heightField.text = [NSString stringWithFormat:@"%d", (int)heightStepper.value];
        widthStepper.value = [[app_delegate.entryData valueForKey:@"widest_width"] doubleValue];
        widthField.text = [NSString stringWithFormat:@"%d", (int)widthStepper.value];
    }
    
    [super viewWillAppear:animated];
}
/*
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
 */

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
