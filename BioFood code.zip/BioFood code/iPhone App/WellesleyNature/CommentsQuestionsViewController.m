//
//  CommentsQuestionsViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "CommentsQuestionsViewController.h"

@implementation CommentsQuestionsViewController

@synthesize app_delegate, comments, questions, scrollViewForKeyboard;


-(IBAction)keyboardButtonPresed:(id)sender{
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark KeyboardStuff

- (void)resizeRestore {
	[comments resignFirstResponder];
    [questions resignFirstResponder];
	[scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [comments resignFirstResponder];
    [questions resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", textField.text]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
	[scrollViewForKeyboard setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 120) animated:YES];	
}

- (IBAction) backgroundButton
{
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", text_field.text]];
	[comments resignFirstResponder];
    [questions resignFirstResponder];
	[self resizeRestore];
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    comments.delegate = self;
    questions.delegate = self;
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");
	[app_delegate.entryData setValue:comments.text forKey:@"comments"];
	[app_delegate.entryData setValue:questions.text forKey:@"questions"];
    //NSLog(@"%@", app_delegate.entryData);
	[super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
