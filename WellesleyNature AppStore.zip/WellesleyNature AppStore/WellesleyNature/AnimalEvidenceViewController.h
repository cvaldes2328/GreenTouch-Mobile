//
//  AnimalEvidenceViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 12/30/11.
//  Copyright (c) 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface AnimalEvidenceViewController : UIViewController<UITextFieldDelegate, UIImagePickerControllerDelegate>{
    
    AppDelegate *app_delegate;
    NSMutableDictionary *answers;
    //number textfields
    UITextField *leafTextField;
    UITextField *flowerTextField;
    UITextField *stemTextField;
    UITextField *fruitTextField;
    
    //camera buttons
    UIButton *leafPicture;
    UIButton *flowerPicture;
    UIButton *stemPicture;
    UIButton *fruitPicture;
    
    //steppers
    UIStepper *leafStepper;
    UIStepper *flowerStepper;
    UIStepper *stemStepper;
    UIStepper *fruitStepper;
    
    UIScrollView *scrollViewForKeyboard;
    UIScrollView *picturesScrollView;
    UILabel *viewPicturesLabel;
    //pictures data storage
    NSMutableArray *pictures;
    
}

@property (nonatomic, retain) AppDelegate *app_delegate;
@property (nonatomic, retain) NSMutableDictionary *answers;
//number textfields
@property (nonatomic, retain) IBOutlet UITextField *leafTextField;
@property (nonatomic, retain) IBOutlet UITextField *flowerTextField;
@property (nonatomic, retain) IBOutlet UITextField *stemTextField;
@property (nonatomic, retain) IBOutlet UITextField *fruitTextField;

//camera buttons
@property (nonatomic, retain) IBOutlet UIButton *leafPicture;
@property (nonatomic, retain) IBOutlet UIButton *flowerPicture;
@property (nonatomic, retain) IBOutlet UIButton *stemPicture;
@property (nonatomic, retain) IBOutlet UIButton *fruitPicture;

//stepper
@property (nonatomic, retain) IBOutlet UIStepper *leafStepper;
@property (nonatomic, retain) IBOutlet UIStepper *flowerStepper;
@property (nonatomic, retain) IBOutlet UIStepper *stemStepper;
@property (nonatomic, retain) IBOutlet UIStepper *fruitStepper;


@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForKeyboard;
@property (nonatomic, retain) IBOutlet UIScrollView *picturesScrollView;
@property (nonatomic, retain) IBOutlet UILabel *viewPicturesLabel;
@property (nonatomic, retain) NSMutableArray *pictures;

-(IBAction) leafStepperPressed:(UIStepper *)sender;
-(IBAction) flowerStepperPressed:(UIStepper *)sender;
-(IBAction) stemStepperPressed:(UIStepper *)sender;
-(IBAction) fruitStepperPressed:(UIStepper *)sender;
- (IBAction) backgroundButton;
-(IBAction)nextButtonPressed:(id)sender;
@end
