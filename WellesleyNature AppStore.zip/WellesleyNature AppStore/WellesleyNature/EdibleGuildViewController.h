//
//  EdibleGuildViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/19/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;
@class EdibleGuildMainPageViewController;

@interface EdibleGuildViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>{
   
    AppDelegate *app_delegate; 
    
    UITableView *totalCoverTableView;
    UITableView *occupationPercentTableView;
    UIScrollView *contentScrollView;
    
    
    int *selected;
    NSArray *totalCoverOptionsArray;
    NSArray *occupationPercentOptionsArray;
    
    UISegmentedControl *healthSegControl;
    
    //for damage
    UISegmentedControl *holesSegControl;
    UISegmentedControl *spotsSegControl;
    UISegmentedControl *browsedSegControl;
    UISegmentedControl *otherSegControl;
    
    UITextField *leafAnimalField;
    UITextField *stemAnimalField;
    UITextField *flowerAnimalField;
    
    UIStepper *leafAnimalStepper;
    UIStepper *stemAnimalStepper;
    UIStepper *flowerAnimalStepper; 
    
    UIImageView *plantImage;
    
    UILabel *scientificLabel;
    
    UIButton *backgroundButton; 

}

@property (nonatomic, retain) AppDelegate *app_delegate; 

@property (nonatomic, retain) IBOutlet UITableView *totalCoverTableView;
@property (nonatomic, retain) IBOutlet UITableView *occupationPercentTableView;
@property (nonatomic, retain) IBOutlet UIScrollView *contentScrollView;

@property (nonatomic) int *selected;
@property (nonatomic, retain) NSArray *totalCoverOptionsArray;
@property (nonatomic, retain) NSArray *occupationPercentOptionsArray;

@property (nonatomic, retain) IBOutlet UISegmentedControl *healthSegControl;
@property (nonatomic, retain) IBOutlet UISegmentedControl *holesSegControl;
@property (nonatomic, retain) IBOutlet UISegmentedControl *spotsSegControl;
@property (nonatomic, retain) IBOutlet UISegmentedControl *browsedSegControl;
@property (nonatomic, retain) IBOutlet UISegmentedControl *otherSegControl;

//for GuildAnimals
@property(nonatomic, retain) IBOutlet UITextField *leafAnimalField;
@property(nonatomic, retain) IBOutlet UITextField *stemAnimalField;
@property(nonatomic, retain) IBOutlet UITextField *flowerAnimalField;

@property(nonatomic, retain) IBOutlet UIStepper *leafAnimalStepper; 
@property(nonatomic, retain) IBOutlet UIStepper *stemAnimalStepper; 
@property(nonatomic, retain) IBOutlet UIStepper *flowerAnimalStepper; 


@property (nonatomic, retain) IBOutlet UIButton *backgroundButton; 
@property (nonatomic, retain) IBOutlet UIImageView *plantImage;
@property (nonatomic, retain) IBOutlet UILabel *scientificLabel;


-(IBAction)leafAnimalStepperUpdate:(id)sender;
-(IBAction)stemAnimalStepperUpdate:(id)sender;
-(IBAction)flowerAnimalStepperUpdate:(id)sender;

-(IBAction)stepperValueChanged:(id)sender;

-(IBAction)backgroundButtonClose:(id)sender;
-(IBAction)saveButtonPressed:(id)sender;

@end
