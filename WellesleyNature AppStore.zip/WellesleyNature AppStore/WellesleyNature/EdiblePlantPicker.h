//
//  EdiblePlantPicker.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/23/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "ZXingWidgetController.h"
//#import "ObjectiveFlickr.h"
@class AppDelegate;

@interface EdiblePlantPicker: UIViewController<ZXingDelegate/*, OFFlickrAPIRequestDelegate*/>{
    NSArray *plantNames;
    AppDelegate *app_delegate;
    
    //OFFlickrAPIRequest *flickrRequest;
}

@property (nonatomic, retain) NSArray *plantNames;
@property (nonatomic, retain) AppDelegate *app_delegate;
//@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;

-(IBAction)buttonPressed:(id)sender;
-(BOOL) connectedToNetwork;
@end
