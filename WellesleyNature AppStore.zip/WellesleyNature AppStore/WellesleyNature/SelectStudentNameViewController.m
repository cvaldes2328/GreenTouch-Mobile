//
//  SelectStudentNameViewController.m
//  WellesleyNature
//
//  Created by LTS on 1/14/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "SelectStudentNameViewController.h"
#import "AppDelegate.h"

@implementation SelectStudentNameViewController

@synthesize studentNames, selected, app_delegate;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    studentNames = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"names" ofType:@"plist"]];
    selected =0;
    
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [studentNames count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    NSUInteger row = [indexPath row];
    NSString *name = [studentNames objectAtIndex:row]; 
    cell.textLabel.text = name;
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//deselect row
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	
    //if(!app_delegate.userNames) app_delegate.userNames = [[NSMutableString alloc] init];
	//if(cell.accessoryType == UITableViewCellAccessoryCheckmark) {
		//cell.accessoryType = UITableViewCellAccessoryNone;//toggle check
        [app_delegate.userNames replaceOccurrencesOfString:cell.textLabel.text withString:@"" options:kNilOptions range:NSMakeRange(0, [app_delegate.userNames length])];
       // selected--;
    //}
	//else {
		cell.accessoryType = UITableViewCellAccessoryCheckmark;//check!
        if ([app_delegate.userNames length]>1) {
            [app_delegate.userNames appendString:@", "];
        }
        [app_delegate.userNames appendString:cell.textLabel.text];
        //[app_delegate.userNames appendString:@", "];
    //    selected++;
    //}
    
    //if(selected > 1)
   // {
        //[app_delegate.userNames deleteCharactersInRange:NSMakeRange([app_delegate.userNames length]-2, 2)];
        [self performSegueWithIdentifier:@"main page" sender:self];
   // }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
        //NSIndexPath *selectedIndexPath = [self.tableView indexPathForSelectedRow];
        //NSInteger rowNumber = selectedIndexPath.row;
        
        //UIViewController *next = [segue destinationViewController];
        //next.title = [studentNames objectAtIndex:rowNumber];
    
        //#warning Save 2 names to data structure
    NSLog(@"user names are %@", app_delegate.userNames);

}

@end
