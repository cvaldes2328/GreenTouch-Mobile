//
//  EdibleChooseTreeOrGuild.m
//  WellesleyNature
//
//  Created by HCI Lab on 3/2/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleChooseTreeOrGuild.h"
#import "AppDelegate.h"

@implementation EdibleChooseTreeOrGuild

@synthesize plantPicView, plantNameLabel, doneButton, app_delegate, treeCheck, guildCheck;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)woodyButtonPressed:(id)sender {
    //NSLog(@"pressed woody button");
    
    if([app_delegate.totalEdibleTreeDataGathered count]>0) {
        NSMutableDictionary *lastDict = [app_delegate.totalEdibleTreeDataGathered objectAtIndex:[app_delegate.totalEdibleTreeDataGathered count]-1];
        //NSLog(@"%@", lastDict);
        if([[lastDict objectForKey:@"plant_accession"] isEqualToString:app_delegate.plantAccession]) {
            app_delegate.entryData = lastDict;
            [app_delegate.totalEdibleTreeDataGathered removeObject:lastDict];
        }
    }
}

-(IBAction)guildButtonPressed:(id)sender {
    NSLog(@"pressed guild button");
    NSLog(@"total edible data is %@", app_delegate.totalEdibleGuildDataGathered);
    if([app_delegate.totalEdibleGuildDataGathered count]>0) {
        NSMutableDictionary *lastDict = [app_delegate.totalEdibleGuildDataGathered objectAtIndex:[app_delegate.totalEdibleGuildDataGathered count]-1];
        NSLog(@"%@", lastDict);
        if([[lastDict objectForKey:@"plant_accession"] isEqualToString:app_delegate.plantAccession]) {
            //fuck this
            //NSLog(@"setting the guild array, now it's %@", [lastDict objectForKey:@"species"]);
            app_delegate.guildArray = [lastDict objectForKey:@"species"];
            [app_delegate.totalEdibleGuildDataGathered removeObject:lastDict];
        }
    }
    if(!app_delegate.guildArray) app_delegate.guildArray = [[NSMutableArray alloc] init];
    NSLog(@"guild array is %@", app_delegate.guildArray);
}

-(IBAction)doneButtonPressed:(id)sender{
    //NSLog(@"pressed done button");
    //[app_delegate.totalEdibleTreeDataGathered addObject:app_delegate.entryData];
    //app_delegate.entryData = nil;
    
    [self.navigationController popViewControllerAnimated:YES];
    //[self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

-(IBAction)ActionButtonPressed:(UIButton*)sender{
    
    if([@"Tree/shrub" isEqualToString:sender.titleLabel.text])
    {
        treeCheck.hidden = NO;
    }  else{
        guildCheck.hidden = NO;
    }
    
    
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    app_delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *plistPath = [bundle pathForResource:@"EdibleEcoSys" ofType:@"plist"];
    
    NSDictionary *temporary_dictionary = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    //guildList = [[temporary_dictionary valueForKey:app_delegate.plantAccession] valueForKey:@"guild"];
   // NSLog(@"plant name is %@", app_delegate.plantAccession);
   // NSLog(@"current plant is %@", [temporary_dictionary valueForKey:app_delegate.plantAccession]);
    [app_delegate.entryData setValue:[[temporary_dictionary valueForKey:app_delegate.plantAccession] valueForKey:@"common_name"] forKey:@"plant_name"];
    self.title = [app_delegate.entryData objectForKey:@"plant_name"];
    plantNameLabel.text = self.title;
    plantPicView.image = [UIImage imageNamed:[app_delegate.plantAccession substringToIndex:[app_delegate.plantAccession length]-2]];
    [self.navigationItem setHidesBackButton:YES];
    [super viewDidLoad];
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //NSLog(@"%@", app_delegate.totalEdibleTreeDataGathered);
    [self.navigationItem setHidesBackButton:YES];
   // NSLog(@"view appeared");
    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
