//
//  EdibleTreeShrubHealth.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/31/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleTreeShrubHealth.h"
#import "AppDelegate.h" 

@implementation EdibleTreeShrubHealth

@synthesize overall, stemTip, bark, leafDamage, leafDiscolor, flower, fruit, app_delegate, scrollView, imageButton, image; 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)nextButtonPressed:(id)sender {
    [self viewWillDisappear:YES];
    [self.navigationController popViewControllerAnimated:YES];

}

#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */

#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewPicturesLabel setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
        self.image = image;
        //NSLog(@"setting image");
        [imageButton setImage:image forState:UIControlStateNormal];
        [imageButton setImage:image forState:UIControlStateSelected];
        [imageButton setHidden:NO];
        //[picturesDict setObject:image forKey:[self stringForSelectedIndex]];
		//[pictures addObject:[[NSArray alloc] initWithObjects: image, selectedType, nil]];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		////newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
        //newView.frame = CGRectMake(45-40, 10, 40, 60);
		//[self.picturesScrollView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
    
    
    -(IBAction) buttonPressed: (id)sender {
        //UIButton *button = (UIButton *)sender;
        
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        } else {
            return;
        }
        
        [self presentModalViewController:imagePicker animated:YES];
    }


#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    //NSLog(@"we're totally setting the content size");
    [scrollView setContentSize:CGSizeMake(100, 675)]; 
    [super viewDidLoad];
}

-(void) viewWillAppear:(BOOL)animated {
    NSMutableDictionary *dict = [app_delegate.entryData objectForKey:@"health"];
    //NSLog(@"%@", app_delegate.entryData);
    if(dict) {
       // NSLog(@"setting things");
        [fruit setSelectedSegmentIndex:[[dict objectForKey:@"fruit"] intValue]];
        [overall setSelectedSegmentIndex:[[dict objectForKey:@"overall"] intValue]];
        [flower setSelectedSegmentIndex:[[dict objectForKey:@"flower"] intValue]];
        [stemTip setSelectedSegmentIndex:[[dict objectForKey:@"stem_tip"] intValue]];
        [bark setSelectedSegmentIndex:[[dict objectForKey:@"bark"] intValue]];
        [leafDamage setSelectedSegmentIndex:[[dict objectForKey:@"leaf_damage"] intValue]];
        [leafDiscolor setSelectedSegmentIndex:[[dict objectForKey:@"leaf_discoloration"] intValue]];
        
    }
    [self.navigationItem setHidesBackButton:YES];
    [super viewWillAppear:animated];
}
-(void) viewWillDisappear:(BOOL)animated {

    NSMutableDictionary *answers = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:[overall selectedSegmentIndex]], @"overall",
                                    [NSNumber numberWithInt:[fruit selectedSegmentIndex]], @"fruit",
                                    [NSNumber numberWithInt:[flower selectedSegmentIndex]], @"flower",
                                    [NSNumber numberWithInt:[stemTip selectedSegmentIndex]], @"stem_tip",
                                    [NSNumber numberWithInt:[bark selectedSegmentIndex]], @"bark",
                                    [NSNumber numberWithInt:[leafDamage selectedSegmentIndex]], @"leaf_damage",
                                    [NSNumber numberWithInt:[leafDiscolor selectedSegmentIndex]], @"leaf_discoloration",
                                    nil];
    if(image) [answers setValue:[NSMutableArray arrayWithObject:image] forKey:@"images"];
    else [answers setValue:[[NSMutableArray alloc] init] forKey:@"images"];
    //NSLog(@"saving things: %@", answers);
    [app_delegate.entryData setValue:answers forKey:@"health"];
    [super viewWillDisappear:animated];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
