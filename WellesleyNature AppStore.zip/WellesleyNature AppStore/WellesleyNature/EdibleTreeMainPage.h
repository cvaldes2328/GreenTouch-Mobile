//
//  EdibleTreeMainPage.h
//  WellesleyNature
//
//  Created by HCI Lab on 2/17/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;
@interface EdibleTreeMainPage : UIViewController{
    AppDelegate *app_delegate;
    
    UIBarButtonItem *saveButton;
    UIButton *sizeButton;
    
    UILabel *nameLabel; 
    UIImageView *picture;
    
    UIImageView *picturePhenology;
    UIImageView *pictureHealth;
    UIImageView *pictureProductivity;
    UIImageView *pictureAnimals;
    UIImageView *pictureSize;
    
    NSArray *plantNames; 
}

@property (nonatomic, retain) AppDelegate *app_delegate;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *saveButton;
@property (nonatomic, retain) IBOutlet UIButton *sizeButton;

@property (nonatomic, retain) IBOutlet UILabel *nameLabel; 
@property (nonatomic, retain) IBOutlet UIImageView *picture; 

@property (nonatomic, retain) IBOutlet UIImageView *picturePhenology;
@property (nonatomic, retain) IBOutlet UIImageView *pictureHealth;
@property (nonatomic, retain) IBOutlet UIImageView *pictureProductivity;
@property (nonatomic, retain) IBOutlet UIImageView *pictureAnimals;
@property (nonatomic, retain) IBOutlet UIImageView *pictureSize;

@property (nonatomic, retain) NSArray *plantNames; 

-(IBAction)saveButtonPressed:(id)sender;
-(IBAction)ActionButtonPressed:(UIButton*)sender;

@end
