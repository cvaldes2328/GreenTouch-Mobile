//
//  ProductivityViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 2/27/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//
//  Replace PickerSegControlViewController. Get's rid of pickers and uses text field and steppers to enter the data instead. 

#import <UIKit/UIKit.h>
@class AppDelegate; 


@interface ProductivityViewController : UIViewController<UITextFieldDelegate, UIImagePickerControllerDelegate>{
    AppDelegate *app_delegate; 
    NSMutableDictionary *answers;
    
    
    UITextField *treeField; //How many fruits of any size are currently on the tree/shrub?
    UITextField *groundField; //How many fruits are on the ground that are probably from this tree/shrub?
    UITextField *havestField; //haha....How many fruits are you harvesting today to eat?
    
    UIStepper *treeStepper; 
    UIStepper *groundStepper;
    UIStepper *harvestStepper;
    
    UIButton *treeImageButton; 
    UIButton *groundImageButton;
    UIButton *harvestImageButton; 
    
    UIButton *backgroundButton; 
    
    UIScrollView *scrollViewForKeyboard;
    UIScrollView *picturesScrollView;
    UILabel *viewPicturesLabel;
    //pictures data storage
    NSMutableArray *pictures;
    
}
@property (nonatomic, retain) AppDelegate *app_delegate;
@property (nonatomic, retain) NSMutableDictionary *answers; 

@property (nonatomic, retain) IBOutlet UITextField *treeField; 
@property (nonatomic, retain) IBOutlet UITextField *groundField; 
@property (nonatomic, retain) IBOutlet UITextField *harvestField; 

@property (nonatomic, retain) IBOutlet UIStepper *treeStepper; 
@property (nonatomic, retain) IBOutlet UIStepper *groundStepper; 
@property (nonatomic, retain) IBOutlet UIStepper *harvestStepper; 

@property (nonatomic, retain) IBOutlet UIButton *treeImageButton; 
@property (nonatomic, retain) IBOutlet UIButton *groundImageButton; 
@property (nonatomic, retain) IBOutlet UIButton *harvestImageButton; 

@property (nonatomic, retain) IBOutlet UIButton *backgroundButton; 

@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForKeyboard;
@property (nonatomic, retain) IBOutlet UIScrollView *picturesScrollView;
@property (nonatomic, retain) IBOutlet UILabel *viewPicturesLabel;
@property (nonatomic, retain) NSMutableArray *pictures;

-(IBAction) treeStepperUpdated: (id)sender;
-(IBAction) groundStepperUpdated: (id)sender;
-(IBAction) harvestStepperUpdated: (id)sender;
-(IBAction) backgroundButtonClose:(id)sender;
-(IBAction) nextButtonPressed:(id)sender;

@end
