//
//  SelectStudentNameViewController.h
//  WellesleyNature
//
//  Created by LTS on 1/14/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;
@interface SelectStudentNameViewController : UITableViewController{

    NSArray *studentNames;
    int selected;
    
    AppDelegate *app_delegate;
}

@property (nonatomic, retain) NSArray *studentNames;
@property (nonatomic) int selected;

@property (nonatomic, retain) AppDelegate *app_delegate;

@end
