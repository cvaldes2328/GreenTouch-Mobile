//
//  PickerSegControlViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/18/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//
// not used as of 02/27

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface PickerSegControlViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate, UIImagePickerControllerDelegate>{
    
    AppDelegate *app_delegate;
    
    //NSDictionary *phenologyDictionary;
    NSMutableDictionary *measuresDictionary;
    NSMutableDictionary *picturesDictionary;
    
    UISegmentedControl *questionSegControl;
    
    NSArray *segments;
    //NSDictionary *questions;
    UILabel *questionLabel;
    UIPickerView *optionsPicker;
    UIButton *imageButton;
    UIButton *nextButton; 
    
    NSString *plistName;

    
}

@property (nonatomic, retain) AppDelegate *app_delegate;

//@property (nonatomic, retain) NSDictionary *phenologyDictionary;
@property (nonatomic, retain) NSMutableDictionary *measuresDictionary;
@property (nonatomic, retain) NSMutableDictionary *picturesDictionary;

@property (nonatomic, retain) NSArray *segments;
//@property (nonatomic, retain) NSDictionary *questions;
@property (nonatomic, retain) NSString *plistName;

@property(nonatomic, retain) IBOutlet UISegmentedControl *questionSegControl;

@property(nonatomic, retain) IBOutlet UILabel *questionLabel;
@property(nonatomic, retain) IBOutlet UIPickerView *optionsPicker;
@property(nonatomic, retain) IBOutlet UIButton *imageButton;
@property(nonatomic, retain) IBOutlet UIButton *nextButton; 

-(IBAction)QuestionChanged:(UISegmentedControl *)sender;
-(IBAction)buttonPressed:(id)sender;
-(IBAction)nextButtonPressed:(id)sender;

@end
