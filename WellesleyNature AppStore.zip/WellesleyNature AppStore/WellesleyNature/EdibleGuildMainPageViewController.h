//
//  EdibleGuildMainPageViewController.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/20/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class EdibleGuildViewController;
@class AppDelegate; 

@interface EdibleGuildMainPageViewController : UITableViewController {
    
    NSArray *guildList;
    
    UITextField *numAnimalField;
    UIStepper *numAnimalStepper;
    
    UISegmentedControl *percentCoveredSegControl; 
    UITableView *table;
    
    UIButton  *backgroundButton; 
    
    UIButton *saveButton; 
    
    AppDelegate *app_delegate; 
}

@property (nonatomic, retain) NSArray *guildList; 

@property(nonatomic, retain) IBOutlet UITextField *numAnimalField;
@property(nonatomic, retain) IBOutlet UIStepper *numAnimalStepper; 

@property (nonatomic, retain) IBOutlet UISegmentedControl *percentCoveredSegControl; 
@property (nonatomic, retain) IBOutlet UITableView *table;
@property (nonatomic, retain) IBOutlet UIButton *backgroundButton; 

@property (nonatomic, retain) IBOutlet UIButton *saveButton; 

@property(nonatomic, retain) AppDelegate *app_delegate; 

-(IBAction)numAnimalStepperUpdate:(id)sender;

-(IBAction)saveButtonPressed:(id)sender;
-(IBAction)backgroundButtonClose:(id)sender;
@end
