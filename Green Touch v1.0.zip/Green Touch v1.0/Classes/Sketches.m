//
//  Sketches.m
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "Sketches.h"
#import "FlowerPowerNavBAppDelegate.h"
#import "ObjectiveFlickr.h"

#import "SampleAPIKey.h"


@implementation Sketches
@synthesize pic;


-(IBAction) backButtonPressed:(id)sender{
	[self.view removeFromSuperview];	
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	self.title = [NSString stringWithFormat:@"Save Sketches"];
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary{
	NSLog(@"done???");
}


- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didFailWithError:(NSError *)inError{
	NSLog(@"error");
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest imageUploadSentBytes:(NSUInteger)inSentBytes totalBytes:(NSUInteger)inTotalBytes{
	NSLog(@"what is this???");
}





-(IBAction) cameraButtonPressed: (id) sender {
	NSLog(@"pressed the button");
	UIImagePickerController *picker = [[UIImagePickerController alloc] init];
	picker.delegate = self;
	picker.allowsImageEditing = NO;
	picker.sourceType = UIImagePickerControllerSourceTypeCamera;
	FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	[app_delegate.navigationController presentModalViewController:picker animated:YES];
}

#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		NSLog(@"made it!");
		[self dismissModalViewControllerAnimated:YES];
		pic = image;
		FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
		[app_delegate.navigationController popViewControllerAnimated:YES];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		//newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
		//[self.questions_scroll_view addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
	
/*- (void)imagePickerController:(UIImagePickerController *)picker
		didFinishPickingImage:(UIImage *)image
				  editingInfo:(NSDictionary *)editingInfo {
	//HERE'S WHERE WE DO THE UPLOADING TO FLICKR
	
	OFFlickrAPIContext *context = [[OFFlickrAPIContext alloc] initWithAPIKey:@"8bf5396058a1b049300e0bcf1d6d1d7c" sharedSecret:@"2b0407a86d205081"];
	OFFlickrAPIRequest *request = [[OFFlickrAPIRequest alloc] initWithAPIContext:context];
	
	// set the delegate, here we assume it's the controller that's creating the request object
	[request setDelegate:self];
	NSLog(@"created request");
	NSData* imgData = UIImageJPEGRepresentation(image, 1.0);
	NSInputStream *imageStream = [NSInputStream inputStreamWithData:imgData];
    [request uploadImageStream:imageStream suggestedFilename:@"Foobar.jpg" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
	NSLog(@"uploaded?");
	
	[picker dismissModalViewControllerAnimated:YES];
}*/

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
	[picker dismissModalViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
