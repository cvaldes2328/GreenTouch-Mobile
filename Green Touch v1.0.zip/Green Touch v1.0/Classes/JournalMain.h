//
//  JournalMain.h
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface JournalMain : UIViewController {

	IBOutlet UIView *byDayView, *overTimeView;
	IBOutlet UISegmentedControl *tabController;
	IBOutlet UITableView *byDays;
}

@property (nonatomic, retain) IBOutlet UISegmentedControl *tabController;
@property (nonatomic, retain) IBOutlet UIView *byDayView;
@property (nonatomic, retain) IBOutlet UIView *overTimeView;
@property (nonatomic, retain) IBOutlet UITableView *byDays;

-(IBAction) backButtonPressed: (id) sender;

-(IBAction) changedView: (id) sender;
@end
