//
//  RootViewController.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/18/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CoreFoundation.h>

#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>

#import "RootViewController.h"
#import "FlowerPowerNavBAppDelegate.h"
#import "AddNewEntry.h"
#import "ZXingWidgetController.h"
#import "QRCodeReader.h"
#import "SampleAPIKey.h"

@implementation RootViewController

@synthesize app_delegate, scanView, specimenView, dateLabel, segControl, addNew, flickrRequest;
@synthesize resultsView, resultsToDisplay, surfaceView, namesView, studentName;
@synthesize whereView; 
@synthesize currentDataList, plantInfo, plantNames, studentNamesTemp, submitAllButton;
//Log
@synthesize stream_, log_;


#pragma mark -
#pragma mark View lifecycle

- (void)viewDidLoad {
	self.title = @"Pick your name to start";

	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	plantNames = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"PlantNames" ofType:@"plist"]];
	

	studentNamesTemp = [[NSArray alloc]init];
	NSArray *tempArray = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"names" ofType:@"plist"]];
	studentNamesTemp = [tempArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	
	self.studentName = [NSString alloc];
	self.currentDataList = studentNamesTemp;
	//Log set up
	self.log_ = [[NSMutableArray alloc]init];
	
	[segControl setFrame:
     CGRectMake(segControl.frame.origin.x,
				segControl.frame.origin.y,
				segControl.frame.size.width, 
				segControl.frame.size.height*1.4)];
	
	[submitAllButton setHidden:YES];
	
    [super viewDidLoad];
	   	
}


// Implement viewWillAppear: to do additional setup before the view is presented.
- (void)viewWillAppear:(BOOL)animated {
	self.title = @"Pick your name to start";
	if(app_delegate.totalDataGathered||([app_delegate.totalSurveyInfo count]>=1)) {
		[submitAllButton setHidden:NO];
		//[app_delegate.dataGathered release];
		//app_delegate.dataGathered = [[NSMutableDictionary alloc] init];
		
	}
    [super viewWillAppear:animated];
}

-(IBAction) viewChanged: (id)sender{
	NSLog(@"dammit: %d", segControl.selectedSegmentIndex);
	switch (segControl.selectedSegmentIndex) {
		case 0:
			self.title = @"Pick your name to start";
			NSArray *tempArray;
			tempArray = [[NSArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"names" ofType:@"plist"]];
			studentNamesTemp = [tempArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
			self.currentDataList = studentNamesTemp;
			//NSLog(@"yes!");
			[namesView setHidden:NO];
			[surfaceView setHidden:YES];
			break;
		case 1:
			self.title = @"Pick plant & place on surface";

			//get plant info from plist
			self.currentDataList = plantNames;		
			[namesView setHidden:YES];
			[surfaceView setHidden:NO];
			break;
			
		default:
			break;
	}
	[self.namesView reloadData];
	[self.surfaceView reloadData];
	
}

- (void)_startUpload:(NSNumber *)image
{
	int i = [image intValue];

	NSLog(@"going to start upload");
    NSData *JPEGData = UIImageJPEGRepresentation([app_delegate.pics objectAtIndex:i], 1.0);
	 
	 //snapPictureButton.enabled = NO;
	 //snapPictureDescriptionLabel.text = @"Uploading";
	 
	 self.flickrRequest.sessionInfo = @"kUploadImageStep";
	 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] 
						 suggestedFilename:@"Demo" MIMEType:@"image/jpeg" 
								 arguments:[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"WCBotany%@ WCBotany notDuplicate", [[app_delegate.picPlants objectAtIndex:i] stringByReplacingOccurrencesOfString:@" " withString:@""]], @"tags", @"0", @"is_public", nil]];
	 
	
	
	NSLog(@"upload?");
	[UIApplication sharedApplication].idleTimerDisabled = YES;
	
	//[self updateUserInterface:nil];
}

- (void)_startUploadRevised:(NSNumber *)image { 
	//This method works to upload all images from the surveys done since the last time they were uploaded.  It's thrilling stuff.
	int count = [image intValue];
	for (int i = 0; i<[app_delegate.totalSurveyInfo count]; i++) {
		for (int j = 0; j<[[app_delegate.totalSurveyInfo objectAtIndex:i]count]; j++) {
			NSArray *images = [[app_delegate.totalSurveyPics objectAtIndex:i] objectAtIndex:j];
			for (int k = 0; k<[images count]; k++) {
				NSLog(@"the picture i'm sending: %@", [images objectAtIndex:k]);
				NSLog(@"the tags i'm setting: %@",[[app_delegate.totalSurveyInfo objectAtIndex:i] objectAtIndex:j]);
				[self performSelector: @selector(_startUploadThree:) withObject:[[NSArray alloc] initWithObjects:[images objectAtIndex:k],[[app_delegate.totalSurveyInfo objectAtIndex:i] objectAtIndex:j], nil] afterDelay:5.0+10.0*count];
				count++;
			}
		}
	}
	
}
	
- (void)_startUploadThree:(NSArray *)args {
	//This method uploads a single picture, given the picture and the desired tags in the proper format.
	NSLog(@"going to start upload 3");
    NSData *JPEGData = UIImageJPEGRepresentation([args objectAtIndex:0], 1.0);
	
	//snapPictureButton.enabled = NO;
	//snapPictureDescriptionLabel.text = @"Uploading";
	
	self.flickrRequest.sessionInfo = @"kUploadImageStep";
	[self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] 
						suggestedFilename:@"Demo" MIMEType:@"image/jpeg" 
								arguments:[NSDictionary dictionaryWithObjectsAndKeys:[args objectAtIndex:1], @"tags", @"0", @"is_public", nil]];
	
	
	
	NSLog(@"upload?");
	[UIApplication sharedApplication].idleTimerDisabled = YES;
	
}

- (IBAction)authorizeAction
{	
	//authorizeButton.enabled = NO;
	//authorizeDescriptionLabel.text = @"Logging in...";
    
    NSURL *loginURL = [[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext loginURLFromFrobDictionary:nil requestedPermission:OFFlickrWritePermission];
    [[UIApplication sharedApplication] openURL:loginURL];
}


-(BOOL) connectedToNetwork
{

	//Create zero addy
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	
	//Recover reachability flags
	SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr*)&zeroAddress);
	SCNetworkReachabilityFlags flags;
	
	BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
	CFRelease(defaultRouteReachability);
	
	if (!didRetrieveFlags) {
		printf("Error. Could not recover network reachability flags\n");
		return 0;
	}
	
	BOOL isReachable = flags & kSCNetworkFlagsReachable;
	BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
	return (isReachable && !needsConnection) ? YES : NO;
}



-(IBAction)submitAllButtonPressed: (id)sender {
	
	if ([self connectedToNetwork]) {
		for (int i = 0; i<[app_delegate.totalDataGathered count]; i++) {
			//creating the data we actually want to upload
			NSString *pleasepleaseplease = [[app_delegate.totalDataGathered objectAtIndex:i] JSONRepresentation];
			NSString *paramDataString = [NSString stringWithFormat:@"entry=%@", pleasepleaseplease];
			NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
			NSLog(@"this is the log: %@", paramDataString);
			
			//connecting to the internet
			NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
			[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_entry"]];
			[request setHTTPMethod:@"POST"];
			[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
			[request setHTTPBody: paramData];
			
			NSURLResponse *urlResponse;	
			NSError *error;
			NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
			if(!data) {
				NSLog(@"%@", [error localizedDescription]);
			}
			NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
			NSLog(@"made it to end of addLog");
			//NSLog(@"%@", urlResponse);
			//NSLog(@"%@", data);
			//NSLog(@"%@", tData);
			[tData release];
			[request release];
			
			
		}
		//app_delegate.flickrContext = [[OFFlickrAPIContext alloc] initWithAPIKey:kOBJECTIVE_FLICKR_SAMPLE_API_KEY sharedSecret:kOBJECTIVE_FLICKR_SAMPLE_API_SHARED_SECRET];
		
		if ([[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext.authToken length]<1) {
			[self authorizeAction];
		}
		NSString *authToken;
		if (authToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"FlickrAuthToken"]) {
			app_delegate.flickrContext.authToken = authToken;
		}
		
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:app_delegate.flickrContext];
		flickrRequest.delegate = self;
		flickrRequest.requestTimeoutInterval = 60.0;
		
		NSLog(@"going to upload all pics");
		NSLog(@"%d", [app_delegate.pics count]);
		int count = 0;
		for (int i = 0; i<[app_delegate.pics count]; i++) {
			[self performSelector: @selector(_startUpload:) withObject:[NSNumber numberWithInt:i] afterDelay:5.0+10.0*i];
			count++;
		}
		
		NSLog(@"going to upload all of the pics and info from the survey");
		for (int i = 0; i<[app_delegate.totalSurveyInfo count]; i++) {
			[self performSelector:@selector(_startUploadRevised:) withObject: [NSNumber numberWithInt:i] afterDelay:5.0+10.0*count];
			count++;
		}
		//some last-minute setup-type stuff
		[submitAllButton setHidden:YES];
		//[app_delegate.totalData release];
		app_delegate.totalDataGathered = [[NSMutableArray alloc] init];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success!" 
														message:@"Your data has uploaded.  Please leave the app running so that the pictures can finish uploading." 
													   delegate:nil 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles:nil];
		[alert show];
		[alert release];
		
	}else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No WiFi!" 
														message:@"Seems like there is no internet. Try again when you see that you have wifi." 
													   delegate:nil 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles:nil];
		[alert show]; 
		[alert release];
	}

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	
	if (buttonIndex ==0) {
		NSString *temp = @"";
		
		temp = [[alertView textField] text];
		NSLog(@"testing name: %@", temp);
		
		[app_delegate.studentNames addObject:temp];
		[self.namesView reloadData];
		
		ZXingWidgetController *widController = [[ZXingWidgetController alloc] initWithDelegate:self showCancel:YES OneDMode:NO];
		QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
		NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
		[qrcodeReader release];
		widController.readers = readers;
		[readers release];
		NSBundle *mainBundle = [NSBundle mainBundle];
		widController.soundToPlay =
		[NSURL fileURLWithPath:[mainBundle pathForResource:@"beep-beep" ofType:@"aiff"] isDirectory:NO];
		resultsView.text = resultsToDisplay;
		[self presentModalViewController:widController animated:YES];
		[widController release];
	}
	

}

-(IBAction)addNewButtonPressed: (id)sender{
	//trying a sign in alert
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle: @"First time?"
						  message: @"What's your name?"
						  delegate:self
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:@"Cancel",nil];
	
	[alert addTextFieldWithValue:@"" label:@"Name"];

	//name field
	UITextField *tf = [alert textFieldAtIndex:0];
	tf.clearButtonMode = UITextFieldViewModeWhileEditing;
	tf.keyboardType = UIKeyboardTypeAlphabet;
	tf.keyboardAppearance = UIKeyboardAppearanceAlert;
	tf.autocapitalizationType = UITextAutocapitalizationTypeWords;
	tf.autocorrectionType = UITextAutocorrectionTypeNo;
	
	[alert show];
}




//ZXing
#pragma mark -
#pragma mark ZXing & DelegateMethods

- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)result {
	NSLog(@"scanned result");
	self.resultsToDisplay = result;
	
		NSLog(@"in outer if");
		if ([app_delegate.plant_info valueForKey:result]!=NULL) {
			
			[app_delegate.newEntryData setObject:result forKey:@"commonName"];

			addNew = [[AddNewEntry alloc] initWithNibName:@"AddNewEntry" bundle:nil];
			app_delegate.currentPlant = result;
			addNew.nameForLoad = studentName;
			NSLog(@"going to push: %@", studentName);
			[app_delegate.navigationController pushViewController:addNew animated:YES];
			
			
		}else {
			UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" 
														   message:@"The ID you entered doesn't exist in our database. Please check your entry and try again!" 
														  delegate:nil 
												 cancelButtonTitle:@"OK" 
												 otherButtonTitles:nil];
			[alert show];
		}
		//if we wanted to display some kind of confirmation label or something...
		[resultsView setText:resultsToDisplay];
		[resultsView setNeedsDisplay];
	//}
	[self dismissModalViewControllerAnimated:NO];
}

- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller {
	[self dismissModalViewControllerAnimated:NO];
}




#pragma mark -
#pragma mark Posting

- (NSString*)processLog {
	NSString *lprocessed = [NSString stringWithFormat:@"Log %@\n",[NSDate date]];
	for (int i = 0; i < [log_ count]; i++) {
		NSString *y = [[NSString alloc]init];
		y = [NSString stringWithFormat:@"%d: %@\n",i,[log_ objectAtIndex:i]];
		lprocessed = [lprocessed stringByAppendingString:y];
	}
	lprocessed = [lprocessed stringByAppendingString:@"\n"];
	return lprocessed;
}


//FFFFFIIIIIIIIXXXXXXX!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-(void)addLog {
	NSString *hmm = [self processLog];
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
	
	NSString *paramDataString = [NSString stringWithFormat:@"log=%@", hmm];
	NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
	
	NSLog(@"this is the log: %@", paramDataString);
	
	//[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~davistui/iPhone/add2.php"]];
	[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~hcilab/add.php"]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	[request setHTTPBody:paramData];
	
	NSURLResponse *urlResponse;	
	NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:nil];
	NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	

	//[tData release];
	//[hmm release];
	[request release];
	//[paramDataString release];
	//[paramData release];
	//[urlResponse release];
	//[data release];
}

-(void)updateLog:(NSString*)act {
	[self.log_ addObject:[NSDate date]];
	[self.log_ addObject:act];
	
}


#pragma mark OFFlickrAPIRequest delegate methods
- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	NSLog(@"Hi!");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inResponseDictionary);
    
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//snapPictureDescriptionLabel.text = @"Setting properties...";
		
        //NSLog(@"Hi 2");
        NSLog(@"%@", inResponseDictionary);
        NSString *photoID = [[inResponseDictionary valueForKeyPath:@"photoid"] textContent];
		
        flickrRequest.sessionInfo = @"kSetImagePropertiesStep";
        [flickrRequest callAPIMethodWithPOST:@"flickr.photos.setMeta" arguments:[NSDictionary dictionaryWithObjectsAndKeys:photoID, @"photo_id", @"Snap and Run", @"title", @"Uploaded from my iPhone/iPod Touch", @"description", nil]];        		        
	}
    else if ([inRequest.sessionInfo isEqualToString: @"kSetImagePropertiesStep"]) {
		//[self updateUserInterface:nil];		
		//snapPictureDescriptionLabel.text = @"Done";
        
		[UIApplication sharedApplication].idleTimerDisabled = NO;		
        
    }
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didFailWithError:(NSError *)inError
{
	NSLog(@"Hi 3");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inError);
	/*
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//[self updateUserInterface:nil];
		//snapPictureDescriptionLabel.text = @"Failed";		
		[UIApplication sharedApplication].idleTimerDisabled = NO;
		
		[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
		
	}
	else {
		[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
	}
	 */
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Flickr problem" 
													 message:@"Flickr is having technical difficulties, so your pictures were not uploaded.  All other information has been uploaded successfully." 
													delegate:nil 
										   cancelButtonTitle:@"OK" 
										   otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest imageUploadSentBytes:(NSUInteger)inSentBytes totalBytes:(NSUInteger)inTotalBytes
{
	if (inSentBytes == inTotalBytes) {
		//snapPictureDescriptionLabel.text = @"Waiting for Flickr...";
	}
	else {
		//snapPictureDescriptionLabel.text = [NSString stringWithFormat:@"%lu/%lu (KB)", inSentBytes / 1024, inTotalBytes / 1024];
	}
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	//return [[self.fetchedResultsController sections] count];
	return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
    //return [sectionInfo numberOfObjects];
	return [currentDataList count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	NSUInteger row = [indexPath row];

	NSString *name = [currentDataList objectAtIndex:row]; 
    cell.textLabel.text = name;
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
    return cell;
}



- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // The table view should not be re-orderable.
    return NO;
}





#pragma mark -
#pragma mark Table view delegate

// old method, pre ActionSheet addition...works great! kt
/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
	if (namesView.hidden == NO) {
		NSLog(@"current row selected %d", indexPath.row);
		NSString *ctitle = [currentDataList objectAtIndex:indexPath.row];
		studentName = ctitle;
		app_delegate.newEntryData = [[NSMutableDictionary alloc] init];
		[app_delegate.newEntryData setObject:ctitle forKey:@"user"];
		ZXingWidgetController *widController = [[ZXingWidgetController alloc] 
												initWithDelegate:self 
												showCancel:YES 
												OneDMode:NO];
		QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
		NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
		[qrcodeReader release];
		widController.readers = readers;
		[readers release];
		NSBundle *mainBundle = [NSBundle mainBundle];
		widController.soundToPlay =
		[NSURL fileURLWithPath:[mainBundle pathForResource:@"beep-beep" ofType:@"aiff"] isDirectory:NO];
		resultsView.text = resultsToDisplay;
		[self presentModalViewController:widController animated:YES];
		[widController release];
		
	}else {
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Not yet!" message:@"More information on collaboration coming soon!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}

	[tableView deselectRowAtIndexPath:indexPath animated:YES];

}*/ 

// new method using ActionSheet 06/08...tested, works! 
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *) indexPath {
	
	if (namesView.hidden == NO) {
		// gets name of student and saves
		NSLog(@"current row selected %d", indexPath.row);
		NSString *ctitle = [currentDataList objectAtIndex:indexPath.row];
		studentName = ctitle;
		app_delegate.studentName = studentName;
		app_delegate.newEntryData = [[NSMutableDictionary alloc] init];
		[app_delegate.newEntryData setObject:ctitle forKey:@"user"];
		
		//shows ActionSheet for user to choose what they would like to do
		UIActionSheet *actionSheet=[[UIActionSheet alloc]
									initWithTitle:@"What would you like to do?"
									delegate:self
									cancelButtonTitle:@"Cancel"
									destructiveButtonTitle:nil
									otherButtonTitles:@"Begin Bloom Survey", @"Individual Data", nil];
		// action sheet based of fb model
		[actionSheet showInView:self.view];
		[actionSheet release]; 
		
	} else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Not yet!" message:@"More information on collaboration coming soon!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
		
	}
	
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
}

// helper method 06/08...tested, works! 
-(void) actionSheet: (UIActionSheet *) actionSheet clickedButtonAtIndex: (NSInteger) buttonIndex {
	if(buttonIndex == 0) { //Bloom
		self.title = nil;
		NSLog(@"accessing bloom");
		//UIViewController *nextController = whereView; 
		whereView = [[Where alloc] initWithNibName:@"Where" bundle:nil];
		[app_delegate.navigationController pushViewController:whereView animated:YES]; 
	} else if (buttonIndex == 1) { // 1, Gather Data
		// code from other method....
		ZXingWidgetController *widController = [[ZXingWidgetController alloc] 
												initWithDelegate:self 
												showCancel:YES 
												OneDMode:NO];
		QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
		NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
		[qrcodeReader release];
		widController.readers = readers;
		[readers release];
		NSBundle *mainBundle = [NSBundle mainBundle];
		widController.soundToPlay =
		[NSURL fileURLWithPath:[mainBundle pathForResource:@"beep-beep" ofType:@"aiff"] isDirectory:NO];
		resultsView.text = resultsToDisplay;
		[self presentModalViewController:widController animated:YES];
		[widController release];
		} else { // must be cancel button
			// do nothing??
		}
	
}








#pragma mark -
#pragma mark Fetched results controller


/*
- (NSFetchedResultsController *)fetchedResultsController {
    
    if (fetchedResultsController_ != nil) {
        return fetchedResultsController_;
    }
    
   
    // Create the fetch request for the entity.
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    // Edit the entity name as appropriate.
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    
    // Set the batch size to a suitable number.
    [fetchRequest setFetchBatchSize:20];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"timeStamp" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    // Edit the section name key path and cache name if appropriate.
    // nil for section name key path means "no sections".
    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:@"Root"];
    aFetchedResultsController.delegate = self;
    self.fetchedResultsController = aFetchedResultsController;
    
    [aFetchedResultsController release];
    [fetchRequest release];
    [sortDescriptor release];
    [sortDescriptors release];
    
    NSError *error = nil;
    if (![fetchedResultsController_ performFetch:&error]) {
       
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    //return fetchedResultsController_;
}    
*/

#pragma mark -
#pragma mark Fetched results controller delegate
/*

- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    [self.tableView beginUpdates];
}


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath {
    
    UITableView *tableView = self.tableView;
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
            
        case NSFetchedResultsChangeMove:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath]withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    [self.tableView endUpdates];
}
 [self.view addSubview:anm.view];

*/
/*
// Implementing the above methods to update the table view in response to individual changes may have performance implications if a large number of changes are made simultaneously. If this proves to be an issue, you can instead just implement controllerDidChangeContent: which notifies the delegate that all section and object changes have been processed. 
 
 - (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // In the simplest, most efficient, case, reload the table view.
    [self.tableView reloadData];
}
 */


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}


- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	//[fetchedResultsController_ release];
    //[managedObjectContext_ release];
    [super dealloc];
}


@end

