//
//  Comments.h
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FlowerPowerNavBAppDelegate;

@interface Comments : UIViewController {

	FlowerPowerNavBAppDelegate *app_delegate;
	
	IBOutlet UITextView *tf;
	IBOutlet UITextView *tf2;
	IBOutlet UIScrollView *sview;
}

@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UITextView *tf;
@property (nonatomic, retain) IBOutlet UITextView *tf2;
@property (nonatomic, retain) IBOutlet UIScrollView *sview;
-(IBAction) keyboardButtonPressed: (id) sender;

@end
