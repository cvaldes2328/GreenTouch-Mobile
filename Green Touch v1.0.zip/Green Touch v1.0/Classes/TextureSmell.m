//
//  TextureSmell.m
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "TextureSmell.h"
#import "FlowerPowerNavBAppDelegate.h"

@implementation TextureSmell

@synthesize smell,flowerView, segControl, leafView, app_delegate, floweranswersSelected, leafSmellanswersSelected, leafTextureanswersSelected; 

-(IBAction) backButtonPressed: (id)sender {
	//[((FlowerPowerAppDelegate *)[[UIApplication sharedApplication] delegate]).viewController.view 
	[self.view removeFromSuperview];
}

-(IBAction) keyboardButtonPressed: (id)sender {
	[flowerView setContentOffset:CGPointZero animated:YES];
	[smell resignFirstResponder];
}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
	[flowerView setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 120) animated:YES];	
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[smell resignFirstResponder];
	[flowerView setContentOffset:CGPointZero animated:YES];
	NSString *otherEntered = [NSString stringWithFormat:@"Leaf: %@", textField.text];
	//do something with title
	//[answersSelected addObject:otherEntered];
	return YES;
}

-(IBAction) viewChanged: (id)sender{
	switch (segControl.selectedSegmentIndex) {
		case 0:
			[flowerView setHidden:NO];
			[leafView setHidden:YES];
			break;
		case 1:
			[flowerView setHidden:YES];
			[leafView setHidden:NO];
			break;
		default:
			break;
	}
	
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	floweranswersSelected = [[NSMutableArray alloc]init];
	leafTextureanswersSelected = [[NSMutableArray alloc] init];
	leafSmellanswersSelected = [[NSMutableArray alloc] init];
	
	//[flowerView setContentSize: CGSizeMake(320, 1000)];
	self.title = [NSString stringWithFormat:@"Texture & Smell"];
	smell.delegate = self;
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	[segControl setFrame:
     CGRectMake(segControl.frame.origin.x,
				segControl.frame.origin.y,
				segControl.frame.size.width, 
				segControl.frame.size.height*1.4)];
	
    [super viewDidLoad];
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");
	//NSDictionary *allanswersforappdelegate = [NSDictionary dictionaryWithObjectsAndKeys:
								// answersSelected, @"animalEvidence",
								 //nil];
	//NSMutableDictionary *allanswersforappdelegate = [[NSMutableDictionary alloc] init];
	//[allanswersforappdelegate setObject:answersSelected forKey:@"\"animalEvidence\""];
	//NSLog(@"%@", answersSelected);
	//NSLog(@"%@", allanswersforappdelegate);
	[app_delegate.newEntryData setObject:leafTextureanswersSelected forKey:@"leafTexture"];
	[app_delegate.newEntryData setObject:leafSmellanswersSelected forKey:@"leafSmell"];
	[app_delegate.newEntryData setObject:floweranswersSelected forKey:@"flowerSmell"];
	NSLog(@"set object");
	//NSLog(@"here's the value: %@", answersSelected);
	[smell resignFirstResponder];
	//NSLog(@"resigned first responder");
	[super viewWillDisappear:animated];
}

//update data from here
- (IBAction) checkboxSelectedLeafTexture:(id)sender{
	if ([sender isSelected]) {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Leaf: %@", button.currentTitle];
		//do something with title
		[leafTextureanswersSelected removeObject:buttonTitle];
		UIImage *unselectedImage = [UIImage imageNamed:@"checkbox.png"];
		[sender setImage:unselectedImage forState:UIControlStateNormal];
		[sender setSelected:NO];
	}else {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Leaf: %@", button.currentTitle];
		NSLog(@"%@",buttonTitle);
		//do something with title
		[leafTextureanswersSelected addObject:buttonTitle];
		UIImage *selectedImage = [UIImage imageNamed:@"checkbox-checked.png"];
		[sender setImage:selectedImage forState:UIControlStateSelected];
		[sender setSelected:YES];
	}
	
	
}

- (IBAction) checkboxSelectedLeafSmell:(id)sender{
	if ([sender isSelected]) {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Leaf: %@", button.currentTitle];
		//do something with title
		[leafSmellanswersSelected removeObject:buttonTitle];
		UIImage *unselectedImage = [UIImage imageNamed:@"checkbox.png"];
		[sender setImage:unselectedImage forState:UIControlStateNormal];
		[sender setSelected:NO];
	}else {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Leaf: %@", button.currentTitle];
		NSLog(@"%@",buttonTitle);
		//do something with title
		[leafSmellanswersSelected addObject:buttonTitle];
		UIImage *selectedImage = [UIImage imageNamed:@"checkbox-checked.png"];
		[sender setImage:selectedImage forState:UIControlStateSelected];
		[sender setSelected:YES];
	}
	
	
}

//update data from here
- (IBAction) checkboxSelectedFlower:(id)sender{
	if ([sender isSelected]) {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Flower: %@", button.currentTitle];
		//do something with title
		[floweranswersSelected removeObject:buttonTitle];
		UIImage *unselectedImage = [UIImage imageNamed:@"checkbox.png"];
		[sender setImage:unselectedImage forState:UIControlStateNormal];
		[sender setSelected:NO];
	}else {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//NSString *buttonTitle = [NSString stringWithFormat:@"Flower: %@", button.currentTitle];
		NSLog(@"%@",buttonTitle);
		//do something with title
		[floweranswersSelected addObject:buttonTitle];
		UIImage *selectedImage = [UIImage imageNamed:@"checkbox-checked.png"];
		[sender setImage:selectedImage forState:UIControlStateSelected];
		[sender setSelected:YES];
	}
	
	
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
