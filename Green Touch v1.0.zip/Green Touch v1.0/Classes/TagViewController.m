//
//  TagViewController.m
//  ArtExplo
//
//  Created by HCI Lab on 7/2/10.
//  Copyright 2010 Wellesley College. All rights reserved.
//
//	Based on Lia Napolitano's Davis-FX project. Specifically, the MultipleChoiceVC.m class.
//


#import "TagViewController.h"
#import "FlowerPowerNavBAppDelegate.h"

@implementation TagViewController

@synthesize backgroundButton, text_field, questions_scroll_view,work,r,labelText, app_delegate, otherScrollView, viewHere;

@synthesize question,answers,bg, answer, minorButton, significant, severe, minorLabel, significantLabel, severeLabel;
@synthesize pictures, selectedType/*pictureImageViews*/;

//camera buttons
@synthesize animalOnLeaf, animalOnStem, animalOnFlower, holes, damageToleaf;



-(IBAction) backButtonPressed: (id)sender {
	//[((FlowerPowerAppDelegate *)[[UIApplication sharedApplication] delegate]).viewController.view 
	[self.view removeFromSuperview];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	self.title = [NSString stringWithFormat:@"Animal Evidence"];

	was_answered = NO;
	answer = [[NSMutableArray alloc] init];
	pictures = [[NSMutableArray alloc] init];
	//pictureImageViews = [[NSMutableArray alloc] init];
			
	bg = [UIImage imageNamed:@"ButtonBack3.png"];
	
	text_field.delegate = self;
    [super viewDidLoad];
}

-(void) viewWillDisappear:(BOOL)animated {
	
	[text_field resignFirstResponder];

	[self resizeRestore];
		
	[app_delegate.newEntryData setObject:answer forKey:@"animalEvidence"];
	
	[super viewWillDisappear:animated];
}

-(IBAction) buttonPressed: (id)sender {
	//UIButton *button = (UIButton *)sender;

	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}

	[self presentModalViewController:imagePicker animated:YES];
}

#pragma mark KeyboardStuff
- (void)resizeRestore {
	[text_field resignFirstResponder];
	[otherScrollView setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[text_field resignFirstResponder];
	[self resizeRestore];
	if (!was_answered) {
		//app_delegate.number_of_questions_answered++;
		was_answered = YES;
	}
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", textField.text]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
	[otherScrollView setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 120) animated:YES];	
}

- (IBAction) backgroundButton: (id)sender
{
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", text_field.text]];
	[text_field resignFirstResponder];
	[self resizeRestore];
}




#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
{
    NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
    
	snapPictureButton.enabled = NO;
	snapPictureDescriptionLabel.text = @"Uploading";
	
    self.flickrRequest.sessionInfo = kUploadImageStep;
    [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
	NSLog(@"upload?");
	[UIApplication sharedApplication].idleTimerDisabled = YES;
	[self updateUserInterface:nil];
}
*/
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		[viewHere setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		[pictures addObject:[[NSArray alloc] initWithObjects: image, selectedType, nil]];
		UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
		[self.questions_scroll_view addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
	

//update data from here
- (IBAction) checkboxSelected:(id)sender{
	if ([sender isSelected]) {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		//do something with title
		[answer removeObject:buttonTitle];
		//[answer removeObject:[NSString stringWithFormat:@"Minor %@", buttonTitle]];
		//[answer removeObject:[NSString stringWithFormat:@"Significant %@", buttonTitle]];
		//[answer removeObject:[NSString stringWithFormat:@"Severe %@", buttonTitle]];
		UIImage *unselectedImage = [UIImage imageNamed:@"checkbox.png"];
		[sender setImage:unselectedImage forState:UIControlStateNormal];
		[sender setSelected:NO];
		
		if ([buttonTitle isEqualToString: @"  Animal(s) currently on leaf or stem"]) {
			animalOnLeaf.hidden = YES;
		}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on stem"]) {
			animalOnStem.hidden = YES;
		}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on flower"]) {
			animalOnFlower.hidden = YES;
		}else if ([buttonTitle isEqualToString: @"  Holes in leaf or flower"]) {
			holes.hidden = YES;
			minorButton.hidden = YES;
			significant.hidden = YES;
			severe.hidden = YES;
			minorLabel.hidden = YES;
			significantLabel.hidden = YES;
			severeLabel.hidden = YES;
			
		}else if ([buttonTitle isEqualToString: @"  Damage to edge of leaf"]) {
			damageToleaf.hidden = YES;
		}

	}else {
		UIButton *button = (UIButton *)sender; 
		NSString *buttonTitle = button.currentTitle;
		if([buttonTitle isEqualToString:@"Holes in leaf or flower"]) {
			if([minorButton isSelected])
				buttonTitle = [@"Minor " stringByAppendingString:buttonTitle];
			else if ([significant isSelected])
				buttonTitle = [@"Significant " stringByAppendingString:buttonTitle];
			else if ([severe isSelected])
				buttonTitle = [@"Severe " stringByAppendingString:buttonTitle];
		}
		[answer addObject:[[NSDictionary alloc] initWithObjectsAndKeys:buttonTitle, @"description", @"no picture", @"photo", nil]];
		UIImage *selectedImage = [UIImage imageNamed:@"checkbox-checked.png"];
		[sender setImage:selectedImage forState:UIControlStateSelected];
		[sender setSelected:YES];
		
		if ([buttonTitle isEqualToString: @"  Animal(s) currently on leaf or stem"]) {
			animalOnLeaf.hidden = NO;
		}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on stem"]) {
			animalOnStem.hidden = NO;
		}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on flower"]) {
			animalOnFlower.hidden = NO;
		}else if ([buttonTitle isEqualToString: @"  Holes in leaf or flower"]) {
			holes.hidden = NO;
			minorButton.hidden = NO;
			significant.hidden = NO;
			severe.hidden = NO;
			minorLabel.hidden = NO;
			significantLabel.hidden = NO;
			severeLabel.hidden = NO;
		}else if ([buttonTitle isEqualToString: @"  Damage to edge of leaf"]) {
			damageToleaf.hidden = NO;
		}		
	}
	
	
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	[pictures release];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [answer release];
	
	[super dealloc];
}


@end
