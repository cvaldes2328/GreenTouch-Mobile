//
//  RootViewController.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/18/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "FlowerPowerNavBAppDelegate.h"
#import "AddNewEntry.h"
#import "Where.h"

@class FlowerPowerNavBAppDelegate;

@interface RootViewController : UIViewController  <UIActionSheetDelegate, OFFlickrAPIRequestDelegate>{

	FlowerPowerNavBAppDelegate *app_delegate;

	UITableView *surfaceView;
	UITableView *namesView;
	IBOutlet UIView *scanView;
	IBOutlet UIView *specimenView;
	IBOutlet UILabel *dateLabel;
	
	OFFlickrAPIRequest *flickrRequest;
	
	IBOutlet UIButton *addNewNameButton;
	IBOutlet UIButton *submitAllButton;
	UISegmentedControl *segControl;

	AddNewEntry *addNew;
	Where *whereView; 
	
	NSArray *currentDataList;
	NSArray *plantNames;
	NSDictionary *plantInfo;
	NSArray *studentNamesTemp;
	NSString *studentName;
	
	//Log
	NSMutableDictionary *stream_;
	NSMutableArray *log_;
	
	
	//ZXing
	IBOutlet UILabel *resultsView;
	NSString *resultsToDisplay;
	

}



@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UITableView *surfaceView;
@property (nonatomic, retain) IBOutlet UITableView *namesView;

@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;

@property (nonatomic, retain) IBOutlet UIView *scanView;
@property (nonatomic, retain) IBOutlet UIView *specimenView;
@property (nonatomic, retain) IBOutlet UILabel *dateLabel;
@property (nonatomic, retain) NSString *studentName;

@property (nonatomic, retain) IBOutlet UISegmentedControl *segControl;
@property (nonatomic, retain) IBOutlet UIButton *submitAllButton;

@property (nonatomic, retain) AddNewEntry *addNew;
@property (nonatomic, retain) Where *whereView; 

@property (nonatomic, retain) NSArray *currentDataList;
@property (nonatomic, retain) NSArray *plantNames;
@property (nonatomic, retain) NSDictionary *plantInfo;
@property (nonatomic, retain) NSArray *studentNamesTemp;


//Log
@property (nonatomic, retain) NSMutableDictionary *stream_;
@property (nonatomic, retain) NSMutableArray *log_;

//ZXing-------------------------------------------------------------
@property (nonatomic, retain) IBOutlet UILabel *resultsView;
@property (nonatomic, copy) NSString *resultsToDisplay;

-(IBAction)addNewButtonPressed: (id)sender;
//-(IBAction)logTestButtonPressed: (id)sender;
-(IBAction) viewChanged: (id)sender;
-(IBAction)submitAllButtonPressed: (id)sender;
- (void)_startUpload:(NSNumber *)image;
- (void)_startUploadRevised:(NSNumber *)image;
- (void)_startUploadThree:(NSArray *)args;


@end
