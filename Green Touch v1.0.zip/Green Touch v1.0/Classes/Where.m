//
//  Where.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/7/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "Where.h"

#import "FlowerPowerNavBAppDelegate.h"


@implementation Where
@synthesize picker, button, text, array, photoView, bloomView, app_delegate; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[picker setDelegate:self]; 
	[picker setDataSource:self];
	
	//app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	
	array = [[NSArray alloc] initWithObjects:@"Alexandra Botanic Garden",
					  @"Arboretum", @"Edible Ecosystem", @"Educational Garden", @"Student Farm",
					  @"Elsewhere", nil]; 
	
	[text setFont:[UIFont fontWithName:@"Helvetica" size:28.0]];
	self.title = @"Location";
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


//picker stuff
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}

// when button pressed, go to pictures page
-(IBAction) buttonPressed: (id) sender {
	
	//NSLog(@"The button is being pressed...");
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	bloomView = [[SurveyGallery alloc] initWithNibName:@"SurveyGallery" bundle:nil];
	photoView = [[Photo alloc] initWithNibName:@"Photo" bundle:nil];
	photoView.surveyGallery = bloomView;
	bloomView.currentInfo = [[NSMutableString alloc] initWithString:[[array objectAtIndex:[picker selectedRowInComponent:0]] stringByReplacingOccurrencesOfString:@" " withString:@""]];
	[bloomView.currentInfo appendString:@" "];
	[bloomView.currentInfo appendString:(app_delegate.studentName)];
	app_delegate.totalSurveyInfo = [[NSMutableArray alloc] init];
	app_delegate.totalSurveyPics = [[NSMutableArray alloc] init];
	[app_delegate.navigationController popViewControllerAnimated:NO]; 
	[app_delegate.navigationController pushViewController:bloomView animated:NO]; //push menu
	[app_delegate.navigationController pushViewController:photoView animated:YES]; //push where
	
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
