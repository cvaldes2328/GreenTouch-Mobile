//
//  Sketches.h
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ObjectiveFlickr.h"

@interface Sketches : UIViewController <OFFlickrAPIRequestDelegate> {

	UIImage *pic;
}

@property (nonatomic, retain) UIImage *pic;

-(IBAction) backButtonPressed:(id)sender;
-(IBAction) cameraButtonPressed: (id) sender;

- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken;

- (IBAction)cancelAction;

@end
