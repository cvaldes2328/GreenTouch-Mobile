//
//  FlowerPowerNavBAppDelegate.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/18/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

//from snap&run app
#import "ObjectiveFlickr.h"

#define knamesFilename        @"names.plist"
#define kdataFilename        @"dataGathered.plist"

@class PaintingWindow;

extern NSString *SnapAndRunShouldUpdateAuthInfoNotification;

@interface FlowerPowerNavBAppDelegate : NSObject <UIApplicationDelegate, OFFlickrAPIRequestDelegate> {
    
    //UIWindow *window;
	PaintingWindow *window;
    UINavigationController *navigationController;
	
	NSDictionary *plant_info;
	NSMutableArray *studentNames;
	NSString *studentName;
	NSString *currentPlant;
	
	NSMutableDictionary *newEntryData;
	NSMutableArray *totalDataGathered;
	NSMutableArray *totalSurveyPics;
	NSMutableArray *totalSurveyInfo;
	
	NSMutableArray *pics;
	NSMutableArray *picPlants;
	
	//fromS&R
	UIActivityIndicatorView *activityIndicator;
	UIView *progressView;
	//UIButton *cancelButton;
	//UILabel *progressDescription;
    
    OFFlickrAPIContext *flickrContext;
	OFFlickrAPIRequest *flickrRequest;
	//NSString *flickrUserName;
	

@private
    NSManagedObjectContext *managedObjectContext_;
    NSManagedObjectModel *managedObjectModel_;
    NSPersistentStoreCoordinator *persistentStoreCoordinator_;
}

//@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet PaintingWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) NSMutableArray *totalSurveyPics;
@property (nonatomic, retain) NSMutableArray *totalSurveyInfo;

@property (nonatomic, retain) NSDictionary *plant_info;
@property (nonatomic, retain) NSMutableArray *studentNames;
@property (nonatomic, retain) NSString *currentPlant;
@property (nonatomic, retain) NSString *studentName;
@property (nonatomic, retain, readwrite) NSMutableDictionary *newEntryData;
@property (nonatomic, retain, readwrite) NSMutableArray *totalDataGathered;
@property (nonatomic, retain, readwrite) NSMutableArray *pics;
@property (nonatomic, retain, readwrite) NSMutableArray *picPlants;


@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

//From S&R
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain) IBOutlet UIView *progressView;
//@property (nonatomic, retain) IBOutlet UIButton *cancelButton;
//@property (nonatomic, retain) IBOutlet UILabel *progressDescription;

@property (nonatomic, retain, readonly) OFFlickrAPIContext *flickrContext;
//@property (nonatomic, retain) NSString *flickrUserName;

//mine
- (NSURL *)applicationDocumentsDirectory;
- (void)saveContext;

//from SNR
- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken;
+ (FlowerPowerNavBAppDelegate *)sharedDelegate;

- (IBAction)cancelAction;



@end

