//
//  SurveyGallery.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/9/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "SurveyGallery.h"
#import "FlowerPowerNavBAppDelegate.h"
#import "Photo.h"

@implementation SurveyGallery

@synthesize menuButton, addNewButton, views, galleryView, info, currentInfo, app_delegate, numberOfPlants; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	//views = [[NSMutableArray alloc] init];
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	//currentInfo = app_delegate.studentName;
	info = [[NSMutableArray alloc] init];
	self.title = @"Gallery";
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

-(void) viewWillAppear:(BOOL)animated {
	NSLog(@"%@", views);
	[self addNewPicture];
	[self.view setNeedsDisplay];
	[super viewWillAppear:animated];
}
#pragma mark Picture Adding

-(void) addNewPicture{
	UIImageView *magicview = [[UIImageView alloc] initWithImage:[[views objectAtIndex:([views count]-1)] objectAtIndex:0]];
	magicview.backgroundColor = [UIColor grayColor];
	magicview.frame = CGRectMake( 10 + 50*(([views count]-1)%5),10 + 70*(([views count]-1)/5), 40, 60);
	//[views addObject:pictures];
	[info addObject:currentInfo];
	[self.galleryView addSubview:magicview];
	NSLog(@"Added picture");
	NSLog(@"Total info is %@", info);
}

/*-(NSMutableArray *) views {
	if(!self.views)
		views = [[NSMutableArray alloc] init];
	return self.views;
}
 */
#pragma mark button methods
-(IBAction) addButtonPressed: (id) sender {
	
	//FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	Photo *photoView = [[Photo alloc] initWithNibName:@"Photo" bundle:nil];
	photoView.surveyGallery = self;
	NSString *where = [[currentInfo componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] objectAtIndex:0];
	currentInfo = [[NSMutableString alloc] initWithString:where];
	[currentInfo appendFormat:@" %@", app_delegate.studentName];
	[app_delegate.navigationController pushViewController:photoView animated:YES]; //push where
	
	
}

// return to AddNewEntry????
-(IBAction) menuButtonPressed: (id) sender {
	//FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	NSLog(@"Adding %d pictures", [views count]);
	if (views) {
		[app_delegate.totalSurveyPics addObject:views];
		[app_delegate.totalSurveyInfo addObject:info];
	}
	[app_delegate.navigationController popViewControllerAnimated:YES]; 
	//NSLog(@"l;h");
	
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
