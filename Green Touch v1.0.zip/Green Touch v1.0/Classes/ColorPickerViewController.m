//
//  ColorPickerViewController.m
//  ColorPicker
//
//  Created by markj on 3/6/09.
//  Copyright Mark Johnson 2009. All rights reserved.
//

#import "ColorPickerViewController.h"
#import "FlowerPowerNavBAppDelegate.h"
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/CoreAnimation.h>


@implementation ColorPickerViewController

@synthesize colorWheel, greenColorWheel;
@synthesize tapMeButton;
@synthesize work,current,label,labelText;
@synthesize question,inputAmount, color1,color2,color3,colorcurrent;
@synthesize color1_selector, color2_selector, color3_selector;



-(IBAction) backButtonPressed: (id)sender {
	//[((FlowerPowerAppDelegate *)[[UIApplication sharedApplication] delegate]).viewController.view 
	[self.view removeFromSuperview];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	self.title = [NSString stringWithFormat:@"Colors Observed"];
	
    //NSLog(@"loaded color picker");
	//[self animateColorWheelToShow:NO duration:0];
	
	colorWheel.pickedColorDelegate = self;
	greenColorWheel.pickedColorDelegate = self;
	[greenColorWheel setHidden:YES];

	
	colorcurrent = color1;
	
	//NSLog(@"color question: %@", question);
	
	NSArray *c = [work valueForKey:@"color"];
	current = [c objectAtIndex:0];
	//label.text = self.question;
	
	//appDelegate = (ArtExploAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	[super viewDidLoad];
}

/*- (NSString*)hexColor {
	//NSColor* col = [self colorUsingColorSpaceName:NSCalibratedRGBColorSpace];
	return [NSString stringWithFormat:@"#%0.2X%0.2X%0.2X",
			(int)([color1 redComponent] * 255),
			(int)([color1 greenComponent] * 255),
			(int)([color1 blueComponent] * 255)];
}
 NSString *color1String = [NSString stringWithFormat:@"#%0.2X%0.2X%0.2X",
 ((int)[color1.backgroundColor redComponent]) * 255,
 ((int)[color1.backgroundColor greenComponent]) * 255,
 ((int)[color1.backgroundColor blueComponent]) * 255];
 NSLog(@"color1: %@", color1String);
 NSString *color2String = [NSString stringWithFormat:@"#%0.2X%0.2X%0.2X",
 ((int)[color2.backgroundColor redComponent]) * 255,
 ((int)[color2.backgroundColor greenComponent]) * 255,
 ((int)[color2.backgroundColor blueComponent]) * 255];
 NSString *color3String = [NSString stringWithFormat:@"#%0.2X%0.2X%0.2X",
 ((int)[color3.backgroundColor redComponent]) * 255,
 ((int)[color3.backgroundColor greenComponent]) * 255,
 ((int)[color3.backgroundColor blueComponent]) * 255];
 
 
 */


-(void) viewWillDisappear:(BOOL)animated {

	//[NSString stringWithFormat:	@"bgcolor=#%02x%02x%02x",[color redComponent], [color greenComponent], [color blueComponent]];
	//NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:
							  //color1.backgroundColor, @"flowers",
							  //color2.backgroundColor, @"stem",
							  //color3.backgroundColor, @"leaves",
							  //nil];
	UIColor *one = color1.backgroundColor;
	UIColor *two = color2.backgroundColor;
	UIColor *three = color3.backgroundColor;
	
	//NSMutableDictionary *tempDict = [[NSDictionary alloc] init];
	NSString *string1;
	NSString *string2;
	NSString *string3;
	
	//color1
	const CGFloat *components = CGColorGetComponents(one.CGColor);
	//NSLog(@"%f, %f, %f, %f", components[0],components[1],components[2],components[3]);
	//NSLog(@"%X, %X, %X, %X", (char)(255*components[0]), (char)(255*components[1]), (char)(255*components[2]), (char)(255*components[3]));
	NSLog(@"%f", components);
	
	string1 = [NSString stringWithFormat:@"%qX%qX%qX", (int)(255*components[0]), (int)(255*components[1]), (int)(255*components[2])];
	unsigned int i1 = ( unsigned int)(255*components[0]);
	unsigned int i2 = (unsigned int)(255*components[1]);
	unsigned int i3 = (unsigned int)(255*components[2]);
	string1 = [NSString stringWithFormat:@"%x%x%x%x%x%x", i1/16, i1 % 16, i2/16, i2%16, i3/16, i3%16];
	unsigned int int1;
	NSScanner *scanner1 = [NSScanner scannerWithString:string1];
	[scanner1 scanHexInt:&int1];
	//[tempDict setValue:string2 forKey: @"flowers"];
	
	
	
	//color2
	const CGFloat *components1 = CGColorGetComponents(two.CGColor);
	//NSLog(@"%f, %f, %f, %f", components1[0],components1[1],components1[2],components1[3]);
	//NSLog(@"%X, %X, %X, %X", (char)(255*components1[0]), (char)(255*components1[1]), (char)(255*components1[2]), (char)(255*components1[3]));

	i1 = ( unsigned int)(255*components1[0]);
	i2 = (unsigned int)(255*components1[1]);
	i3 = (unsigned int)(255*components1[2]);
	string2 = [NSString stringWithFormat:@"%x%x%x%x%x%x", i1/16, i1 % 16, i2/16, i2%16, i3/16, i3%16];
	unsigned int int2;
	NSScanner *scanner2 = [NSScanner scannerWithString:string2];
	[scanner2 scanHexInt:&int2];
	//[tempDict setValue:string2 forKey: @"stem"];

	
	//color3
	const CGFloat *components2 = CGColorGetComponents(three.CGColor);
	//NSLog(@"%f, %f, %f, %f", components2[0],components2[1],components2[2],components2[3]);
	//NSLog(@"%X, %X, %X, %X", (char)(255*components2[0]), (char)(255*components2[1]), (char)(255*components2[2]), (char)(255*components2[3]));
	NSLog(@"%f",components2[0]);
	string3 = [NSString stringWithFormat:@"%c%c%c", (int)(255*components2[0]), (int)(255*components2[1]), (int)(255*components2[2])];
	i1 = ( unsigned int)(255*components2[0]);
	i2 = (unsigned int)(255*components2[1]);
	i3 = (unsigned int)(255*components2[2]);
	string3 = [NSString stringWithFormat:@"%x%x%x%x%x%x", i1/16, i1 % 16, i2/16, i2%16, i3/16, i3%16];
	NSLog(@"float = %f", components2[0]*255);
	NSLog(@"char = %c", (char)components2[0]*255);
	NSLog(@" all three: %@ %@ %@", string1, string2, string3);
	unsigned int int3;
	NSScanner *scanner3 = [NSScanner scannerWithString:string3];
	[scanner3 scanHexInt:&int3];
	//[tempDict setValue:string2 forKey: @"leaves"];
	
	NSNumber *num1 = [NSNumber numberWithUnsignedInt:int1];
	NSNumber *num2 = [NSNumber numberWithUnsignedInt:int2];
	NSNumber *num3 = [NSNumber numberWithUnsignedInt:int3];
	NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:
							  num1, @"flowers",
							  num2, @"stem",
							  num3, @"leaves",
							  nil];
							  
	
	FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	[app_delegate.newEntryData setValue:tempDict forKey:@"colors"];
	NSLog(@"set object");
		 
	[super viewWillDisappear:animated];
}
- (IBAction) tapMe: (id)sender {
	[self animateColorWheelToShow:YES duration:0.1]; 
}

- (void) pickedColor:(UIColor*)color {
	//[self animateColorWheelToShow:NO duration:0.3]; 
	//self.view.backgroundColor = color;
	//[self.view setNeedsDisplay];
	//NSLog(@"called pickedColor");
	colorcurrent.backgroundColor = color;

}

- (void) animateColorWheelToShow:(BOOL)show duration:(NSTimeInterval)duration {
	int x;
	float angle;
	float scale;
	if (show==NO) { 
		x = -320;
		angle = -3.12;
		scale = 0.01;
		self.colorWheel.hidden=YES;
	} else {
		x=0;
		angle = 0;
		scale = 1;
		[self.colorWheel setNeedsDisplay];
		self.colorWheel.hidden=NO;
	}
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:duration];
	
	CATransform3D transform = CATransform3DMakeTranslation(0,0,0);
	transform = CATransform3DScale(transform, scale,scale,1);
	self.colorWheel.transform=CATransform3DGetAffineTransform(transform);
	self.colorWheel.layer.transform=transform;
	[UIView commitAnimations];
}


-(IBAction)selectView1 {
	NSLog(@"Flowers picked");
	color1_selector.hidden = NO;
	color2_selector.hidden = YES;
	color3_selector.hidden = YES;
	colorcurrent = color1;
		
}

-(IBAction)selectView2 {
		NSLog(@"Stem picked");
	color1_selector.hidden = YES;
	color2_selector.hidden = NO;
	color3_selector.hidden = YES;
	colorcurrent = color2;
}

-(IBAction)selectView3 {
		NSLog(@"Leaves picked");
	color1_selector.hidden = YES;
	color2_selector.hidden = YES;
	color3_selector.hidden = NO;
	colorcurrent = color3;
	
}


@end
