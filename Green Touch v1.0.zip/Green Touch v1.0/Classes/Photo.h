//
//  Photo.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/7/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HowMany.h"
#import "SurveyGallery.h"

@class FlowerPowerNavBAppDelegate;


@interface Photo : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>{

	FlowerPowerNavBAppDelegate *app_delegate;
	HowMany *howManyView; 
	SurveyGallery *surveyGallery;
	
	int plantType;
	
	UITextView *text; 
	
	UIButton *wholeButton; 
	UIButton *closeButton;
	UIButton *moreButton; 
	
	NSMutableArray *pictures; 
}
@property (nonatomic) int plantType;
@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) HowMany *howManyView; 
@property (nonatomic, retain) SurveyGallery *surveyGallery;

@property (nonatomic, retain) IBOutlet UITextView *text; 

@property (nonatomic, retain) IBOutlet UIButton *wholeButton; 
@property (nonatomic, retain) IBOutlet UIButton *closeButton; 
@property (nonatomic, retain) IBOutlet UIButton *moreButton; 
@property (nonatomic, retain) NSMutableArray *pictures; 

-(IBAction) buttonPressed: (id) sender; 
-(IBAction) wholePressed: (id) sender; 
-(IBAction) closePressed: (id) sender; 

@end
