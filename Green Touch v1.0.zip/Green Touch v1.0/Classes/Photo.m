//
//  Photo.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/7/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "Photo.h"
#import "FlowerPowerNavBAppDelegate.h"


@implementation Photo

@synthesize wholeButton, closeButton, moreButton, howManyView, text, app_delegate, plantType, surveyGallery, pictures;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	pictures = [[NSMutableArray alloc] init];
    [text setFont:[UIFont fontWithName:@"Helvetica" size:28]];
	self.title = @"Pictures";
	[super viewDidLoad];
}

-(void)viewWillDisappear:(BOOL)animated {
	//NSMutableArray *answersArray = [[NSMutableArray alloc] init];
	
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		//[pictures addObject:image];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		//newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
		//[self.questions_scroll_view addSubview:newView];
		switch (plantType) {
			case 0: //whole plant
				wholeButton.imageView.image = image;
				[wholeButton setImage:image forState:UIControlStateSelected];
				[wholeButton setImage:image forState:UIControlStateHighlighted];
				[wholeButton setImage:image forState:UIControlStateDisabled];
				[wholeButton setImage:image forState:UIControlStateNormal];
				break;
			case 1:
				closeButton.imageView.image = image;
				[closeButton setImage:image forState:UIControlStateNormal];
				[closeButton setImage:image forState:UIControlStateSelected];
				[closeButton setImage:image forState:UIControlStateHighlighted];
				[closeButton setImage:image forState:UIControlStateDisabled];
				break;
			case 2:
				//additional pictures, update if we ever add that function
				break;

			default:
				break;
		}
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
	
-(IBAction) wholePressed: (id) sender {
	plantType = 0;
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}
	
	[self presentModalViewController:imagePicker animated:YES];
}


-(IBAction) closePressed: (id) sender {
	plantType = 1;
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}
	
	[self presentModalViewController:imagePicker animated:YES];
}

-(IBAction) buttonPressed: (id) sender {
	
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	howManyView = [[HowMany alloc] initWithNibName:@"HowMany" bundle:nil];
	howManyView.surveyGallery = surveyGallery;
	[pictures addObject:closeButton.imageView.image];
	[pictures addObject:wholeButton.imageView.image];
	NSLog(@"%@", pictures);
	//if we make a small gallery, need to update this
	NSLog(@"Adding pictures");
	if(!surveyGallery.views) {
	surveyGallery.views = [[NSMutableArray alloc] initWithObjects:pictures, nil];
	} else {
		[surveyGallery.views addObject:pictures];
	}

	//[surveyGallery.views addObject:pictures];
	NSLog(@"%@", surveyGallery);
	NSLog(@"%@", surveyGallery.views);
	[app_delegate.navigationController pushViewController:howManyView animated:YES]; 
	
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
