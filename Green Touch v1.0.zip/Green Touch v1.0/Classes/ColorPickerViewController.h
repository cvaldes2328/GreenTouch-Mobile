//
//  ColorPickerViewController.h
//  ColorPicker
//
//  Created by markj on 3/6/09.
//  Copyright Mark Johnson 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ColorPickerImageView.h"



@interface ColorPickerViewController : UIViewController {
	IBOutlet ColorPickerImageView* colorWheel;
	IBOutlet ColorPickerImageView* greenColorWheel;

	IBOutlet UIButton* tapMeButton;
	
	
	NSString *question;
	int inputAmount;
	
	NSString *labelText;
	NSDictionary *work;
	NSDictionary *current;
	IBOutlet UILabel *label;
	
	IBOutlet UIView *color1;
	IBOutlet UIView *color2;
	IBOutlet UIView *color3;
	IBOutlet UIView	*colorcurrent;

	IBOutlet UIImageView *color1_selector;
	IBOutlet UIImageView *color2_selector;
	IBOutlet UIImageView *color3_selector;
	
}

@property (nonatomic, retain) ColorPickerImageView* colorWheel;
@property (nonatomic, retain) ColorPickerImageView* greenColorWheel;
@property (nonatomic, retain) UIButton* tapMeButton;

@property (nonatomic,retain) NSString *question;
@property (nonatomic) int inputAmount;
@property (nonatomic,retain) NSDictionary *work;
@property (nonatomic,retain) NSDictionary *current;
@property (nonatomic,retain) IBOutlet UILabel *label;
@property (nonatomic,retain) NSString *labelText;

@property (nonatomic,retain) IBOutlet UIView *color1;
@property (nonatomic,retain) IBOutlet UIView *color2;
@property (nonatomic,retain) IBOutlet UIView *color3;
@property (nonatomic,retain) IBOutlet UIView *colorcurrent;

@property (nonatomic,retain) IBOutlet UIImageView *color1_selector;
@property (nonatomic,retain) IBOutlet UIImageView *color2_selector;
@property (nonatomic,retain) IBOutlet UIImageView *color3_selector;

- (IBAction) tapMe: (id)sender;
- (void) pickedColor:(UIColor*)color;
- (void) animateColorWheelToShow:(BOOL)show duration:(NSTimeInterval)duration;
- (void)getRidOfKeyboardFromQuestionsView;

- (IBAction)selectView1;
- (IBAction)selectView2;
- (IBAction)selectView3;

-(IBAction) backButtonPressed: (id)sender;

@end

