//
//  ThirdTrySize.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/25/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "ThirdTrySize.h"
#import "FlowerPowerNavBAppDelegate.h"

@implementation ThirdTrySize
@synthesize segControl, view1, view2, view3, picker1, picker2, picker3, text1, text2, text3, array1, array2, array3, label1, label2, label3;
@synthesize app_delegate;


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	self.title = [NSString stringWithFormat:@"Spring Phenology"];
	
	NSArray *array = [[NSArray alloc] initWithObjects:@"Bud dormant", 
			  @"Bud expanded", @"Leaf < 0.5cm long", @"Leaf between 1 and 2cm",
			  @"Leaf between 2 and 4 cm", @"Leaf >4cm", nil];
	array1 = array;
	[text1 setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	text1.text =  @"What is the stage of the most advanced leaf you can see?";
	//firstDetail.array = 
	//firstDetail.labelString = @"What is the stage of the most advanced leaf you can see?";
	
	array = [[NSArray alloc] initWithObjects:@"None", @"Bud without color", @"Bud with color",
																		 @"In bloom", @"Post-bloom", nil];
	array2 = array;
	text2.text = @"What is the stage of the most advanced flower you can see?";
	[text2 setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	//secondDetail.array = [[NSArray alloc] initWithObjects:@"None", @"Bud without color", @"Bud with color",
	// @"In bloom", @"Flower past", nil];
	//secondDetail.labelString = @"What is 
	array = [[NSArray alloc] initWithObjects:@"None", @"Beginning (<10% blooming)",
			  @"Early (10-33%)", @"Peak (33-67%)", @"Late (few buds remaining)", @"Post-bloom", nil];
	array3 = array;
	text3.text = @"What is the overall stage of bloom?";
	[text3 setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	//NSLog(@"%@",[array3 objectAtIndex:1]);
	//segControl.selectedSegmentIndex = 2;
	
	[segControl setFrame:
     CGRectMake(segControl.frame.origin.x,
				segControl.frame.origin.y,
				segControl.frame.size.width, 
				segControl.frame.size.height*1.4)];
	
	[view2 setHidden:YES];
	[view3 setHidden:YES];
	
    [super viewDidLoad];
}

-(void) viewDidAppear {
	[picker1 selectRow:2 inComponent:0 animated:YES];
	[picker1 reloadComponent:0];
	
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");
	NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:
							  [NSNumber numberWithInt:[picker1 selectedRowInComponent:0]], @"leaf",
							  [NSNumber numberWithInt:[picker2 selectedRowInComponent:0]], @"flower",
							  [NSNumber numberWithInt:[picker3 selectedRowInComponent:0]], @"overall", nil];
	NSLog(@"Temp dict is %@", tempDict);
	//NSDictionary *allanswersforappdelegate = [NSDictionary dictionaryWithObjectsAndKeys:
											  //tempDict, @"phenology",
											  //nil];
	//NSLog(@"created dictionary");
	
	[app_delegate.newEntryData setValue:tempDict forKey:@"phenology"];
	//NSLog(@"set object");
	//NSLog(@"here's the value: %@", answersSelected);
	//[smell resignFirstResponder];
	//NSLog(@"resigned first responder");
	/*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"trying it out" message:@"hi" delegate:self cancelButtonTitle:@"button1" otherButtonTitles:@"button2", nil];
	[alert show];
	[alert release];*/
	[super viewWillDisappear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(IBAction) viewChanged: (id)sender {
	switch (segControl.selectedSegmentIndex) {
		case 0:
			[view1 setHidden:NO];
			[view2 setHidden:YES];
			[view3 setHidden:YES];
			break;
		case 1:
			[view1 setHidden:YES];
			[view2 setHidden:NO];
			[view3 setHidden:YES];
			break;
		case 2:
			[view1 setHidden:YES];
			[view2 setHidden:YES];
			[view3 setHidden:NO];
			break;
		default:
			break;
	}
}

-(IBAction) nextButtonPressed: (id)sender {
	segControl.selectedSegmentIndex++;
	/*[viewChanged: nil];*/
}

-(IBAction) doneButtonPressed: (id)sender{
	[app_delegate.navigationController popViewControllerAnimated:YES];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if (pickerView==picker1) {
		return [array1 count];
	} else if (pickerView==picker2) {
		return [array2 count];
	} else {
		return [array3 count];
	}
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if (pickerView==picker1) {
		//NSLog(@"picker 1, adding %@", [array1 objectAtIndex:row]);
		return [array1 objectAtIndex:row];
	} else if (pickerView==picker2) {
		return [array2 objectAtIndex:row];
	} else {
		return [array3 objectAtIndex:row];
	}
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
	
	switch (segControl.selectedSegmentIndex) {
		case 0:
			//UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"please work" message:@"will you?" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:<#(NSString *)otherButtonTitles#>]
			break;
		default:
			break;
	}
}


- (void)dealloc {
    [super dealloc];
}


@end
