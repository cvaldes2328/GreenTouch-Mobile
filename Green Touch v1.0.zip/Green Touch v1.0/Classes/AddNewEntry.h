//
//  AddNewEntry.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/23/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Comments.h"
#import "ColorPickerViewController.h"
#import "Sketches.h"
#import "TextureSmell.h"
#import "TagViewController.h"
#import "ThirdTrySize.h"
#import "PaintVC.h"
#import "LocationGetter.h"
#import "FallPhenology.h"
@class FlowerPowerNavBAppDelegate;


@interface AddNewEntry : UITableViewController <UINavigationControllerDelegate, UIActionSheetDelegate, UIImagePickerControllerDelegate, OFFlickrAPIRequestDelegate> {
	FlowerPowerNavBAppDelegate *app_delegate;
	ColorPickerViewController *colors;
	Comments *comments;
	ThirdTrySize *sizeVC;
	Sketches *sketches;
	TextureSmell *textureSmell;
	TagViewController *tagVC;
	PaintVC *paint;
	FallPhenology *fall;
	
	UILabel *specimenLabel;
	UILabel *dateLabel;
	UILabel *weatherLabel;
	UILabel *takePicHint;
	UILabel *nameLabel;
	
	BOOL isFirst;
	NSString *nameForLoad;
	NSArray *controllers_;
	NSArray *controller_names;

	IBOutlet UIButton *picture;
	OFFlickrAPIRequest *flickrRequest;
	
	CLLocation *lastKnownLocation;
	
	NSMutableDictionary *stream_;
	NSMutableArray *log_;
	
	//NSMutableDictionary *thisPlantData;
     
    //UIImagePickerController *imagePicker;
    

}

@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;

@property (nonatomic, retain) ColorPickerViewController *colors;
@property (nonatomic, retain) Comments *comments;
@property (nonatomic, retain) ThirdTrySize *sizeVC;
@property (nonatomic, retain) Sketches *sketches;
@property (nonatomic, retain) TextureSmell *textureSmell;
@property (nonatomic, retain) TagViewController *tagVC;
@property (nonatomic, retain) PaintVC *paint;
@property (nonatomic, retain) FallPhenology *fall;

//@property (nonatomic, retain) NSMutableDictionary *thisPlantData;

@property (nonatomic, retain) IBOutlet UILabel *specimenLabel;
@property (nonatomic, retain) IBOutlet UILabel *dateLabel;
@property (nonatomic, retain) IBOutlet UILabel *weatherLabel;
@property (nonatomic, retain) IBOutlet UILabel *takePicHint;
@property (nonatomic, retain) IBOutlet UILabel *nameLabel;

@property (nonatomic, retain) NSString *nameForLoad;
@property (nonatomic, retain) NSArray *controllers_;
@property (nonatomic, retain) NSArray *controller_names;
@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;
@property (nonatomic, retain) IBOutlet UIButton *picture;

@property (nonatomic, retain) CLLocation *lastKnownLocation;

//Log
@property (nonatomic, retain) NSMutableDictionary *stream_;
@property (nonatomic, retain) NSMutableArray *log_;


//@property (nonatomic, retain) UIImagePickerController *imagePicker;

-(void) submitInfo;
- (void)_startUpload:(UIImage *)image;
- (IBAction)authorizeAction;
-(IBAction) pictureButtonPressed: (id) sender;
- (NSString*)processLog ;
-(NSString*) parsedJSON;
-(NSString*) basicParse: (NSArray *)s;

//FFFFFIIIIIIIIXXXXXXX!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-(void)addLog;
-(void)updateLog:(NSString*)act;
-(void)_startUpload:(UIImage *)image;
@end
