//
//  TextureSmell.h
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FlowerPowerNavBAppDelegate;

@interface TextureSmell : UIViewController <UITextFieldDelegate>{
	
	FlowerPowerNavBAppDelegate *app_delegate;
	NSMutableArray *floweranswersSelected; 
	NSMutableArray *leafSmellanswersSelected; 
	NSMutableArray *leafTextureanswersSelected; 
	
	UISegmentedControl *segControl;
	
	IBOutlet UITextField *smell;
	IBOutlet UIScrollView *flowerView;
	IBOutlet UIView *leafView;
	
}

@property (nonatomic, retain) IBOutlet FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) NSMutableArray *floweranswersSelected;
@property (nonatomic, retain) NSMutableArray *leafSmellanswersSelected;
@property (nonatomic, retain) NSMutableArray *leafTextureanswersSelected;
@property (nonatomic, retain) IBOutlet UISegmentedControl *segControl;
@property (nonatomic, retain) IBOutlet UITextField *smell;
@property (nonatomic, retain) IBOutlet UIScrollView *flowerView;
@property (nonatomic, retain) IBOutlet UIView *leafView;

- (IBAction) checkboxSelectedLeafSmell:(id)sender;
- (IBAction) checkboxSelectedFlower:(id)sender;
- (IBAction) checkboxSelectedLeafTexture:(id)sender;
-(IBAction) keyboardButtonPressed: (id) sender;
-(IBAction) backButtonPressed: (id)sender;
-(IBAction) viewChanged: (id)sender;


@end
