//
//  TagViewController.h
//  ArtExplo
//
//  Created by HCI Lab on 7/2/10.
//  Copyright 2010 Wellesley College. All rights reserved.
//
//	Based on Lia Napolitano's Davis-FX project. Specifically, the TagVC.h class.
//

#import <UIKit/UIKit.h>
@class FlowerPowerNavBAppDelegate;


@interface TagViewController : UIViewController <UITextFieldDelegate> {

	NSDictionary *work;
	int r;
	BOOL was_answered;
	NSString *question;
	NSArray *answers;
	NSMutableArray *answer;
	NSMutableArray *pictures;
	NSString *selectedType;
	
	UIButton *animalOnLeaf;
	UIButton *animalOnStem;
	UIButton *animalOnFlower;
	UIButton *holes;
	UIButton *damageToleaf;
	UILabel *viewHere;
	UIButton *minorButton;
	UIButton *significant;
	UIButton *severe;
	UILabel *minorLabel;
	UILabel *significantLabel;
	UILabel *severeLabel;
	
	
	NSString *labelText;
	
	IBOutlet UIButton *backgroundButton;
	IBOutlet UIScrollView *questions_scroll_view;
	IBOutlet UIScrollView *otherScrollView;
	

	IBOutlet UITextField *text_field;
	
	UIImage *bg;

}

@property (nonatomic, retain) IBOutlet FlowerPowerNavBAppDelegate *app_delegate;

@property (nonatomic, retain) NSString *question;
@property (nonatomic, retain) NSString *selectedType;
@property (nonatomic, retain) UIImage *bg;
@property (nonatomic, retain) NSArray *answers;
@property (nonatomic, retain) NSDictionary *work;
@property (nonatomic, retain) NSMutableArray *answer;
@property (nonatomic, retain) NSMutableArray *pictures;

//camera buttons
@property (nonatomic, retain) IBOutlet UIButton *animalOnLeaf;
@property (nonatomic, retain) IBOutlet UIButton *animalOnStem;
@property (nonatomic, retain) IBOutlet UIButton *animalOnFlower;
@property (nonatomic, retain) IBOutlet UIButton *holes;
@property (nonatomic, retain) IBOutlet UIButton *damageToleaf;
@property (nonatomic, retain) IBOutlet UILabel *viewHere;

@property (nonatomic, retain) IBOutlet UIButton *minorButton;
@property (nonatomic, retain) IBOutlet UIButton *significant;
@property (nonatomic, retain) IBOutlet UIButton *severe;
@property (nonatomic, retain) IBOutlet UILabel *minorLabel;
@property (nonatomic, retain) IBOutlet UILabel *significantLabel;
@property (nonatomic, retain) IBOutlet UILabel *severeLabel;

@property (nonatomic) int r;
@property (nonatomic, retain) NSString *labelText;

@property (nonatomic, retain) UIButton *backgroundButton;
@property (nonatomic, retain) IBOutlet UIScrollView *questions_scroll_view;
@property (nonatomic, retain) IBOutlet UIScrollView *otherScrollView;
@property (nonatomic, retain) IBOutlet UITextField *text_field;

- (IBAction) checkboxSelected:(id)sender;
- (IBAction) backgroundButton: (id)sender;
-(IBAction) backButtonPressed: (id)sender;
-(IBAction) buttonPressed: (id)sender;
- (void)getRidOfKeyboardFromQuestionsView;

@end
