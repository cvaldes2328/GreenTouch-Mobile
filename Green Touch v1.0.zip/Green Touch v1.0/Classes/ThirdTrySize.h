//
//  ThirdTrySize.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/25/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FlowerPowerNavBAppDelegate;

@interface ThirdTrySize : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate> {

	FlowerPowerNavBAppDelegate *app_delegate;
	UISegmentedControl *segControl;
	
	UIView *view1;
	UIView *view2;
	UIView *view3;
	
	UIPickerView *picker1;
	UIPickerView *picker2;
	UIPickerView *picker3;
	
	UILabel *label1;
	UILabel *label2;
	UILabel *label3;
	
	NSArray *array1;
	NSArray *array2;
	NSArray *array3;
	
	UITextView *text1;
	UITextView *text2;
	UITextView *text3;
	
	
}

@property (nonatomic, retain) IBOutlet FlowerPowerNavBAppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UISegmentedControl *segControl;

@property (nonatomic, retain) IBOutlet UIView *view1;
@property (nonatomic, retain) IBOutlet UIView *view2;
@property (nonatomic, retain) IBOutlet UIView *view3;

@property (nonatomic, retain) IBOutlet UIPickerView *picker1;
@property (nonatomic, retain) IBOutlet UIPickerView *picker2;
@property (nonatomic, retain) IBOutlet UIPickerView *picker3;

@property (nonatomic, retain) IBOutlet UILabel *label1;
@property (nonatomic, retain) IBOutlet UILabel *label2;
@property (nonatomic, retain) IBOutlet UILabel *label3;

@property (nonatomic, retain) IBOutlet UITextView *text1;
@property (nonatomic, retain) IBOutlet UITextView *text2;
@property (nonatomic, retain) IBOutlet UITextView *text3;

@property (nonatomic, retain) NSArray *array1;
@property (nonatomic, retain) NSArray *array2;
@property (nonatomic, retain) NSArray *array3;

-(IBAction) viewChanged: (id)sender;
-(IBAction) nextButtonPressed: (id)sender;
-(IBAction) doneButtonPressed: (id)sender;
@end
