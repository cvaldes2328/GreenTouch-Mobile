//
//  SurveyGallery.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/9/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//
#import "FlowerPowerNavBAppDelegate.h"
#import <UIKit/UIKit.h>


@interface SurveyGallery : UIViewController {

	FlowerPowerNavBAppDelegate *app_delegate;
	NSMutableArray *views;
	NSMutableArray *info;

	NSMutableString *currentInfo;
	NSString *numberOfPlants;
	
	UIButton *addNewButton;
	UIButton *menuButton;
	UIView *galleryView;
}
@property (nonatomic, retain) NSString *numberOfPlants;
@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) NSMutableArray *views; 
@property (nonatomic, retain) NSMutableArray *info; 
@property (nonatomic, retain) NSMutableString *currentInfo;
@property (nonatomic, retain) IBOutlet UIButton *addNewButton; 
@property (nonatomic, retain) IBOutlet UIButton *menuButton; 
@property (nonatomic, retain) IBOutlet UIView *galleryView;

-(IBAction) addButtonPressed: (id) sender;

-(IBAction) menuButtonPressed: (id) sender;

-(void) addNewPicture;

@end
