//
//  Where.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/7/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Bloom.h"
#import "Photo.h"
#import "SurveyGallery.h"

@class FlowerPowerNavBAppDelegate;

@interface Where : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
	
	FlowerPowerNavBAppDelegate *app_delegate;
	Photo *photoView;
	SurveyGallery *bloomView; 
	
	UITextView *text; 
	UIPickerView *picker; 
	UIButton *button; 
	NSArray *array; 
}
@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate; 
@property (nonatomic, retain) Photo *photoView; 
@property (nonatomic, retain) SurveyGallery *bloomView; 

@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) IBOutlet UIButton *button;
@property (nonatomic, retain) IBOutlet UITextView *text; 
@property (nonatomic, retain) NSArray *array; 

-(IBAction) buttonPressed : (id) sender; 


@end
