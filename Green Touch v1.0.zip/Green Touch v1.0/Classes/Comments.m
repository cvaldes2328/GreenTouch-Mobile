//
//  Comments.m
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "Comments.h"
#import "FlowerPowerNavBAppDelegate.h"


@implementation Comments
@synthesize tf, tf2, sview, app_delegate;


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];

	self.title = [NSString stringWithFormat:@"Comments/Questions"];
	tf.delegate = self;
	tf2.delegate = self;
    [super viewDidLoad];
}


- (void)textViewDidBeginEditing:(UITextView *)textField
{	
	[sview setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 50) animated:YES];	
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");
	/*NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:
							  tf.text, @"comments",
							  tf2.text, @"questions",
							  nil];
	NSLog(@"Temp dict is %@", tempDict);*/
	//NSDictionary *allanswersforappdelegate = [NSDictionary dictionaryWithObjectsAndKeys:
											 // tempDict, @"comments",
											 // nil];
	//NSLog(@"created dictionary");
	//NSString *hacky = [NSString stringWithFormat:@"%@ ", tf.text];
	[app_delegate.newEntryData setValue:tf.text forKey:@"comments"];
	//hacky = [NSString stringWithFormat:@"%@ ", tf2.text];
	[app_delegate.newEntryData setValue:tf2.text forKey:@"questions"];
	//NSLog(@"set object");
	//NSLog(@"here's the value: %@", answersSelected);
	//[smell resignFirstResponder];
	//NSLog(@"resigned first responder");
	[super viewWillDisappear:animated];
}

//or grab data from here
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	//[text_field resignFirstResponder];
	[sview setContentOffset:CGPointZero animated:YES];
	return YES;
}


-(IBAction) keyboardButtonPressed: (id) sender {
	
	[tf resignFirstResponder];
	[tf2 resignFirstResponder];
	[sview setContentOffset:CGPointZero animated:YES];

}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[tf release];
    [super dealloc];
}


@end
