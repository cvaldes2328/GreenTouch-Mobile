//
//  PaintVC.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/30/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "PaintVC.h"
#import "PaintingView.h"
#import "SoundEffect.h"
#import "FlowerPowerNavBAppDelegate.h"

//CONSTANTS:

#define kPaletteHeight			30
#define kPaletteSize			5
#define kMinEraseInterval		0.5

// Padding for margins
#define kLeftMargin				10.0
#define kTopMargin				10.0
#define kRightMargin			10.0

//FUNCTIONS:
/*
 HSL2RGB Converts hue, saturation, luminance values to the equivalent red, green and blue values.
 For details on this conversion, see Fundamentals of Interactive Computer Graphics by Foley and van Dam (1982, Addison and Wesley)
 You can also find HSL to RGB conversion algorithms by searching the Internet.
 See also http://en.wikipedia.org/wiki/HSV_color_space for a theoretical explanation
 */
static void HSL2RGB(float h, float s, float l, float* outR, float* outG, float* outB)
{
	float			temp1,
	temp2;
	float			temp[3];
	int				i;
	
	// Check for saturation. If there isn't any just return the luminance value for each, which results in gray.
	if(s == 0.0) {
		if(outR)
			*outR = l;
		if(outG)
			*outG = l;
		if(outB)
			*outB = l;
		return;
	}
	
	// Test for luminance and compute temporary values based on luminance and saturation 
	if(l < 0.5)
		temp2 = l * (1.0 + s);
	else
		temp2 = l + s - l * s;
	temp1 = 2.0 * l - temp2;
	
	// Compute intermediate values based on hue
	temp[0] = h + 1.0 / 3.0;
	temp[1] = h;
	temp[2] = h - 1.0 / 3.0;
	
	for(i = 0; i < 3; ++i) {
		
		// Adjust the range
		if(temp[i] < 0.0)
			temp[i] += 1.0;
		if(temp[i] > 1.0)
			temp[i] -= 1.0;
		
		
		if(6.0 * temp[i] < 1.0)
			temp[i] = temp1 + (temp2 - temp1) * 6.0 * temp[i];
		else {
			if(2.0 * temp[i] < 1.0)
				temp[i] = temp2;
			else {
				if(3.0 * temp[i] < 2.0)
					temp[i] = temp1 + (temp2 - temp1) * ((2.0 / 3.0) - temp[i]) * 6.0;
				else
					temp[i] = temp1;
			}
		}
	}
	
	// Assign temporary values to R, G, B
	if(outR)
		*outR = temp[0];
	if(outG)
		*outG = temp[1];
	if(outB)
		*outB = temp[2];
}

//CLASS IMPLEMENTATIONS:
@implementation PaintVC
@synthesize window;
@synthesize drawingView /*app_delegate*/;
@synthesize pic;


-(IBAction) buttonPressed: (id)sender {
	//UIButton *button = (UIButton *)sender;
	
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}
	
	[self presentModalViewController:imagePicker animated:YES];
}

#pragma mark UIImagePickerController delegate methods
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		NSLog(@"made it!");
		[self dismissModalViewControllerAnimated:YES];
		[image retain];
		pic = image;
		FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
		[app_delegate.navigationController popViewControllerAnimated:YES];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		//newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
		//[self.questions_scroll_view addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */
	/*
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		//[pictures addObject:[[NSArray alloc] initWithObjects: image, selectedType, nil]];
		UIImageView *newView = [[UIImageView alloc] initWithImage:image];
	 
		newView.frame = CGRectMake(45/*[pictures count]-40, 10, 40, 60);
		[self.drawingView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	 */
	


 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	self.title = [NSString stringWithFormat:@"Sketches"];


	CGRect					rect = [[UIScreen mainScreen] applicationFrame];
	CGFloat					components[3];
	
	// Create a segmented control so that the user can choose the brush color.
	UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:
											[NSArray arrayWithObjects:
											 [UIImage imageNamed:@"Red.png"],
											 [UIImage imageNamed:@"Yellow.png"],
											 [UIImage imageNamed:@"Green.png"],
											 [UIImage imageNamed:@"Blue.png"],
											 [UIImage imageNamed:@"Purple.png"],
											 nil]];
	
	// Compute a rectangle that is positioned correctly for the segmented control you'll use as a brush color palette
	CGRect frame = CGRectMake(rect.origin.x + kLeftMargin, rect.size.height - kPaletteHeight - kTopMargin, rect.size.width - (kLeftMargin + kRightMargin), kPaletteHeight);
	segmentedControl.frame = frame;
	// When the user chooses a color, the method changeBrushColor: is called.
	[segmentedControl addTarget:self action:@selector(changeBrushColor:) forControlEvents:UIControlEventValueChanged];
	segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
	// Make sure the color of the color complements the black background
	segmentedControl.tintColor = [UIColor darkGrayColor];
	// Set the third color (index values start at 0)
	segmentedControl.selectedSegmentIndex = 2;
	
	// Add the control to the window
	[window addSubview:segmentedControl];
	// Now that the control is added, you can release it
	[segmentedControl release];
	
    // Define a starting color 
	HSL2RGB((CGFloat) 2.0 / (CGFloat)kPaletteSize, kSaturation, kLuminosity, &components[0], &components[1], &components[2]);
	// Defer to the OpenGL view to set the brush color
	[drawingView setBrushColorWithRed:components[0] green:components[1] blue:components[2]];
	
	// Look in the Info.plist file and you'll see the status bar is hidden
	// Set the style to black so it matches the background of the application
	//[application setStatusBarStyle:UIStatusBarStyleBlackTranslucent animated:NO];
	// Now show the status bar, but animate to the style.
	//[application setStatusBarHidden:NO withAnimation:YES];
	
	// Load the sounds
	NSBundle *mainBundle = [NSBundle mainBundle];	
	erasingSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"Erase" ofType:@"caf"]];
	selectSound =  [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"Select" ofType:@"caf"]];
	
	// Erase the view when recieving a notification named "shake" from the NSNotificationCenter object
	// The "shake" nofification is posted by the PaintingWindow object when user shakes the device	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(eraseView) name:@"shake" object:nil];
	
	UIBarButtonItem *saveItem;
	saveItem = [[UIBarButtonItem alloc] initWithTitle:@"Take Picture" 
												style:UIBarButtonItemStyleDone target:self action:@selector(buttonPressed:)];
	self.navigationItem.rightBarButtonItem = saveItem;
	[saveItem release];
	
	[super viewDidLoad];
 }
 
-(void) viewWillDisappear:(BOOL)animated {
	
	//[app_delegate.dataGathered setValue:tf.text forKey:@"comments"];
	//[app_delegate.dataGathered setValue:tf2.text forKey:@"questions"];
	//NSLog(@"set object");
	//NSLog(@"here's the value: %@", answersSelected);
	//[smell resignFirstResponder];
	//NSLog(@"resigned first responder");
	FlowerPowerNavBAppDelegate *app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	[app_delegate.newEntryData setValue:@"" forKey:@"sketches"];
	[super viewWillDisappear:animated];
}


// Release resources when they are no longer needed,
- (void) dealloc
{
	[selectSound release];
	[erasingSound release];
	[drawingView release];
	[window release];
	
	[super dealloc];
}

// Change the brush color
- (void)changeBrushColor:(id)sender
{
 	CGFloat					components[3];
	
	// Play sound
 	[selectSound play];
	
	// Define a new brush color
 	HSL2RGB((CGFloat)[sender selectedSegmentIndex] / (CGFloat)kPaletteSize, kSaturation, kLuminosity, &components[0], &components[1], &components[2]);
	// Defer to the OpenGL view to set the brush color
	[drawingView setBrushColorWithRed:components[0] green:components[1] blue:components[2]];
	
}

// Called when receiving the "shake" notification; plays the erase sound and redraws the view
-(void) eraseView
{
	if(CFAbsoluteTimeGetCurrent() > lastTime + kMinEraseInterval) {
		[erasingSound play];
		[drawingView erase];
		lastTime = CFAbsoluteTimeGetCurrent();
	}
}

@end
