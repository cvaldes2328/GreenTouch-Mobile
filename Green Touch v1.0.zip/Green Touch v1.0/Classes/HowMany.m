//
//  HowMany.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/8/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "HowMany.h"
#import "FlowerPowerNavBAppDelegate.h"

@implementation HowMany
@synthesize picker, button, text, array, notesView, app_delegate, surveyGallery; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[picker setDelegate:self];
	[picker setDataSource:self];
	
	array = [[NSArray alloc] initWithObjects:@"1-10", @"11-100", @"100-1,000", @"1,000+", nil]; 
	[text setFont:[UIFont fontWithName:@"Helvetica" size:28.0]];

	self.title = @"Flower Count";
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

//picker stuff
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}


// when button pressed, should go to notes page
-(IBAction) buttonPressed: (id) sender {
	
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	notesView = [[Notes alloc] initWithNibName:@"Notes" bundle:nil];
	notesView.surveyGallery = surveyGallery;
	/*if ([[NSCharacterSet decimalDigitCharacterSet] characterIsMember:[surveyGallery.currentInfo characterAtIndex:[surveyGallery.currentInfo length]-1]]) {
		[surveyGallery.currentInfo 
	}
	[surveyGallery.currentInfo appendString:@" "];
	//[surveyGallery.currentInfo appendString:[picker titleForRow:[picker selectedRowInComponent:0] forComponent:0]];
	[surveyGallery.currentInfo appendString:[[array objectAtIndex:[picker selectedRowInComponent:0]] stringByReplacingOccurrencesOfString:@"," withString:@""]];
	*/
	surveyGallery.numberOfPlants = [array objectAtIndex:[picker selectedRowInComponent:0]];
	 NSLog(@"current info is %@", surveyGallery.currentInfo);
	[app_delegate.navigationController pushViewController:notesView animated:YES]; 
	
	
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
