//
//  FallPhenology.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/7/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "FallPhenology.h"


@implementation FallPhenology
@synthesize segControl, view1, view2, view3, picker1, picker2, picker3, text1, text2, text3, array1, array2, array3, label1, label2, label3;
@synthesize app_delegate;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	self.title = [NSString stringWithFormat:@"Fall Phenology"];
	
	NSArray *array = [[NSArray alloc] initWithObjects:@"None", 
					  @"Less than half", @"At least half", 
					  @"Almost all",
					  @"All", nil];
	array1 = array;
	[array1 retain];
	text1.text =  @"How many of the leaves have fall color?";
	[text1 setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	//firstDetail.array = 
	//firstDetail.labelString = @"What is the stage of the most advanced leaf you can see?";
	
	array = [[NSArray alloc] initWithObjects:@"Red", @"Orange", @"Yellow",
			 @"Green", @"Brown", @"Other",nil];
	array2 = array;
	[array2 retain];
	text2.text = @"What is the most predominant color over all the leaves on the plant?";
	[text2 setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	//secondDetail.array = [[NSArray alloc] initWithObjects:@"None", @"Bud without color", @"Bud with color",
	// @"In bloom", @"Flower past", nil];
	//secondDetail.labelString = @"What is 
	array = [[NSArray alloc] initWithObjects:@"None", @"Less than half",
			 /*@"More than half",*/ @"Half or more", @"Almost all", @"All", nil];
	array3 = array;
	[array3 retain];
	text3.text = @"What fraction of the leaves have already dropped from the tree? (Look on the ground as well as at the plant for evidence.)";
	[text3 setFont:[UIFont fontWithName:@"Helvetica" size:18.0]];
	//NSLog(@"%@",[array3 objectAtIndex:1]);
	//segControl.selectedSegmentIndex = 2;
	
	[segControl setFrame:
     CGRectMake(segControl.frame.origin.x,
				segControl.frame.origin.y,
				segControl.frame.size.width, 
				segControl.frame.size.height*1.4)];
	
	[view2 setHidden:YES];
	[view3 setHidden:YES];
	
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
-(IBAction) viewChanged: (id)sender {
	switch (segControl.selectedSegmentIndex) {
		case 0:
			[view1 setHidden:NO];
			[view2 setHidden:YES];
			[view3 setHidden:YES];
			break;
		case 1:
			[view1 setHidden:YES];
			[view2 setHidden:NO];
			[view3 setHidden:YES];
			break;
		case 2:
			[view1 setHidden:YES];
			[view2 setHidden:YES];
			[view3 setHidden:NO];
			break;
		default:
			break;
	}
}

#pragma mark PickerView DataSource methods
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if (pickerView==picker1) {
		return [array1 count];
	} else if (pickerView==picker2) {
		return [array2 count];
	} else {
		return [array3 count];
	}
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	NSLog(@"Getting titles");
	if (pickerView==picker1) {
		NSLog(@"picker 1, adding %@", [array1 objectAtIndex:row]);
		return [array1 objectAtIndex:row];
	} else if (pickerView==picker2) {
		return [array2 objectAtIndex:row];
	} else {
		NSLog(@"in else");
		return [array3 objectAtIndex:row];
	}
}

-(IBAction) nextButtonPressed: (id)sender {
	segControl.selectedSegmentIndex++;
	/*[viewChanged: nil];*/
}

-(IBAction) doneButtonPressed: (id)sender{
	[app_delegate.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
