//
//  AddNewEntry.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/23/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//


#import <CoreFoundation/CoreFoundation.h>

#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>

#import "AddNewEntry.h"
#import "TagViewController.h"
#import "TextureSmell.h"
#import "ColorPickerViewController.h"
#import "Comments.h"
#import "Sketches.h"
#import "FlowerPowerNavBAppDelegate.h"
#import "ThirdTrySize.h"
#import "PaintVC.h"
#import "LocationGetter.h"
#import "FallPhenology.h"
#import "JSON.h"

@implementation AddNewEntry

//NSString *kGetUserInfoStep = @"kGetUserInfoStep";
//NSString *kSetImagePropertiesStep = @"kSetImagePropertiesStep";
//NSString *kUploadImageStep = @"kUploadImageStep";
@synthesize colors, comments, sizeVC, sketches, textureSmell, tagVC, paint, fall, nameForLoad;

@synthesize app_delegate, controllers_, controller_names, flickrRequest, picture, dateLabel, weatherLabel, specimenLabel, takePicHint;
@synthesize nameLabel;
@synthesize lastKnownLocation, stream_, log_;

#pragma mark -
#pragma mark View lifecycle



- (void)viewDidAppear:(BOOL)animated {
 self.title = [NSString stringWithFormat:@"New Entry"];
 NSLog(@"%@", app_delegate.newEntryData);
[super viewDidAppear:animated];
}


- (void)viewDidLoad {
	isFirst = YES;

	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	specimenLabel.text = app_delegate.currentPlant;
	NSLog(@"hello? %@", app_delegate.currentPlant);
	NSMutableArray *array = [[NSMutableArray alloc] init];
	NSMutableArray *names = [[NSMutableArray alloc] init];
	
	self.nameLabel.text = nameForLoad;
	
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
	
	df.dateStyle = NSDateFormatterLongStyle;
	NSDate *date =[NSDate date];
	NSString *today = [df stringFromDate:(NSDate *)date];
	NSLog(@"%@",today);
	dateLabel.text = today;
	
	[df release];
	
	
	tagVC = [[TagViewController alloc] initWithNibName:@"TagViewController" bundle:nil];
	[array addObject:tagVC];
	[names addObject:@"Animal Evidence"];
	
	/*colors = [[ColorPickerViewController alloc] initWithNibName:@"ColorPickerViewController" bundle:nil];
	[array addObject:colors];
	[names addObject:@"Colors"];*/
	
	sizeVC = [[ThirdTrySize alloc] initWithNibName:@"ThirdTrySize" bundle:nil];
	[array addObject:sizeVC];
	[names addObject:@"Spring Phenology"];
	
	fall = [[FallPhenology alloc] initWithNibName:@"FallPhenology" bundle:nil];
	[array addObject:fall];
	[names addObject:@"Fall Phenology"];
	
	/*paint = [[PaintVC alloc] initWithNibName:@"PaintVC" bundle:nil];
	[array addObject:paint];
	[names addObject:@"Sketches"];*/
	
	textureSmell = [[TextureSmell alloc] initWithNibName:@"TextureSmell" bundle:nil];
	[array addObject:textureSmell];
	[names addObject:@"Texture & Smell"];
	
	comments = [[Comments alloc] initWithNibName:@"Comments" bundle:nil];
	[array addObject:comments];
	[names addObject:@"Comments/Questions"];
	

	 
	self.controllers_ = array;
	[array release];
	self.controller_names = names;
	[names release];
	
	self.log_ = [[NSMutableArray alloc]init];
	// get our physical location for weather and gps later
    LocationGetter *locationGetter = [[LocationGetter alloc] init];
    locationGetter.delegate = self;
    [locationGetter startUpdates];
	
    [super viewDidLoad];

	UIBarButtonItem *saveItem;
	
	if(!flickrRequest) {
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext];
        flickrRequest.delegate = self;
		flickrRequest.requestTimeoutInterval = 60.0;
	}
	//NSLog(@"%@", [flickrRequest isRunning]);
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
	if([[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext.authToken length]>0) {
		saveItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" 
													style:UIBarButtonItemStyleDone target:self action:@selector(doneButtonPressed:)];

	}
	else {
		saveItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" 
								style:UIBarButtonItemStyleDone target:self action:@selector(doneButtonPressed:)];
	}
		self.navigationItem.rightBarButtonItem = saveItem;
	[saveItem release];
	
	//remove default "back" barbutton
	[self.navigationItem setHidesBackButton:YES];
	
}

-(IBAction) cancelButtonPressed: (id)sender {
	UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" 
												   message:@"Are you sure you want to return to the main menu?  All information will be lost!" 
												  delegate:self 
										 cancelButtonTitle:@"Delete data" 
										 otherButtonTitles:@"Cancel", nil];
	[alert show];
	[alert release];
}

-(IBAction)doneButtonPressed:(id)sender
{
	if ([self.navigationItem.rightBarButtonItem.title isEqualToString:@"Authenticate"]) {
		[self authorizeAction];
		self.navigationItem.rightBarButtonItem.title = @"Done";
	} else {
	UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" 
												   message:@"Are you sure you've finished?" 
												  delegate:self 
										 cancelButtonTitle:@"No, go back" 
										 otherButtonTitles:@"Yes, continue", nil];
	//[app_delegate updateLog:[NSString stringWithFormat:@"Submitted bad ID %@",art_code_field.text]];
	[alert show];
		[alert release];
	}
}

-(IBAction) pictureButtonPressed: (id) sender {
	if(isFirst) { //first picture
		takePicHint.hidden = YES;
		UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
		
		if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
			imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
		}
		[self presentModalViewController:imagePicker animated:YES];
	} else { //check if you actually WANT to re-take picture
		UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Would you like to retake this plant's picture?" 
																 delegate:self 
														cancelButtonTitle:@"Yes"
												   destructiveButtonTitle:@"No" 
														otherButtonTitles:nil];
		[actionSheet showInView:self.view];
		[actionSheet release];
	}

}


#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		isFirst = NO;
		picture.imageView.image = image;
		[picture setImage:image forState:UIControlStateNormal];
		[picture setImage:image forState:UIControlStateHighlighted];
		[picture setImage:image forState:UIControlStateDisabled];
		[self dismissModalViewControllerAnimated:YES];
		
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
		
	}
	
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	if(buttonIndex==0) {
		//do nothing
	} else {
		UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
		
		if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
			imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
		}
		[self presentModalViewController:imagePicker animated:YES];
		
	}
}
	

-(BOOL) connectedToNetwork
{
	
	//Create zero addy
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	
	//Recover reachability flags
	SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr*)&zeroAddress);
	SCNetworkReachabilityFlags flags;
	
	BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
	CFRelease(defaultRouteReachability);
	
	if (!didRetrieveFlags) {
		printf("Error. Could not recover network reachability flags\n");
		return 0;
	}
	
	BOOL isReachable = flags & kSCNetworkFlagsReachable;
	BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
	return (isReachable && !needsConnection) ? YES : NO;
}

	
	
- (void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex {
	NSLog(@"will dismiss");
	if(buttonIndex==1) {//okay
		//[self submitInfo];
		//[self updateLog:[NSString stringWithFormat:@"%@",app_delegate.dataGathered]];
		//app_delegate.dataGathered
		NSLog(@"adding log, submitting info");
		[self addLog];
		[self submitInfo];
		
		//submit info from data to server if there is wifi
		/*if ([self connectedToNetwork]) {
			for (int i = 0; i<[app_delegate.totalDataGathered count]; i++) {
				NSString *pleasepleaseplease = [[app_delegate.totalDataGathered objectAtIndex:i] JSONRepresentation];
				NSString *paramDataString = [NSString stringWithFormat:@"entry=%@", pleasepleaseplease];
				NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
				
				NSLog(@"this is the log: %@", paramDataString);
				
				NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
				[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_entry"]];
				[request setHTTPMethod:@"POST"];
				[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
				
				[request setHTTPBody: paramData];
				
				NSURLResponse *urlResponse;	
				NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:nil];
				NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
				NSLog(@"made it to end of addLog");
				NSLog(@"%@", urlResponse);
				NSLog(@"%@", data);
				NSLog(@"%@", tData);
				[tData release];
				[request release];
				
				
			}
			//app_delegate.flickrContext = [[OFFlickrAPIContext alloc] initWithAPIKey:kOBJECTIVE_FLICKR_SAMPLE_API_KEY sharedSecret:kOBJECTIVE_FLICKR_SAMPLE_API_SHARED_SECRET];
			
			if ([[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext.authToken length]<1) {
				[self authorizeAction];
			}
			NSString *authToken;
			if (authToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"FlickrAuthToken"]) {
				app_delegate.flickrContext.authToken = authToken;
			}
			
			flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:app_delegate.flickrContext];
			flickrRequest.delegate = self;
			flickrRequest.requestTimeoutInterval = 60.0;
			
			NSLog(@"going to upload all pics");
			for (int i = 0; i<[app_delegate.pics count]; i++) {
				[self performSelector: @selector(_startUpload:) withObject:[NSNumber numberWithInt:i] afterDelay:5.0+10.0*i];
			}
			//some last-minute setup-type stuff
			//[submitAllButton setHidden:YES];
			//[app_delegate.totalData release];
			if (app_delegate.totalDataGathered == nil) {
				app_delegate.totalDataGathered = [[NSMutableArray alloc] init];
			}

			
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success!" 
															message:@"Your data has uploaded.  Please leave the app running so that the pictures can finish uploading." 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
			[alert show];
			[alert release];
			
		}else {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No WiFi!" 
															message:@"Seems like there is no internet. Try again when you see that you have wifi." 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
			[alert show];
			[alert release];
		}		
		//submitting done
		*/
		[app_delegate.navigationController popViewControllerAnimated:YES];
		NSLog(@"finished returning to menu");
		 
	} else { //cancel
		//do nothing
	}
	
}
/*	
-(NSString*) parsedJSON {
		//currently can deal with animal evidence, comments, questions, texture/smell, user name
	NSMutableString *ans = [[NSMutableString alloc] init];
	NSDictionary *working = app_delegate.newEntryData;
	NSArray *keys = [working allKeys];
	for (int n = 0; n<[keys count]; n++) {
		NSString *key = [keys objectAtIndex: n];
		if ([key isEqualToString:@"\"animalevidence\""]) {
			//add the words "animal evidence"
			[ans appendString:key];
			[ans appendString:@" : [\n"];
			[ans appendString:[NSString stringWithFormat:@"%@", [self basicParse:[working objectForKey:key]]]];
			[ans appendString:@"]\n"];
			
		} else if ([key isEqualToString:@"\"comments\""]||[key isEqualToString:@"\"questions\""]||[key isEqualToString:@"\"leafTexture\""]||[key isEqualToString:@"\"leafSmell\""]||[key isEqualToString:@"\"flowerSmell"]||[key isEqualToString:@"\"location\""]
				   ||[key isEqualToString:@"\"user\""]){
			[ans appendString:key];
			[ans appendString:@" :"];
			[ans appendString:[NSString stringWithFormat:@"%@", [self basicParse: [working objectForKey:key]]]];
			[ans appendString:@",\n"];
		} 
	}
					  return ans;
					
}

	
-(NSString*) basicParse:(NSArray*)s {
	NSString *y = [NSString stringWithFormat:@"%@", s];
	y = [y stringByReplacingOccurrencesOfString:@"=" withString:@":"];
	y = [y stringByReplacingOccurrencesOfString:@"1: " withString:@""];
	y = [y stringByReplacingOccurrencesOfString:@";" withString:@","];
	//y = [y stringByReplacingOccurrencesOfString:@"," withString:@"" options:0 range:NSMakeRange([y length]-10, 9)];
	y = [y stringByReplacingOccurrencesOfString:@"(" withString:@"{"];
	y = [y stringByReplacingOccurrencesOfString:@")" withString:@"}"];
	y = [y stringByReplacingOccurrencesOfString:@"\"\\\"" withString:@"\""];
	y = [y stringByReplacingOccurrencesOfString:@"\\\"\"" withString:@"\""];
	return y;
}

*/
	
- (IBAction)authorizeAction
{	
	//authorizeButton.enabled = NO;
	//authorizeDescriptionLabel.text = @"Logging in...";
    
    NSURL *loginURL = [[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext loginURLFromFrobDictionary:nil requestedPermission:OFFlickrWritePermission];
    [[UIApplication sharedApplication] openURL:loginURL];
}

-(void) submitInfo {
	if(!flickrRequest) {
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:[FlowerPowerNavBAppDelegate sharedDelegate].flickrContext];
        flickrRequest.delegate = self;
		flickrRequest.requestTimeoutInterval = 60.0;
	}
	NSLog(@"it's gonna upload");
	if(picture.imageView.image) {
		[self _startUpload:picture.imageView.image];
	}
	
	for(int i = 0; i<[tagVC.pictures count]; i++) {
		NSLog(@"iterating");
		[self _startUpload:[[tagVC.pictures objectAtIndex:i] objectAtIndex:0]];
	}
	/*if(paint.pic) {
		NSLog(@"in if");
		[self _startUpload:paint.pic];
	}*/
	
}
#pragma mark -
#pragma mark Posting
	
- (NSString*)processLog {
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
	
	df.dateStyle = NSDateFormatterLongStyle;
	[df setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
	NSDate *date =[NSDate date];
	NSString *today = [df stringFromDate:(NSDate *)date];
	NSLog(@"%@",today);
	[df release];
	NSString *lprocessed = [NSString stringWithFormat:@"Log %@\n",today];
	
	NSString *y = [[NSString alloc]init];

	
	for (int i = 1; i < [log_ count]; i++) {
		NSString *z = [NSString stringWithFormat:@"%d: %@\n",i,[log_ objectAtIndex:i]];
		NSLog(@"iterating: %@", z);
		if ([[z substringFromIndex:[z length] -1] isEqualToString: @","]) {
			z = [z substringToIndex:[z length] -1];
		}
		y = [y stringByAppendingString:z];
	}
	lprocessed = [lprocessed stringByAppendingString:@"\n"];
	y = [y stringByReplacingOccurrencesOfString:@"=" withString:@":"];
	y = [y stringByReplacingOccurrencesOfString:@"1: " withString:@""];
	y = [y stringByReplacingOccurrencesOfString:@";" withString:@","];
	y = [y stringByReplacingOccurrencesOfString:@"," withString:@"" options:0 range:NSMakeRange([y length]-10, 9)];
	y = [y stringByReplacingOccurrencesOfString:@"(" withString:@"{"];
	y = [y stringByReplacingOccurrencesOfString:@")" withString:@"}"];
	y = [y stringByReplacingOccurrencesOfString:@"\"\\\"" withString:@"\""];
	y = [y stringByReplacingOccurrencesOfString:@"\\\"\"" withString:@"\""];
	//y = [lprocessed stringByAppendingString:y];
	return y;
}


//FFFFFIIIIIIIIXXXXXXX!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-(void)addLog {
	//NSString *hmm = [self processLog];
	/*
	NSString *pleasepleaseplease = [app_delegate.dataGathered JSONRepresentation];
	NSString *paramDataString = [NSString stringWithFormat:@"entry=%@", pleasepleaseplease];
	//paramDataString = [paramDataString stringByReplacingOccurrencesOfString:@"=" withString:@":"];
	NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
	
	NSLog(@"this is the log: %@", paramDataString);
	
	//NSString *parsed = [self parsedJSON];
	//NSLog(@"here's a trial log: %@", parsed);
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
	//[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~davistui/iPhone/add2.php"]];
	//[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~hcilab/add.php"]];
	[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_entry"]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	//NSString *trial = [NSString stringWithFormat:@"entry=%@",/*paramData];
	//NSLog(@"%@",trial);
	[request setHTTPBody: paramData];
	
	NSURLResponse *urlResponse;	
	NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:nil];
	NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	NSLog(@"made it to end of addLog");
	NSLog(@"%@", urlResponse);
	NSLog(@"%@", data);
	//NSLog(@"%@", )
	NSLog(@"%@", tData);
	[tData release];
	//[hmm release];
	[request release];
	//[paramDataString release];
	//[paramData release];
	//[urlResponse release];
	//[data release];
	 */
	if(!(app_delegate.totalDataGathered)) {
		app_delegate.totalDataGathered = [[NSMutableArray alloc] init];
	}
	[app_delegate.totalDataGathered addObject:app_delegate.newEntryData];
	
	
}

-(void)updateLog:(NSString*)act {
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
		
	df.dateStyle = NSDateFormatterLongStyle;
	[df setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
	NSDate *date =[NSDate date];
	NSString *today = [df stringFromDate:(NSDate *)date];
	NSLog(@"%@",today);
	[self.log_ addObject:today];
	[df release];
	
	//[self.log_ addObject:[NSDate date]];
	[self.log_ addObject:act];
	
}
	
	- (void)_startUpload:(UIImage *)image
{
	NSLog(@"adding images to app delegate");
	if (!(app_delegate.pics)) {
		app_delegate.pics = [[NSMutableArray alloc] init];
	}
	[app_delegate.pics addObject:image];
	[app_delegate.picPlants addObject:app_delegate.currentPlant];
	/*
	if(image) {
		NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
    
	//snapPictureButton.enabled = NO;
	//snapPictureDescriptionLabel.text = @"Uploading";
	
    self.flickrRequest.sessionInfo = @"kUploadImageStep";
    [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] 
						suggestedFilename:@"Demo" MIMEType:@"image/jpeg" 
					arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"WCBotany", @"tags", @"0", @"is_public", nil]];
	 
	
	}
	 */
	//NSLog(@"upload?");
	//[UIApplication sharedApplication].idleTimerDisabled = YES;
	 
	//[self updateUserInterface:nil];
}


# pragma mark -
# pragma mark LocationGetter Delegate Methods
	
	- (void)newPhysicalLocation:(CLLocation *)location {
		
		// Store for later use
		self.lastKnownLocation = location;
		
		// Remove spinner from view
		/*for (UIView *v in [self.viewController.view subviews])
		{
			if ([v class] == [UIActivityIndicatorView class])
			{
				[v removeFromSuperview];
				break;
			}
		}*/
		
		// Alert user
		/*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Location Found" 
														message:[NSString stringWithFormat:
																 @"Found physical location.  %f %f", 
																 self.lastKnownLocation.coordinate.latitude, 
																 self.lastKnownLocation.coordinate.longitude] 
													   delegate:nil 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles: nil];
		[alert show];
		[alert release];
		*/
		// ... continue with initialization of your app
		
		[app_delegate.newEntryData setValue:[NSString stringWithFormat:
											 @"Found physical location.  %f %f", 
											 self.lastKnownLocation.coordinate.latitude, 
											 self.lastKnownLocation.coordinate.longitude] 
									 forKey:@"location"];

		
	}
	

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [controllers_ count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    //[self configureCell:cell atIndexPath:indexPath];
    
	//Grab menu labels for menu table
	NSUInteger row = [indexPath row];
	cell.textLabel.text = [controller_names objectAtIndex:row];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	//cell.textLabel.backgroundColor = [UIColor yellowColor];
	
	UIImage *img = [UIImage alloc];
	
	
	switch (row) {
		case 0:
			img = [UIImage imageNamed: @"animal2.png"];
			cell.imageView.image = img;
			break;
		/*case 1:
			img = [UIImage imageNamed:@"paint2.png"];
			cell.imageView.image = img;
			break;*/
		case 1:
			img = [UIImage imageNamed:@"sketches.png"];
			cell.imageView.image = img;
			break;
		case 2:
			img = [UIImage imageNamed:@"sketches.png"];
			cell.imageView.image = img;
			break;
		case 3:
			img = [UIImage imageNamed:@"nose.png"];
			cell.imageView.image = img;
			break;
		case 4:
			img = [UIImage imageNamed:@"coments2.png"];
			cell.imageView.image = img;
			break;
		default:
			break;
	}
	
	
	
	
    return cell;
}



#pragma mark OFFlickrAPIRequest delegate methods
- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	NSLog(@"Hi!");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inResponseDictionary);
    
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//snapPictureDescriptionLabel.text = @"Setting properties...";
		
        //NSLog(@"Hi 2");
        NSLog(@"%@", inResponseDictionary);
        NSString *photoID = [[inResponseDictionary valueForKeyPath:@"photoid"] textContent];
		
        flickrRequest.sessionInfo = @"kSetImagePropertiesStep";
        [flickrRequest callAPIMethodWithPOST:@"flickr.photos.setMeta" arguments:[NSDictionary dictionaryWithObjectsAndKeys:photoID, @"photo_id", @"Snap and Run", @"title", @"Uploaded from my iPhone/iPod Touch", @"description", nil]];        		        
	}
    else if ([inRequest.sessionInfo isEqualToString: @"kSetImagePropertiesStep"]) {
		//[self updateUserInterface:nil];		
		//snapPictureDescriptionLabel.text = @"Done";
        
		[UIApplication sharedApplication].idleTimerDisabled = NO;		
        
    }
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didFailWithError:(NSError *)inError
{
	NSLog(@"Hi 3");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inError);
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//[self updateUserInterface:nil];
		//snapPictureDescriptionLabel.text = @"Failed";		
		[UIApplication sharedApplication].idleTimerDisabled = NO;
		
		//[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
		
	}
	else {
		//[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
	}
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest imageUploadSentBytes:(NSUInteger)inSentBytes totalBytes:(NSUInteger)inTotalBytes
{
	if (inSentBytes == inTotalBytes) {
		//snapPictureDescriptionLabel.text = @"Waiting for Flickr...";
	}
	else {
		//snapPictureDescriptionLabel.text = [NSString stringWithFormat:@"%lu/%lu (KB)", inSentBytes / 1024, inTotalBytes / 1024];
	}
}




#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    NSUInteger row=[indexPath row];
	
	self.title = [NSString stringWithFormat:@"Back"];
	
	UIViewController *nextController =[self.controllers_ objectAtIndex:row];
	[app_delegate.navigationController pushViewController:nextController animated:YES];
	
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

