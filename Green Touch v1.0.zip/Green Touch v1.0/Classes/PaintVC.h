//
//  PaintVC.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 3/30/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>


@class PaintingWindow;
@class PaintingView;
@class SoundEffect;

@interface PaintVC : UIViewController 
{
	PaintingWindow		*window;
	PaintingView		*drawingView;
	
	SoundEffect			*erasingSound;
	SoundEffect			*selectSound;
	CFTimeInterval		lastTime;
	UIImage *pic;
}

@property (nonatomic, retain) IBOutlet PaintingWindow *window;
@property (nonatomic, retain) IBOutlet PaintingView *drawingView;
@property (nonatomic, retain) UIImage *pic;

@end
