//
//  HowMany.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/8/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
# import "Notes.h"
#import "SurveyGallery.h"

@class FlowerPowerNavBAppDelegate;


@interface HowMany : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {

	FlowerPowerNavBAppDelegate *app_delegate;
	Notes *notesView; 
	SurveyGallery *surveyGallery;
	
	UITextView *text;
	UIPickerView *picker;
	UIButton *button;
	NSArray *array; 
	
}

@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) Notes *notesView; 
@property (nonatomic, retain) SurveyGallery *surveyGallery;

@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) IBOutlet UIButton *button; 
@property (nonatomic, retain) IBOutlet UITextView *text; 
@property (nonatomic, retain) NSArray *array; 

-(IBAction) buttonPressed : (id) sender; 

@end
