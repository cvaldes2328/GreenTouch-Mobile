//
//  JournalByDayTable.h
//  FlowerPower
//
//  Created by HCI Lab on 3/18/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface JournalByDayTable : UITableViewController {

}

@end
