//
//  JournalMain.m
//  FlowerPower
//
//  Created by HCI Lab on 3/17/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//
 
#import "JournalMain.h"


@implementation JournalMain
@synthesize tabController, byDayView, overTimeView, byDays;

-(IBAction) backButtonPressed: (id)sender {
	//[((FlowerPowerAppDelegate *)[[UIApplication sharedApplication] delegate]).viewController.view 
	[self.view removeFromSuperview];
}

-(IBAction) changedView: (id) sender{
	if(tabController.selectedSegmentIndex==0) {//over time
		[overTimeView setHidden:NO];
		[byDays setHidden:YES];
		NSLog(@"it was 0");
	} else { //by day
		[overTimeView setHidden:YES];
		[byDays setHidden:NO];
	}

}
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 5;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    NSLog(@"jgghvbvv");
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    NSLog(@"jgghvbasdasdavv");	
	//NSLog(@"list: %@", list);
	switch (indexPath.row) {
		case 0:
			cell.textLabel.text = @"First observation";
			    NSLog(@"jgghvbvvadasdasdasfsad");
			break;
		case 1:
			cell.textLabel.text = @"Second observation";
			break;
		case 2:
			cell.textLabel.text = @"Third observation";
			break;
		case 3:
			cell.textLabel.text = @"Fourth observation";
			break;
		case 4:
			cell.textLabel.text = @"Fifth observation";
			break;
		default:
			break;
	}

	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	    NSLog(@"jgghvbdsffffffffffffffffffffffffffffffffffvv");
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}


- (void)dealloc {
    [super dealloc];
}


@end
