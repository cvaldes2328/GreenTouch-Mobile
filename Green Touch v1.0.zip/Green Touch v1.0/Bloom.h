//
//  Bloom.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/8/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Photo.h"


@class FlowerPowerNavBAppDelegate;

@interface Bloom : UITableViewController <UINavigationControllerDelegate, UIActionSheetDelegate, UIImagePickerControllerDelegate> {

//@interface Bloom : UITableViewController {

	FlowerPowerNavBAppDelegate *app_delegate;
	Photo *photoView;
	
	UIButton *addButton;
	UIButton *menuButton;
	
	NSMutableArray *array;
	
}
@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) Photo *photoView; 

@property (nonatomic, retain) IBOutlet UIButton *addButton;
@property (nonatomic, retain) IBOutlet UIButton *menuButton;
@property (nonatomic, retain) NSMutableArray *array; 

-(IBAction) addButtonPressed: (id) sender;
-(IBAction) menuButtonPressed: (id) sender; 

@end
