//
//  Notes.h
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/8/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SurveyGallery.h"
//#import "Bloom.h"

@class FlowerPowerNavBAppDelegate;


@interface Notes : UIViewController <UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>{
	
	FlowerPowerNavBAppDelegate *app_delegate;
	SurveyGallery *surveyGallery;
//	Bloom *bloomView; 
	
	UIButton *labelPic;
	IBOutlet UITextView *notes; 
	
	IBOutlet UIScrollView *sview; 
	
}

@property (nonatomic, retain) FlowerPowerNavBAppDelegate *app_delegate;
@property (nonatomic, retain) SurveyGallery *surveyGallery;
//@property (nonatomic, retain) Bloom *bloomView; 

@property (nonatomic, retain) IBOutlet UIButton *labelPic; 
@property (nonatomic, retain) IBOutlet UITextView *notes; 

@property (nonatomic, retain) IBOutlet UIScrollView *sview; 

-(IBAction) keyboardButtonPressed: (id) sender; 
-(IBAction) buttonPressed: (id) sender; 
-(IBAction) picPressed: (id) sender; 

@end
