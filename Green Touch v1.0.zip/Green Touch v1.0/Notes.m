//
//  Notes.m
//  FlowerPowerNavB
//
//  Created by HCI Lab on 6/8/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "Notes.h"
#import "FlowerPowerNavBAppDelegate.h"

@implementation Notes
@synthesize notes, labelPic, sview, app_delegate, surveyGallery; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (FlowerPowerNavBAppDelegate *)[[UIApplication sharedApplication] delegate];
	notes.layer.borderWidth = 1.0f;
	self.title = @"Notes";
	[super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
-(IBAction) keyboardButtonPressed: (id) sender {
	
	[notes resignFirstResponder];
	[sview setContentOffset:CGPointZero animated:YES];
	
}
- (void)textViewDidBeginEditing:(UITextView *)textField
{	
	[sview setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 50) animated:YES];	
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	//[text_field resignFirstResponder];
	[sview setContentOffset:CGPointZero animated:YES];
	return YES;
}

//pops three screens, goes to Bloom screen with new entry
-(IBAction) buttonPressed: (id) sender {
	
	
	//	[app_delegate.navigationController popViewController Animated:YES]; // current
	//	[app_delegate.navigationController popViewControllerAnimated:YES]; // how many
	//	[app_delegate.navigationController popViewControllerAnimated:YES]; // pictures
	//	[app_delegate.navigationController popViewControllerAnimated:YES]; //where

	//[surveyGallery addNewPicture];
	NSArray *allViewControllers = self.navigationController.viewControllers; 
	NSInteger n = [allViewControllers count];
	[surveyGallery.currentInfo appendFormat:@" %@", [surveyGallery.numberOfPlants stringByReplacingOccurrencesOfString:@"," withString:@""]];
	[self.navigationController popToViewController:[allViewControllers objectAtIndex:(n-4)] animated:NO];
	
}

//takes to the camera, and changes the image of the button based on the image taken
-(IBAction) picPressed: (id) sender {
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}
	
	[self presentModalViewController:imagePicker animated:YES];

}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		[[surveyGallery.views objectAtIndex:[surveyGallery.views count]-1] addObject:image];
		labelPic.imageView.image = image;
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
@end
