//
//  EdibleTreeShrubPhenology.m
//  WellesleyNature
//
//  Created by HCI Lab on 1/18/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "EdibleTreeShrubPhenology.h"

@implementation EdibleTreeShrubPhenology

@synthesize app_delegate, phenologyDictionary, measuresDictionary, questionLabel, questionSegControl, optionsPicker, picturesDict, imageButton, nextButton;
@synthesize fruitField, fruitStepper, scrollViewForKeyboard;
@synthesize lastMeasure, lastMeasureValue; 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction) fruitStepperUpdate: (id)sender{
    //UIStepper *heightStepper = (UIStepper *)sender;
    fruitField.text = [NSString stringWithFormat:@"%d", (int)fruitStepper.value];
}

-(IBAction)backgroundButtonClose: (id) sender {
    [fruitField resignFirstResponder]; 
    [fruitStepper resignFirstResponder];
    [fruitStepper setValue:[fruitField.text doubleValue]];
    [scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}

#pragma mark - SegControl

-(NSString *) stringForSelectedIndex {
    switch (questionSegControl.selectedSegmentIndex) {
        case 0:
            return @"leaf";
        case 1:
            return @"flower";
        case 2:
            return @"fruit";
        case 3:
            return @"overall";
        default:
            return @"fail";
    }
}

-(IBAction)nextButtonPressed:(id)sender {
    if (questionSegControl.selectedSegmentIndex<2) {
        questionSegControl.selectedSegmentIndex++;
        [self QuestionChanged:questionSegControl];
    } else if (questionSegControl.selectedSegmentIndex==2) {
        questionSegControl.selectedSegmentIndex++;
        [nextButton setTitle:@"Done" forState:UIControlStateNormal]; 
        [self QuestionChanged:questionSegControl];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}


#pragma mark KeyboardStuff

- (void)resizeRestore {
	[fruitField resignFirstResponder];
	[scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   // NSLog(@"text field returning");
	[fruitField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	[app_delegate updateLog:[NSString stringWithFormat:@"%@: Typing in Phenology", [NSDate date]]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
    NSLog(@"began editing");
	[scrollViewForKeyboard setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 100) animated:YES];	
}

/*
 Update label and picker based on measure selected
 */
-(IBAction)QuestionChanged:(UISegmentedControl *)sender{
    NSDictionary *accessionDictionary = [app_delegate.lastMeasureDictionary objectForKey:app_delegate.plantAccession]; 
    NSDictionary *phenologyDictionaryMeasures = [accessionDictionary objectForKey:@"phenology"];
    if (questionSegControl.selectedSegmentIndex == 0){
        //Leaf
        NSDictionary *leaf = [phenologyDictionary valueForKey:@"Leaf"];
        [questionLabel setText:[leaf valueForKey:@"Question"]];
        [optionsPicker selectRow:[[measuresDictionary valueForKey:@"leaf"] intValue] inComponent:0 animated:NO];
        [nextButton setTitle:@"Next" forState:UIControlStateNormal]; 
        [optionsPicker setHidden:NO]; 
        
        int i = [[phenologyDictionaryMeasures objectForKey:@"leaf"] intValue];
        if(app_delegate.lastMeasureDictionary){
            if (i==0) {
                lastMeasureValue.text = @"dormant";
            } else if(i==2) {
                lastMeasureValue.text = @"expanded";
            } else if(i==3) {
                lastMeasureValue.text = @"<1cm long";
            } else if(i==4) {
                lastMeasureValue.text = @"1-2cm long";
            } else {
                lastMeasureValue.text = @">2cm long";
            }
        } else {
            lastMeasure.hidden = TRUE;
            lastMeasureValue.hidden=TRUE; 
        }
        
    }else if (questionSegControl.selectedSegmentIndex == 1){
        //flower
        NSDictionary *flower = [phenologyDictionary valueForKey:@"Flower"];
        [optionsPicker selectRow:[[measuresDictionary valueForKey:@"flower"] intValue] inComponent:0 animated:NO];
        [questionLabel setText:[flower valueForKey:@"Question"]];
        [nextButton setTitle:@"Next" forState:UIControlStateNormal]; 
        [optionsPicker setHidden:NO]; 
        
        int i = [[phenologyDictionaryMeasures objectForKey:@"flower"] intValue];
        if(app_delegate.lastMeasureDictionary){
            if (i==0) {
                lastMeasureValue.text = @"none";
            } else if(i==2) {
                lastMeasureValue.text = @"bud w/o color";
            } else if(i==3) {
                lastMeasureValue.text = @"bud w/color";
            } else if(i==4) {
                lastMeasureValue.text = @"bud open";
            } else {
                lastMeasureValue.text = @"bud past";
            }
        } else {
            lastMeasure.hidden = TRUE;
            lastMeasureValue.hidden=TRUE; 
        }
        
    }else if (questionSegControl.selectedSegmentIndex == 2){
        //fruit
        NSDictionary *fruit = [phenologyDictionary valueForKey:@"Fruit"];
        [questionLabel setText:[fruit valueForKey:@"Question"]];
        
        //for picker implementation 
        [optionsPicker reloadAllComponents];
        int value = [[measuresDictionary valueForKey:@"fruit"] intValue];
        [optionsPicker selectRow:value/100 inComponent:0 animated:NO];
        [optionsPicker selectRow:value%10 inComponent:2 animated:NO];
        [optionsPicker selectRow:(value%100)/10 inComponent:1 animated:NO];
        [nextButton setTitle:@"Next" forState:UIControlStateNormal]; 
        
        //for stepper implementation
        [optionsPicker setHidden:YES];
        fruitStepper.value = (int)[phenologyDictionary valueForKey:@"fruit"];
        [fruitField setText:[NSString stringWithFormat:@"%d", (int)fruitStepper.value]];
        
        if(app_delegate.lastMeasureDictionary) {
            [lastMeasureValue setText:[[phenologyDictionaryMeasures objectForKey:@"fruit"] stringValue]];
        } else {
            lastMeasure.hidden = TRUE;
            lastMeasureValue.hidden=TRUE;
        }
        
    } else if (questionSegControl.selectedSegmentIndex == 3){
        //overall bloom
        NSDictionary *bloom = [phenologyDictionary valueForKey:@"Overall"];
        [optionsPicker selectRow:[[measuresDictionary valueForKey:@"overall"] intValue] inComponent:0 animated:NO];
        [questionLabel setText:[bloom valueForKey:@"Question"]];
        [nextButton setTitle:@"Done" forState:UIControlStateNormal]; 
        [optionsPicker setHidden:NO]; 
        int i = [[phenologyDictionaryMeasures objectForKey:@"overall"] intValue];
        
        if(app_delegate.lastMeasureDictionary){
            if (i==0) {
                lastMeasureValue.text = @"none";
            } else if(i==2) {
                lastMeasureValue.text = @"beginning";
            } else if(i==3) {
                lastMeasureValue.text = @"early";
            } else if(i==4) {
                lastMeasureValue.text = @"peak";
            } else if(i==5){
                lastMeasureValue.text = @"late";
            } else {
                lastMeasureValue.text = @"post-bloom";
            }
        } else {
            lastMeasure.hidden = TRUE;
            lastMeasureValue.hidden=TRUE; 
        }
        
    }
    UIImage *image = [picturesDict objectForKey:[self stringForSelectedIndex]];
    if(image) {
        NSLog(@"setting image");
        [imageButton setImage:image forState:UIControlStateSelected];
        [imageButton setImage:image forState:UIControlStateNormal];
        [imageButton setHidden:NO];
    } else {
        NSLog(@"image button hidden");
        [imageButton setHidden:YES];
    }
    [optionsPicker reloadAllComponents];
}


#pragma mark - PickerView

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if (questionSegControl.selectedSegmentIndex == 2)
        return 3;
    else
        return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
        if (questionSegControl.selectedSegmentIndex == 0){
            //Leaf
            NSDictionary *leaf = [phenologyDictionary valueForKey:@"Leaf"];
            NSArray *options = [leaf valueForKey:@"Options"];
            return [options count];
        }else if (questionSegControl.selectedSegmentIndex == 1){
            //flower
            NSDictionary *flower = [phenologyDictionary valueForKey:@"Flower"];
            NSArray *options = [flower valueForKey:@"Options"];
            return [options count];
        } else if (questionSegControl.selectedSegmentIndex == 2){
            //overall fruit
            NSDictionary *fruit = [phenologyDictionary valueForKey:@"Fruit"];
            NSArray *options = [fruit valueForKey:@"Options"];
            return [options count];
        } else {
            //overall bloom
            NSDictionary *bloom = [phenologyDictionary valueForKey:@"Overall"];
            NSArray *options = [bloom valueForKey:@"Options"];
            return [options count];
        }
    
}

- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{	

        if (questionSegControl.selectedSegmentIndex == 0){
            //Leaf
            NSDictionary *leaf = [phenologyDictionary valueForKey:@"Leaf"];
            NSArray *options = [leaf valueForKey:@"Options"];
            return [options objectAtIndex:row];
        }else if (questionSegControl.selectedSegmentIndex == 1){
            //flower
            NSDictionary *flower = [phenologyDictionary valueForKey:@"Flower"];
            NSArray *options =  [flower valueForKey:@"Options"];
            return [options objectAtIndex:row];
        } else if (questionSegControl.selectedSegmentIndex == 2){
            //overall fruit
            NSDictionary *fruit = [phenologyDictionary valueForKey:@"Fruit"];
            NSArray *options = [fruit valueForKey:@"Options"];
            return [options objectAtIndex:row];
        } else {
            //overall bloom
            NSDictionary *bloom = [phenologyDictionary valueForKey:@"Overall"];
            NSArray *options =  [bloom valueForKey:@"Options"];
            return [options objectAtIndex:row];
        }
	
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
	//NSLog(@"%@", [NSNumber numberWithInt:[pickerView selectedRowInComponent:0]]);
    
    //NSNumber *selected = [NSNumber numberWithInt:[pickerView selectedRowInComponent:0]];
        if (questionSegControl.selectedSegmentIndex == 0){
            NSLog(@"going to set for seg 0");
            //[springMeasuresDictionary setObject:[NSNumber numberWithInt:[optionsPicker selectedRowInComponent:0]] forKey:@"leaf"];
            [measuresDictionary setValue:[NSNumber numberWithInt:row] forKey:@"leaf"];
            NSLog(@"set");
        }else if (questionSegControl.selectedSegmentIndex == 1){
            //flower
            [measuresDictionary setValue:[NSNumber numberWithInt:row] forKey:@"flower"];  
        } else if (questionSegControl.selectedSegmentIndex == 2){
            //fruit
            
            /* picker implementation
            [measuresDictionary setValue:[NSNumber numberWithInt:100*[optionsPicker selectedRowInComponent:0]+10*[optionsPicker selectedRowInComponent:1]+[optionsPicker selectedRowInComponent:2]] forKey:@"fruit"];
            */
            
            //stepper implementation
            [measuresDictionary setValue:[NSNumber numberWithInt:(int)fruitStepper.value] forKey:@"fruit"];
        }else {
            //overall bloom
            [measuresDictionary setValue:[NSNumber numberWithInt:row] forKey:@"overall"];            
        }
    
}


#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
		//[viewPicturesLabel setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
        NSLog(@"setting image");
        [imageButton setImage:image forState:UIControlStateNormal];
        [imageButton setImage:image forState:UIControlStateSelected];
        [imageButton setHidden:NO];
        [picturesDict setObject:image forKey:[self stringForSelectedIndex]];
		//[pictures addObject:[[NSArray alloc] initWithObjects: image, selectedType, nil]];
		//UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		////newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
        //newView.frame = CGRectMake(45-40, 10, 40, 60);
		//[self.picturesScrollView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
    
    
    -(IBAction) buttonPressed: (id)sender {
        //UIButton *button = (UIButton *)sender;
        [app_delegate updateLog:[NSString stringWithFormat:@"%@: Taking picture in Phenology", [NSDate date]]];
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        } else {
            return;
        }
        
        [self presentModalViewController:imagePicker animated:YES];
    }


#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //load plist with measures info
    //start with spring
    NSBundle *bundle = [NSBundle mainBundle];
    NSDictionary *temporary = [[NSDictionary alloc] initWithContentsOfFile:[bundle pathForResource:@"PhenologyMeasures" ofType:@"plist"]];
    phenologyDictionary = [[NSDictionary alloc] init];
    phenologyDictionary = [temporary valueForKey:@"EdibleEcosystem"];
    
    measuresDictionary = [app_delegate.entryData objectForKey:@"phenology"];
    if(!measuresDictionary) {
        measuresDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                [NSNumber numberWithInt:0], @"leaf",
                                [NSNumber numberWithInt:0], @"flower",
                                [NSNumber numberWithInt:0], @"fruit",
                                [NSNumber numberWithInt:0], @"overall", nil];
    }
    [app_delegate updateLog:[NSString stringWithFormat:@"%@: Loaded phenology page", [NSDate date]]];
    [self.navigationItem setHidesBackButton:YES];
    //start with leaf
    NSDictionary *leafStart = [phenologyDictionary valueForKey:@"Leaf"];
    [questionLabel setText:[leafStart valueForKey:@"Question"]];
    [optionsPicker selectRow:[[measuresDictionary valueForKey:@"leaf"] intValue] inComponent:0 animated:NO];
    picturesDict = [[NSMutableDictionary alloc] init];
}

-(void) viewWillDisappear:(BOOL)animated {
	//NSLog(@"Made it to the view disappearing!");	
    //now, add things to the measures dictionary
    //[measuresDictionary setValue:<#(id)#> forKey:<#(NSString *)#>
    //below is images; changed around to avoid images entirely for week of 4/2
    //[measuresDictionary setValue:[NSMutableArray arrayWithArray:[picturesDict allValues]] forKey:@"images"];
	[measuresDictionary setValue:[[NSArray alloc] init] forKey:@"images"];
    [app_delegate.entryData setValue:measuresDictionary forKey:@"phenology"];
    NSLog(@"%@", app_delegate.entryData);
	[super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
