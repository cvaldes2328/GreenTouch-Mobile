//
//  EdibleTreeShrubPhenology.h
//  WellesleyNature
//
//  Created by HCI Lab on 1/18/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface EdibleTreeShrubPhenology : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate, UIImagePickerControllerDelegate>{
    
    AppDelegate *app_delegate;
    
    NSDictionary *phenologyDictionary;
    NSMutableDictionary *measuresDictionary;
    NSMutableDictionary *picturesDict;
    
    UISegmentedControl *questionSegControl;
    
    UILabel *questionLabel;
    UIPickerView *optionsPicker;
    UIButton *imageButton;
    UIButton *nextButton; 
    
    UIStepper *fruitStepper;
    UITextField *fruitField; 
    UIScrollView *scrollViewForKeyboard;
    
    UILabel *lastMeasure;
    UILabel *lastMeasureValue;
    
}

@property (nonatomic, retain) AppDelegate *app_delegate;

@property (nonatomic, retain) NSDictionary *phenologyDictionary;
@property (nonatomic, retain) NSMutableDictionary *measuresDictionary;
@property (nonatomic, retain) NSMutableDictionary *picturesDict;

@property(nonatomic, retain) IBOutlet UISegmentedControl *questionSegControl;

@property(nonatomic, retain) IBOutlet UILabel *questionLabel;
@property(nonatomic, retain) IBOutlet UIPickerView *optionsPicker;
@property (nonatomic, retain) IBOutlet UIButton *imageButton;
@property (nonatomic, retain) IBOutlet UIButton *nextButton; 

@property (nonatomic, retain) IBOutlet UIStepper *fruitStepper; 
@property (nonatomic, retain) IBOutlet UITextField *fruitField; 
@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForKeyboard;

@property(nonatomic, retain) IBOutlet UILabel *lastMeasure;
@property(nonatomic, retain) IBOutlet UILabel *lastMeasureValue;

-(IBAction)QuestionChanged:(UISegmentedControl *)sender;
-(IBAction)nextButtonPressed:(id)sender;
-(IBAction)fruitStepperUpdate:(id)sender;
-(IBAction)backgroundButtonClose:(id)sender;

@end
