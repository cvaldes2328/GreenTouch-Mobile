//
//  AnimalEvidenceViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 12/30/11.
//  Copyright (c) 2011 Wellesley College. All rights reserved.
//

#import "AnimalEvidenceViewController.h"
#import "AppDelegate.h"

@implementation AnimalEvidenceViewController

//textfields
@synthesize app_delegate, answers, leafTextField, flowerTextField, stemTextField, fruitTextField;
//camera buttons
@synthesize leafPicture, flowerPicture, stemPicture, fruitPicture, stemStepper, flowerStepper, fruitStepper, leafStepper;
//display stuff
@synthesize scrollViewForKeyboard, picturesScrollView, viewPicturesLabel, pictures;
//last measure
@synthesize lastMeasure, lastFlower, lastStem, lastFruit, lastLeaf; 



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Stepper Methods

-(IBAction)leafStepperPressed:(UIStepper *)sender{
    
    double value = [sender value];
    [leafTextField setText:[NSString stringWithFormat:@"%d", (int)value]];
}

-(IBAction)flowerStepperPressed:(UIStepper *)sender{
    double value = [sender value];
    [flowerTextField setText:[NSString stringWithFormat:@"%d", (int)value]];
}

-(IBAction)stemStepperPressed:(UIStepper *)sender{
    double value = [sender value];
    [stemTextField setText:[NSString stringWithFormat:@"%d", (int)value]];
}

-(IBAction)fruitStepperPressed:(UIStepper *)sender{
    double value = [sender value];
    [fruitTextField setText:[NSString stringWithFormat:@"%d", (int)value]];
}

#pragma mark KeyboardStuff

- (void)resizeRestore {
	[leafTextField resignFirstResponder];
    [flowerTextField resignFirstResponder];
    [stemTextField resignFirstResponder];
	[scrollViewForKeyboard setContentOffset:CGPointZero animated:YES];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //NSLog(@"text field returning");
	[leafTextField resignFirstResponder];
    [flowerTextField resignFirstResponder];
    [stemTextField resignFirstResponder];
    [fruitTextField resignFirstResponder];
	[self resizeRestore];
	/*if (!was_answered) {
     //app_delegate.number_of_questions_answered++;
     was_answered = YES;
     }*/
	[app_delegate updateLog:[NSString stringWithFormat:@"%@: Typed in own answer to Animal Evidence",[NSDate date]]];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{	
    //NSLog(@"began editing");
	[scrollViewForKeyboard setContentOffset:CGPointMake(0.0, textField.frame.origin.y - 150) animated:YES];	
}



- (IBAction) backgroundButton
{
    //NSLog(@"background button");
	//[app_delegate updateLog:[NSString stringWithFormat:@"Typed in own answer to tag ?: %@", text_field.text]];
	[leafTextField resignFirstResponder];
    [flowerTextField resignFirstResponder];
    [stemTextField resignFirstResponder];
    [fruitTextField resignFirstResponder];
    [leafStepper setValue:[leafTextField.text doubleValue]];
    [flowerStepper setValue:[flowerTextField.text doubleValue]];
    [stemStepper setValue:[stemTextField.text doubleValue]];
    [fruitStepper setValue:[fruitTextField.text doubleValue]];
	[self resizeRestore];
}

-(IBAction)nextButtonPressed:(id)sender {
    [self viewWillDisappear:YES];
    [self.navigationController popViewControllerAnimated:YES];

}

#pragma mark UIImagePickerController delegate methods
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

/*- (void)_startUpload:(UIImage *)image
 {
 NSData *JPEGData = UIImageJPEGRepresentation(image, 1.0);
 
 snapPictureButton.enabled = NO;
 snapPictureDescriptionLabel.text = @"Uploading";
 
 self.flickrRequest.sessionInfo = kUploadImageStep;
 [self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] suggestedFilename:@"Demo" MIMEType:@"image/jpeg" arguments:[NSDictionary dictionaryWithObjectsAndKeys:@"0", @"is_public", nil]];
 NSLog(@"upload?");
 [UIApplication sharedApplication].idleTimerDisabled = YES;
 [self updateUserInterface:nil];
 }
 */
#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);

		[viewPicturesLabel setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		[pictures addObject:image];
		UIImageView *newView = [[UIImageView alloc] initWithImage:image];
		newView.frame = CGRectMake(45*[pictures count]-40, 10, 40, 60);
        //newView.frame = CGRectMake(45-40, 10, 40, 60);
		[self.picturesScrollView addSubview:newView];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
	}
	
    
    
    -(IBAction) buttonPressed: (id)sender {
        //UIButton *button = (UIButton *)sender;
        //NSLog(@"hit button for picture");
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        } else {
            return;
        }
        
        [self presentModalViewController:imagePicker animated:YES];
    }
    
#pragma mark - View lifecycle
    
    /*
     // Implement loadView to create a view hierarchy programmatically, without using a nib.
     - (void)loadView
     {
     }
     */
    
    
    // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
    - (void)viewDidLoad
    {
        [super viewDidLoad];
        app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //NSLog(@"app delegate is %@", app_delegate);
        //NSLog(@"entry data is %@", app_delegate.entryData);
        pictures = [[NSMutableArray alloc] init];
        
        //if data already taken, display last measure
        if(app_delegate.lastMeasureDictionary){
            NSDictionary *accessionDictionary = [app_delegate.lastMeasureDictionary objectForKey:app_delegate.plantAccession]; 
            NSDictionary *animalsDictionary = [accessionDictionary objectForKey:@"animals"];
            lastLeaf.text = [[animalsDictionary objectForKey:@"leaf"] stringValue]; 
            lastFruit.text = [[animalsDictionary objectForKey:@"fruit"] stringValue]; 
            lastFlower.text = [[animalsDictionary objectForKey:@"flower"] stringValue]; 
            lastStem.text = [[animalsDictionary objectForKey:@"stem"] stringValue]; 
        } else { //hide display
            lastMeasure.hidden = TRUE; 
            lastLeaf.hidden = TRUE;
            lastFruit.hidden = TRUE;
            lastFlower.hidden = TRUE;
            lastStem.hidden = TRUE; 
        }
    }
    
    -(void) viewWillAppear:(BOOL)animated {
        
        NSMutableDictionary *animalsDict = [app_delegate.entryData objectForKey:@"animals"];
        if(animalsDict) {
           // NSLog(@"had a dict, filling in old values");
            leafStepper.value = [[animalsDict objectForKey:@"leaf"] doubleValue]; 
            stemStepper.value = [[animalsDict objectForKey:@"stem"] doubleValue]; 
            flowerStepper.value = [[animalsDict objectForKey:@"flower"] doubleValue]; 
            fruitStepper.value = [[animalsDict objectForKey:@"fruit"] doubleValue]; 
            pictures = [animalsDict objectForKey:@"images"];
            
            [leafTextField setText:[NSString stringWithFormat:@"%d", (int)leafStepper.value]];
            [stemTextField setText:[NSString stringWithFormat:@"%d", (int)stemStepper.value]];
            [flowerTextField setText:[NSString stringWithFormat:@"%d", (int)flowerStepper.value]];
            [fruitTextField setText:[NSString stringWithFormat:@"%d", (int)fruitStepper.value]];
        }
        [self.navigationItem setHidesBackButton:YES];
        [super viewWillAppear:animated];
        
    }
    
    -(void) viewWillDisappear:(BOOL)animated {
       // NSLog(@"app delegate is %@", app_delegate);
       // NSLog(@"entry data is %@", app_delegate.entryData);
        answers = [[NSMutableDictionary alloc] init];
        [answers setValue:[NSNumber numberWithInt:(int)leafStepper.value] forKey:@"leaf"];
        [answers setValue:[NSNumber numberWithInt:(int)stemStepper.value] forKey:@"stem"];
        [answers setValue:[NSNumber numberWithInt:(int)flowerStepper.value] forKey:@"flower"];
        [answers setValue:[NSNumber numberWithInt:(int)fruitStepper.value] forKey:@"fruit"];
        //below deals with images; changed around to avoid images for week of 4/2
        //[answers setValue:pictures forKey:@"images"];
        [answers setValue:[[NSMutableArray alloc] init] forKey:@"images"];
        
        [app_delegate.entryData setObject:answers forKey:@"animals"];
        
        //NSLog(@"%@", app_delegate.entryData);    
        [super viewWillDisappear:animated];
    }
    
    - (void)viewDidUnload
    {
        [super viewDidUnload];
        // Release any retained subviews of the main view.
        // e.g. self.myOutlet = nil;
    }
    
    - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
    {
        // Return YES for supported orientations
        return (interfaceOrientation == UIInterfaceOrientationPortrait);
    }
    
    @end
