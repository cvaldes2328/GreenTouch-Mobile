//
//  iPadHealth.h
//  WellesleyNature
//
//  Created by HCI Lab on 3/9/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iPadHealth : UIViewController

@end
