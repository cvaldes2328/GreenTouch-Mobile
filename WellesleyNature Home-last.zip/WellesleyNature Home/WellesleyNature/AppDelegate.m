//
//  AppDelegate.m
//  WellesleyNature
//
//  Created by HCI Lab on 12/29/11.
//  Copyright (c) 2011 Wellesley College. All rights reserved.
//

#import "AppDelegate.h"
//#import "ObjectiveFlickr.h"

NSString *SnapAndRunShouldUpdateAuthInfoNotification = @"SnapAndRunShouldUpdateAuthInfoNotification";
NSString *kStoredAuthTokenKeyName = @"FlickrAuthToken";
NSString *kGetAuthTokenStep = @"kGetAuthTokenStep";
NSString *kCheckTokenStep = @"kCheckTokenStep";

@implementation AppDelegate

@synthesize window = _window;

//Log
@synthesize stream_, log_;

@synthesize entryData, totalEdibleTreeDataGathered, totalEdibleGuildDataGathered, guildArray, totalSpringDataGathered, plantAccession, userNames/*, flickrRequest, flickrContext*/, lastMeasureDictionary;

- (NSString *)dataFilePath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(
                                                         NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:kdataFilename];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    entryData = [[NSMutableDictionary alloc]init];
    totalEdibleTreeDataGathered = [[NSMutableArray alloc] init];
    totalEdibleGuildDataGathered = [[NSMutableArray alloc] init];
    totalSpringDataGathered = [[NSMutableArray alloc] init];
    
    //Log set up
	self.log_ = [[NSMutableArray alloc]init];
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
    
    NSString *filePath = [self dataFilePath];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
		[self.totalSpringDataGathered writeToFile:filePath atomically:YES];
        //NSArray *array = [[NSArray alloc] initWithContentsOfFile:filePath];
        //NSLog(@"data after safe...\n%@", [[NSMutableArray alloc] initWithContentsOfFile:filePath]);
        //[array release];
    }
	[self.totalSpringDataGathered writeToFile:filePath atomically:YES];
    
    [self addLog];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Logging Methods

- (NSString*)processLog {
	NSString *lprocessed = [NSString stringWithFormat:@"Log %@\n",[NSDate date]];
	for (int i = 0; i < [log_ count]; i++) {
		NSString *y = [[NSString alloc]init];
		y = [NSString stringWithFormat:@"%d: %@\n",i,[log_ objectAtIndex:i]];
		lprocessed = [lprocessed stringByAppendingString:y];
	}
	lprocessed = [lprocessed stringByAppendingString:@"\n"];
	return lprocessed;
}

-(void)addLog {
	NSString *hmm = [self processLog];
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
	
	NSString *paramDataString = [NSString stringWithFormat:@"%@", hmm];
	NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
    
	NSLog(@"this is the log: %@", paramDataString);
    
	[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~davistui/iPhone/add.php"]];
	//[request setURL:[NSURL URLWithString:@"http://cs.wellesley.edu/~hcilab/Log/add.php"]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	[request setHTTPBody:paramData];
	
}

-(void)updateLog:(NSString*)act {
	[self.log_ addObject:act];
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//end Logging Methods


/*
- (OFFlickrAPIRequest *)flickrRequest
{
	if (!flickrRequest) {
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:self.flickrContext];
		flickrRequest.delegate = self;		
	}
	
	return flickrRequest;
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
	[self setAndStoreFlickrAuthToken:nil];
	// query has the form of "&frob=", the rest is the frob
	NSString *frob = [[url query] substringFromIndex:9];
	NSLog(@"%@", frob);
	[self flickrRequest].sessionInfo = kGetAuthTokenStep;
	[flickrRequest callAPIMethodWithGET:@"flickr.auth.getToken" 
							  arguments:[NSDictionary dictionaryWithObjectsAndKeys:frob, @"frob", nil]];
	
	//[activityIndicator startAnimating];
	//[navigationController.view addSubview:progressView];
	
    return YES;
	
}

- (void)_applicationDidFinishLaunchingContinued
{
	if ([self flickrRequest].sessionInfo) {
		// is getting auth token
		return;
	}
	
	if ([self.flickrContext.authToken length]) {
		[self flickrRequest].sessionInfo = kCheckTokenStep;
		[flickrRequest callAPIMethodWithGET:@"flickr.auth.checkToken" arguments:nil];
		
		//[activityIndicator startAnimating];
		//[navigationController.view addSubview:progressView];
	}
}


- (void)cancelAction
{
	[flickrRequest cancel];	
	//[activityIndicator stopAnimating];
	//[progressView removeFromSuperview];
	[self setAndStoreFlickrAuthToken:nil];
	[[NSNotificationCenter defaultCenter] postNotificationName:SnapAndRunShouldUpdateAuthInfoNotification object:self];
}


- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken
{
	NSLog(@"setting and storing");
	if (![inAuthToken length]) {
		self.flickrContext.authToken = nil;
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kStoredAuthTokenKeyName];
	}
	else {
		self.flickrContext.authToken = inAuthToken;
		[[NSUserDefaults standardUserDefaults] setObject:inAuthToken forKey:kStoredAuthTokenKeyName];
	}
}

- (OFFlickrAPIContext *)flickrContext
{
    if (!flickrContext) {
        flickrContext = [[OFFlickrAPIContext alloc] initWithAPIKey:@"0bd9015e52e52197849db03aadd270ef" sharedSecret:@"484dcfc7bb8ea324"];
        
        NSString *authToken;
        if (authToken = [[NSUserDefaults standardUserDefaults] objectForKey:kStoredAuthTokenKeyName]) {
            flickrContext.authToken = authToken;
        }
    }
    
    return flickrContext;
}

#pragma mark OFFlickrAPIRequest delegate methods
- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	if (inRequest.sessionInfo == kGetAuthTokenStep) {
		[self setAndStoreFlickrAuthToken:[[inResponseDictionary valueForKeyPath:@"auth.token"] textContent]];
		NSLog(@"in if, did it braek?");
		NSString *temp = [inResponseDictionary valueForKeyPath:@"auth.user.username"];
		NSLog(@"%@", temp);
		//self.flickrUserName = temp;
	}
	else if (inRequest.sessionInfo == kCheckTokenStep) {
		NSLog(@"in else, did it braek?");
		//self.flickrUserName = [inResponseDictionary valueForKeyPath:@"auth.user.username"];
	}
	
	//[activityIndicator stopAnimating];
	//[progressView removeFromSuperview];
	[[NSNotificationCenter defaultCenter] postNotificationName:SnapAndRunShouldUpdateAuthInfoNotification object:self];
}
*/

@end
