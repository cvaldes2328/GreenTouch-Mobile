//
//  iPadRootViewController.m
//  WellesleyNature
//
//  Created by HCI Lab on 3/9/12.
//  Copyright (c) 2012 Wellesley College. All rights reserved.
//

#import "iPadRootViewController.h"
#import "AppDelegate.h"

#import "iPadAnimals.h"
#import "iPadHealth.h"
#import "iPadPhenology.h"
#import "iPadProductivity.h"

@implementation iPadRootViewController

@synthesize selected, treeShrubArray, guildArray, plantImage, app_delegate, saveButton, guildNamesArray;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    app_delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    treeShrubArray = [[NSArray alloc] initWithObjects:@"Animals", @"Health", @"Phenology", @"Productivity", nil];
   
    NSDictionary *data = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"EdibleEcoSys" ofType:@"plist"]];
    NSDictionary *guilds = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Guilds" ofType:@"plist"]];
    guildNamesArray = [guilds objectForKey:[[data objectForKey:app_delegate.plantAccession] objectForKey:@"guild"]];
    
    guildArray = [[NSArray alloc] initWithObjects:@"Overview",guildNamesArray, nil];
    
    NSLog(@"%@", guildArray);
    
    NSString *resourcePath = [[NSBundle mainBundle] resourcePath];
    NSString *pathForImageFile = [resourcePath stringByAppendingPathComponent:[[self.title stringByAppendingString:@".png"] lowercaseString]];
    NSData *imageData = [[NSData alloc] initWithContentsOfFile:pathForImageFile];
    //NSLog(@"%@",pathForImageFile);
    UIImage *image = [[UIImage alloc] initWithData:imageData];
    plantImage.image = image;    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO; 
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
        return [treeShrubArray count];
    else
        return [guildArray count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if(section == 0)
        return @"Tree/Shrub";
    else
        return @"Understory/Guild";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Cell1Identifier = @"Cell1";
    static NSString *Cell2Identifier = @"Cell2";
    static NSString *Cell3Identifier = @"Cell3";
    NSString *identityString = @"";
    switch ([indexPath section]) {
        case 0: {
            identityString = Cell1Identifier;
            break;
        }
        case 1: {
            identityString = Cell3Identifier;
            break;
        }            
        default:
            break;
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identityString];
    
    if ([indexPath section] == 0) {
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:Cell1Identifier];
        }
        
        switch ([indexPath row]) {
            case 0:{//Animals
                //Initialize the detail view controller and display it.
                iPadAnimals *avc = [[iPadAnimals alloc]
                                                  initWithNibName:@"iPadAnimals" 
                                                  bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 1: {//Health
                iPadHealth *avc = [[iPadHealth alloc]
                                    initWithNibName:@"iPadHealth" 
                                    bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 2:{//Phenology
                iPadPhenology *avc = [[iPadPhenology alloc]
                                    initWithNibName:@"iPadPhenology" 
                                    bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 3:{//Productivity
                iPadProductivity *avc = [[iPadProductivity alloc]
                                    initWithNibName:@"iPadProductivity" 
                                    bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            default:
                break;
        }
    }
       
    else {
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle  reuseIdentifier:Cell2Identifier];
        }
        cell.textLabel.text = [[guildArray objectAtIndex: [indexPath row]] capitalizedString];
        
        for(int i = 0; i<[app_delegate.guildArray count]; i++) {
            NSString *currSpecies = [[app_delegate.guildArray objectAtIndex:i] objectForKey:@"species_name"];        
            if ([cell.textLabel.text isEqualToString:currSpecies]) {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }
        }
        
    }
           
    return cell;
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(cell.accessoryType != UITableViewCellAccessoryCheckmark)
		//cell.accessoryType = UITableViewCellAccessoryNone;//toggle check
        //else 
		cell.accessoryType = UITableViewCellAccessoryCheckmark;//check!
    
    if ([indexPath section] == 0) {
        switch ([indexPath row]) {
            case 0:{//Animals
                //Initialize the detail view controller and display it.
                iPadAnimals *avc = [[iPadAnimals alloc]
                                    initWithNibName:@"iPadAnimals" 
                                    bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 1: {//Health
                iPadHealth *avc = [[iPadHealth alloc]
                                   initWithNibName:@"iPadHealth" 
                                   bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 2:{//Phenology
                iPadPhenology *avc = [[iPadPhenology alloc]
                                      initWithNibName:@"iPadPhenology" 
                                      bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            case 3:{//Productivity
                iPadProductivity *avc = [[iPadProductivity alloc]
                                         initWithNibName:@"iPadProductivity" 
                                         bundle:nil];
                
                [self.navigationController pushViewController:avc animated:YES];
                break;
            }
            default:
                break;
        }
    }

}

@end
