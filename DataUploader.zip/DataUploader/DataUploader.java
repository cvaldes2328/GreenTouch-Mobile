import java.net.*;
import java.io.*;

public class DataUploader {
    public static void main (String[] args) {
        if(args.length == 12) upload(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]), "Alex French", args[3], Integer.parseInt(args[4]), Integer.parseInt(args[5]), Integer.parseInt(args[6]), Integer.parseInt(args[7]), Integer.parseInt(args[8]), Integer.parseInt(args[9]), Integer.parseInt(args[10]), Integer.parseInt(args[11]));
        else if (args.length == 26) uploadEdibleInfo(args[0], args[1], args[22], Integer.parseInt(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]), Integer.parseInt(args[5]), Integer.parseInt(args[6]), Integer.parseInt(args[7]), Integer.parseInt(args[8]), Integer.parseInt(args[9]), Integer.parseInt(args[10]), Integer.parseInt(args[11]), Integer.parseInt(args[12]), Integer.parseInt(args[13]), Integer.parseInt(args[14]), Integer.parseInt(args[15]), Integer.parseInt(args[16]), Integer.parseInt(args[17]), Integer.parseInt(args[18]), Integer.parseInt(args[19]), Integer.parseInt(args[20]), Integer.parseInt(args[21]), Integer.parseInt(args[23]), Integer.parseInt(args[24]), Integer.parseInt(args[25]));
        else if (args.length==30) uploadEdibleGuild(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]), args[3], args[4], args[5], Integer.parseInt(args[6]), Integer.parseInt(args[7]), args[8], Integer.parseInt(args[9]), Integer.parseInt(args[10]), Integer.parseInt(args[11]), Integer.parseInt(args[12]), Integer.parseInt(args[13]), Integer.parseInt(args[14]), Integer.parseInt(args[15]), Integer.parseInt(args[16]), Integer.parseInt(args[17]), Integer.parseInt(args[18]), args[19], Integer.parseInt(args[20]), Integer.parseInt(args[21]), Integer.parseInt(args[22]), Integer.parseInt(args[23]), Integer.parseInt(args[24]), Integer.parseInt(args[25]), Integer.parseInt(args[26]), Integer.parseInt(args[27]), Integer.parseInt(args[28]), Integer.parseInt(args[29]));
        
        else System.out.println("not the right number of args; you had "+args.length+", should be 12 or 26 or 30");
    }
    
    public static void uploadBeastData() {
        try{
            JSONObject js = new JSONObject();
            
        } catch (Exception e) {
            //blah blah blah
        }
        
    }
    public static void uploadEdibleInfo(String userName, String plantName, String plantAccession, int height, int widest_width, int leafPhen, int fruitPhen, int flowerPhen, int overallPhen, int overallHealth, int stemTip, int bark, int leafDamage, int leafDiscoloration, int flowerDamage, int fruitDamage, int leafAnml, int stemAnml, int flowerAnml, int fruitAnml, int treeFruit, int groundFruit, int harvestedFruit, int day, int month, int year) {
        
    
        try{
            //empty images string[]
            String[] imTemp = new String[0];
            
            JSONObject js = new JSONObject();
            js.put("user_name", userName);
            js.put("day", day);
            js.put("month", month);
            js.put("year", year);
            String d = Integer.toString(year) +"-"+ Integer.toString(month) +"-"+ Integer.toString(day);
            js.put("date_time", d);
            js.put("plant_name", plantName);
            js.put("plant_accession", plantAccession);
            js.put("height", height);
            js.put("widest_width", widest_width);
            
            JSONObject phenology = new JSONObject();
            phenology.put("leaf", leafPhen);
            phenology.put("fruit", fruitPhen);
            phenology.put("flower", flowerPhen);
            phenology.put("overall", overallPhen);
            phenology.put("images", imTemp);
            js.put("phenology", phenology);
            
            JSONObject health = new JSONObject();
            health.put("overall", overallHealth);
            health.put("stem_tip", stemTip);
            health.put("bark", bark);
            health.put("leaf_damage", leafDamage);
            health.put("leaf_discoloration", leafDiscoloration);
            health.put("flower", flowerDamage);
            health.put("fruit", fruitDamage);
            health.put("images", imTemp);
            js.put("health", health);
            
            JSONObject animals = new JSONObject();
            animals.put("leaf", leafAnml);
            animals.put("stem", stemAnml);
            animals.put("flower", flowerAnml);
            animals.put("fruit", fruitAnml);
            animals.put("images", imTemp);
            js.put("animals", animals);
            
            JSONObject fruit = new JSONObject();
            fruit.put("on_tree", treeFruit);
            fruit.put("on_ground", groundFruit);
            fruit.put("harvested", harvestedFruit);
            fruit.put("images", imTemp);
            js.put("fruit", fruit);
            
            String jsonText = "entry="+js.toString();
            
            System.out.println(jsonText);
            
            //okay, we have the text, ready to start dealing with the internet
            HttpURLConnection connect = (HttpURLConnection)(new URL("http://flowerpowerwebapp.appspot.com/put_new_phenology_tree").openConnection());
            connect.setRequestMethod("POST");
            connect.setRequestProperty("Content-Type", 
                                       "application/x-www-form-urlencoded");
            connect.setDoInput(true);
            connect.setDoOutput(true);
            
            //actually send the data
            DataOutputStream writer = new DataOutputStream(connect.getOutputStream());
            writer.writeBytes(jsonText);
            writer.flush();
            writer.close();
            
            //get results from the server
            InputStream is = connect.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer(); 
            while((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();
            System.out.println(response);
            
        } catch (Exception e) {
            System.out.println(e);
        
        }
    }
    
    public static void uploadEdibleGuild(int year, int month, int date, String userName, String plantName, String plantAccession, int percentCovered, int numSpecies, 
                                        String spName1, int phen1, int perc_und1, int health1, int holes1, int spots1, int browsed1, int doth1, int leaf1, int stem1, int flower1, 
                                         String spName2, int phen2, int perc_und2, int health2, int holes2, int spots2, int browsed2, int doth2, int leaf2, int stem2, int flower2) {
        try{
            JSONObject js = new JSONObject();
            js.put("user_name", userName);
            js.put("day", date);
            js.put("month", month);
            js.put("year", year);
            js.put("plant_name", plantName);
            js.put("plant_accession", plantAccession);
            js.put("percent_covered", percentCovered);
            js.put("num_species", numSpecies);
            
            JSONArray species = new JSONArray();
            JSONObject species1 = new JSONObject();
            species1.put("species_name", spName1);
            species1.put("phenology", phen1);
            species1.put("percent_understory", perc_und1);
            species1.put("health", health1);
            JSONObject damage1 = new JSONObject();
            damage1.put("holes", holes1);
            damage1.put("spots", spots1);
            damage1.put("browsed", browsed1);
            damage1.put("other", doth1);
            species1.put("damage", damage1);
            JSONObject animals1 = new JSONObject();
            animals1.put("leaf", leaf1);
            animals1.put("stem", stem1);
            animals1.put("flower", flower1);
            species1.put("animals", animals1);
            JSONObject species2 = new JSONObject();
            species2.put("species_name", spName2);
            species2.put("phenology", phen2);
            species2.put("percent_understory", perc_und2);
            species2.put("health", health2);
            JSONObject damage2 = new JSONObject();
            damage2.put("holes", holes2);
            damage2.put("spots", spots2);
            damage2.put("browsed", browsed2);
            damage2.put("other", doth2);
            species2.put("damage", damage2);
            JSONObject animals2 = new JSONObject();
            animals2.put("leaf", leaf2);
            animals2.put("stem", stem2);
            animals2.put("flower", flower2);
            species2.put("animals", animals2);
            species.put(species1);
            species.put(species2);
            js.put("species", species);
            
            String jsonText = "entry="+js.toString();
            
            //okay, we have the text, ready to start dealing with the internet
            HttpURLConnection connect = (HttpURLConnection)(new URL("http://flowerpowerwebapp.appspot.com/put_new_phenology_guild").openConnection());
            connect.setRequestMethod("POST");
            connect.setRequestProperty("Content-Type", 
                                       "application/x-www-form-urlencoded");
            connect.setDoInput(true);
            connect.setDoOutput(true);
            
            //actually send the data
            DataOutputStream writer = new DataOutputStream(connect.getOutputStream());
            writer.writeBytes(jsonText);
            writer.flush();
            writer.close();
            
            //get results from the server
            InputStream is = connect.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer(); 
            while((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();
            System.out.println(response);
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }
    public static void upload(int year, int month, int date, String userName, String plantNumber, int adultBeetles, int averageHeight, int conditionRank, int eggs, int larvae, int leafDamage, int numBeetles, int othersEquallyAffected) {
        
        try{
            //make the json object so we can get the text
            JSONObject js = new JSONObject();
            js.put("adultBeetles", adultBeetles);
            js.put("averageHeight", averageHeight);
            js.put("conditionRank", conditionRank);
            js.put("eggs", eggs);
            js.put("larvae", larvae);
            js.put("leafDamage", leafDamage);
            js.put("numBeetles", numBeetles);
            js.put("othersAreEquallyAffected", othersEquallyAffected);
            js.put("plantNumber", plantNumber);
            js.put("user_name", userName);
            js.put("day", date);
            js.put("year", year);
            js.put("month", month);
            
            String jsonText = "entry="+js.toString();
            
            //okay, we have the text, ready to start dealing with the internet
            HttpURLConnection connect = (HttpURLConnection)(new URL("http://flowerpowerwebapp.appspot.com/put_new_loosestrife_entry_date").openConnection());
            connect.setRequestMethod("POST");
            connect.setRequestProperty("Content-Type", 
                                          "application/x-www-form-urlencoded");
            connect.setDoInput(true);
            connect.setDoOutput(true);
            
            //actually send the data
            DataOutputStream writer = new DataOutputStream(connect.getOutputStream());
            writer.writeBytes(jsonText);
            writer.flush();
            writer.close();
            
            //get results from the server
            InputStream is = connect.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer(); 
            while((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();
            System.out.println(response);
            
            connect.disconnect();
        } catch (JSONException e) {
            System.out.println("we had a JSON exception");
            System.out.println(e);
            
        } catch (MalformedURLException e) {
            System.out.println("we had a malformed URL exception");
            System.out.println(e);
        } catch (ProtocolException e) {
            System.out.println("protocol exception");
            System.out.println(e);
        } catch (IOException e) {
            System.out.println("IO exception");
            System.out.println(e);
        }
    }
}