import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.util.*;

public class PicParser {
    public static void parsePic(String fileName) {
    /*try {String[] split = bytes.split(" ");
      byte[] vals = new byte[split.length*4];
      for (int i = 0; i<split.length; i++) {
        try{
          vals[4*i] = Byte.parseByte(split[i].substring(0,2));
          vals[4*i+1] = Byte.parseByte(split[i].substring(2,4));
          vals[4*i+2] = Byte.parseByte(split[i].substring(4,6));
          vals[4*i+3] = Byte.parseByte(split[i].substring(6,8));
        } catch (Exception e) {
          System.out.println(e);
        }
      }
      */
    try{
      InputStream in = new FileInputStream(new File(fileName));
      Vector<Byte> bytes = new Vector<Byte>();
      String word = "";
      
      InputStream in2 = new ObjectInputStream(in);
        while(word!="-1") {
            if(word.equals(" ")) word = ""+in.read();
            word += in.read();
            try{
                bytes.add(Byte.parseByte(word));
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        byte[] littleBytes = new byte[bytes.size()];
        for(int i = 0; i<littleBytes.length; i++) {
            littleBytes[i] = bytes.get(i).byteValue();
        }
      BufferedImage bImageFromConvert = ImageIO.read(in2);
      
      ImageIO.write(bImageFromConvert, "jpg", new File(
                                                       "new-darksouls.jpg"));
    } catch (Exception e) {
      System.out.println(e);
    }
  }
  
  public static void main(String[] args) {
    parsePic("image.txt");
  }
}