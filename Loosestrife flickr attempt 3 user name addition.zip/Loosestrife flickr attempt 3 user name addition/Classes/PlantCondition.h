//
//  PlantCondition.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoosestrifeAppDelegate.h"
#import "YesNo.h" 

@interface PlantCondition : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>{

	LoosestrifeAppDelegate *app_delegate;
	YesNo *yesNoView; 
	
	UIPickerView *picker;
	UITextView *text;
	
	UIScrollView *infoView;
	
	NSArray *array;
	
}

@property (nonatomic, retain) IBOutlet UIScrollView *infoView;
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) 	YesNo *yesNoView; 
@property (nonatomic, retain) NSArray *array;

@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) IBOutlet UITextView *text;

-(IBAction) nextButtonPressed: (id)sender;

-(IBAction) showInfoPressed: (id)sender;
-(IBAction) hideInfoPressed: (id)sender;

@end
