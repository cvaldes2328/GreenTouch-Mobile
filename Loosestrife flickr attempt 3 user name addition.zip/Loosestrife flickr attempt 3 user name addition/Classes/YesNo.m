//
//  YesNo.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "YesNo.h"


@implementation YesNo
@synthesize app_delegate, eggBox, larvaeBox, adultBox, text; 
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	self.title = @"Beetles"; 
	
	app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate]; 
	
	[text setFont:[UIFont fontWithName:@"Helvetica" size:24]];
    [super viewDidLoad];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

-(IBAction) nextButtonPressed: (id)sender {
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Hit next button in yesno page", today]; 
	[app_delegate updateLog:logEntry];
	
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithBool:[adultBox isSelected]] forKey:@"adultBeetles"];
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithBool:[eggBox isSelected]] forKey:@"eggs"];
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithBool:[larvaeBox isSelected]] forKey:@"larvae"];
	NumBeetles *numBeetlesView = [[NumBeetles alloc] init]; 
	[app_delegate.navigationController pushViewController:numBeetlesView animated:YES]; 
	
}

-(IBAction) checkboxPressed: (id)sender {

		if ([sender isSelected]) {
			//UIButton *button = (UIButton *)sender; 
			//NSString *buttonTitle = button.currentTitle;
			//do something with title
			//[answer removeObject:buttonTitle];
			//[answer removeObject:[NSString stringWithFormat:@"Minor %@", buttonTitle]];
			//[answer removeObject:[NSString stringWithFormat:@"Significant %@", buttonTitle]];
			//[answer removeObject:[NSString stringWithFormat:@"Severe %@", buttonTitle]];
			UIImage *unselectedImage = [UIImage imageNamed:@"checkbox.png"];
			[sender setImage:unselectedImage forState:UIControlStateNormal];
			[sender setSelected:NO];
			
			/*
			if ([buttonTitle isEqualToString: @"  Animal(s) currently on leaf or stem"]) {
				animalOnLeaf.hidden = YES;
			}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on stem"]) {
				animalOnStem.hidden = YES;
			}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on flower"]) {
				animalOnFlower.hidden = YES;
			}else if ([buttonTitle isEqualToString: @"  Holes in leaf or flower"]) {
				holes.hidden = YES;
				minorButton.hidden = YES;
				significant.hidden = YES;
				severe.hidden = YES;
				minorLabel.hidden = YES;
				significantLabel.hidden = YES;
				severeLabel.hidden = YES;
				
			}else if ([buttonTitle isEqualToString: @"  Damage to edge of leaf"]) {
				damageToleaf.hidden = YES;
			}
			 */ 
			
		}else {
			/*
			UIButton *button = (UIButton *)sender; 
			NSString *buttonTitle = button.currentTitle;
			if([buttonTitle isEqualToString:@"Holes in leaf or flower"]) {
				if([minorButton isSelected])
					buttonTitle = [@"Minor " stringByAppendingString:buttonTitle];
				else if ([significant isSelected])
					buttonTitle = [@"Significant " stringByAppendingString:buttonTitle];
				else if ([severe isSelected])
					buttonTitle = [@"Severe " stringByAppendingString:buttonTitle];
			}
			[answer addObject:[[NSDictionary alloc] initWithObjectsAndKeys:buttonTitle,
							   @"description", @"no picture", @"photo", nil]];
			 */ 
			NSLog(@"we are here"); 
			UIImage *selectedImage = [UIImage imageNamed:@"checkbox-checked.png"];
			[sender setImage:selectedImage forState:UIControlStateSelected];
			[sender setSelected:YES];
			/*
			if ([buttonTitle isEqualToString: @"  Animal(s) currently on leaf or stem"]) {
				animalOnLeaf.hidden = NO;
			}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on stem"]) {
				animalOnStem.hidden = NO;
			}else if ([buttonTitle isEqualToString: @"  Animal(s) currently on flower"]) {
				animalOnFlower.hidden = NO;
			}else if ([buttonTitle isEqualToString: @"  Holes in leaf or flower"]) {
				holes.hidden = NO;
				minorButton.hidden = NO;
				significant.hidden = NO;
				severe.hidden = NO;
				minorLabel.hidden = NO;
				significantLabel.hidden = NO;
				severeLabel.hidden = NO;
			}else if ([buttonTitle isEqualToString: @"  Damage to edge of leaf"]) {
				damageToleaf.hidden = NO;
			}	
			 */ 
		} 
		
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Answered presence questions", today]; 
	[app_delegate updateLog:logEntry];

}

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in animal presence", today]; 
		[app_delegate updateLog:logEntry];
	}
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
