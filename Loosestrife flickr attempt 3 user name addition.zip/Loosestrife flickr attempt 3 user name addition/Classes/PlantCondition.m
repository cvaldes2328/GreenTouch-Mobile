//
//  PlantCondition.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "PlantCondition.h"


@implementation PlantCondition
@synthesize app_delegate, text, picker, array, yesNoView, infoView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	self.title = @"Plant Condition";
	
	app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate];
	
	[text setFont:[UIFont fontWithName:@"Helvetica" size:20.0]];
	array = [[NSArray alloc] initWithObjects:@"Poor", @"Fair", @"Good", @"Excellent", nil];
    [super viewDidLoad];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

-(IBAction) nextButtonPressed: (id)sender {
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Next button pressed in leaf damage", today]; 
	[app_delegate updateLog:logEntry];
	
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:[picker selectedRowInComponent:0]] forKey:@"conditionRank"];
	yesNoView = [[YesNo alloc] initWithNibName:@"YesNo" bundle:nil]; 
	[app_delegate.navigationController pushViewController:yesNoView animated:YES]; 
}

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in leaf damage", today]; 
		[app_delegate updateLog:logEntry];
	}
}

-(IBAction) showInfoPressed: (id)sender{

	infoView.hidden = NO;
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Opened leaf damage reference/", today]; 
	[app_delegate updateLog:logEntry];
}

-(IBAction) hideInfoPressed: (id)sender{
	infoView.hidden = YES;
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Hid leaf damage reference", today]; 
	[app_delegate updateLog:logEntry];
	
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
