//
//  UserSelectTable.h
//  Loosestrife
//
//  Created by HCI Lab on 9/5/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoosestrifeAppDelegate;
@class RootViewController;

@interface UserSelectTable : UITableViewController {
	LoosestrifeAppDelegate *app_delegate;
	RootViewController *root;
	
	BOOL isCollectingData;
	NSArray *users;
}

@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) RootViewController *root;
@property (nonatomic, retain) NSArray *users;
@property (nonatomic) BOOL isCollectingData;

@end
