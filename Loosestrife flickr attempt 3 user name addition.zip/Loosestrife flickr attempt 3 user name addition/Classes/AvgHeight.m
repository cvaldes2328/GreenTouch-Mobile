//
//  AvgHeight.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "AvgHeight.h"




@implementation AvgHeight



@synthesize nextButton, heightLabel, picker, array, app_delegate, plantPhotoView; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate];
	[picker setDelegate:self];
	[picker setDataSource:self];
	
	array = [[NSArray alloc] initWithObjects:@"< 0.25 meters", @".5 meters",@".75 meters",@"1 meter",@"1.25 meters", @"1.5 meters",@"1.75 meters",@"2.0 meters", @">2 meters", nil]; 
	[heightLabel setFont:[UIFont fontWithName:@"Helvetica" size:20.0]];
	
	self.title =@"Avg Height";
	
	plantPhotoView = [[PlantPhoto alloc] initWithNibName:@"PlantPhoto" bundle:nil]; 
	plantPhotoView.nextVC = 0;
	
    [super viewDidLoad];
}

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in avg height", today]; 
		[app_delegate updateLog:logEntry];
	}
}

-(IBAction) nextButtonPressed: (id) sender {

	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Hit next button in avg height", today]; 
	[app_delegate updateLog:logEntry];
	
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:[picker selectedRowInComponent:0]] forKey:@"averageHeight"];
	[app_delegate.navigationController pushViewController:plantPhotoView animated:YES]; 
		
}

-(void) viewWillAppear:(BOOL)animated {
	[self.navigationItem setHidesBackButton:YES];
	[super viewWillAppear:animated];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


//picker stuff
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
