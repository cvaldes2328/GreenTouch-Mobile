//
//  YesNo.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoosestrifeAppDelegate.h"
#import "NumBeetles.h"

@interface YesNo : UIViewController {
	LoosestrifeAppDelegate *app_delegate;
	
	UIButton *eggBox;
	UIButton *larvaeBox;
	UIButton *adultBox;
	//UIButton *equallyAffectedBox;
	
	UITextView *text;
	
	//UIButton *nextButton;
	
}
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;

@property (nonatomic, retain) IBOutlet UIButton *eggBox;
@property (nonatomic, retain) IBOutlet UIButton *larvaeBox;
@property (nonatomic, retain) IBOutlet UIButton *adultBox;
//@property (nonatomic, retain) IBOutlet UIButton *nextButton;
@property (nonatomic, retain) IBOutlet UITextView *text;

-(IBAction) checkboxPressed: (id)sender;
-(IBAction) nextButtonPressed: (id)sender;

@end
