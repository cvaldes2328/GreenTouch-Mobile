//
//  AvgHeight.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoosestrifeAppDelegate.h" 
#import "PlantPhoto.h"

@class LoosestrifeAppDelegate;

@interface AvgHeight : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {

	UITextView *heightLabel;
	UIButton *nextButton;
	UIPickerView *picker; 
	NSArray *array; 
	LoosestrifeAppDelegate *app_delegate; 
	PlantPhoto *plantPhotoView; 
	
}

@property (nonatomic, retain) IBOutlet UITextView *heightLabel; 
@property (nonatomic, retain) IBOutlet UIButton *nextButton;
@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) NSArray *array; 
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate; 
@property (nonatomic, retain) PlantPhoto *plantPhotoView; 

-(IBAction) nextButtonPressed: (id) sender; 

@end
