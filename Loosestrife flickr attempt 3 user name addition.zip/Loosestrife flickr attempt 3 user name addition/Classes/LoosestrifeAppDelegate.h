//
//  LoosestrifeAppDelegate.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "ObjectiveFlickr.h"

@interface LoosestrifeAppDelegate : NSObject <UIApplicationDelegate, OFFlickrAPIRequestDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
	
	NSMutableDictionary *currentDataEntry;
	NSMutableArray *totalEntries;
	
	NSMutableArray *picsArray;
	NSMutableArray *totalPics;
	NSArray *uploadingPics;
	NSArray *currentFetchedData;
	NSString *user;
	
	
	OFFlickrAPIContext *flickrContext;
	OFFlickrAPIRequest *flickrRequest;
	NSString *flickrUserName;
	
	//Log
	NSMutableDictionary *stream_;
	NSMutableArray *log_;
	

@private
    NSManagedObjectContext *managedObjectContext_;
    NSManagedObjectModel *managedObjectModel_;
    NSPersistentStoreCoordinator *persistentStoreCoordinator_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@property (nonatomic, retain) NSMutableDictionary *currentDataEntry;
@property (nonatomic, retain) NSMutableArray *totalEntries;
@property (nonatomic, retain) NSMutableArray *picsArray;
@property (nonatomic, retain) NSMutableArray *totalPics;
@property (nonatomic, retain) NSArray *uploadingPics;
@property (nonatomic, retain) NSArray *currentFetchedData;
@property (nonatomic, retain) NSString *user;

@property (nonatomic, retain, readonly) OFFlickrAPIContext *flickrContext;
@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;
@property (nonatomic, retain) NSString *flickrUserName;

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

//Log
@property (nonatomic, retain) NSMutableDictionary *stream_;
@property (nonatomic, retain) NSMutableArray *log_;

- (NSURL *)applicationDocumentsDirectory;
- (void)saveContext;
- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken;

@end

