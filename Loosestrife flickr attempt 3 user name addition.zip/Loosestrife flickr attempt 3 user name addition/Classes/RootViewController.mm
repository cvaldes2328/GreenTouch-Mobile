//
//  RootViewController.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "RootViewController.h"
#import "ObjectiveFlickr.h"
#import "UserSelectTable.h"
#import "PlantSelectTable.h"
#import <ZXingWidgetController.h>
#import <QRCodeReader.h>
#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>


@interface RootViewController ()
//- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;
@end


@implementation RootViewController

//@synthesize fetchedResultsController=fetchedResultsController_, managedObjectContext=managedObjectContext_;
@synthesize beginButton, submitAllButton, avgHeight, app_delegate, flickrRequest, receivedInfoData; 

#pragma mark -
#pragma mark View lifecycle

- (void)viewDidLoad {
	app_delegate = (LoosestrifeAppDelegate *)[[UIApplication sharedApplication] delegate];
	app_delegate.currentDataEntry = [[NSMutableDictionary alloc] init];
	//app_delegate.totalEntries = [[NSMutableArray alloc] init];
	
	self.title = @"Welcome";
    [super viewDidLoad];
	
	

    // Set up the edit and add buttons.
    //self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    //UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject)];
    //self.navigationItem.rightBarButtonItem = addButton;
    //[addButton release];
}


// Implement viewWillAppear: to do additional setup before the view is presented.
- (void)viewWillAppear:(BOOL)animated {
	if (!app_delegate) {
		NSLog(@"it didn't know what app delegate was");
		app_delegate = (LoosestrifeAppDelegate *)[[UIApplication sharedApplication] delegate];
	}
	NSLog(@"app delegate is %@", app_delegate);
	NSLog(@"total entries is %d", [app_delegate.totalEntries count]);
	if ([app_delegate.totalEntries count]>0) {
		[submitAllButton setHidden:NO];
		beginButton.titleLabel.text = @"Next plant";
		[beginButton setTitle:@"Next plant" forState:UIControlStateNormal];
		[beginButton setTitle:@"Next plant" forState:UIControlStateHighlighted];
		[beginButton setTitle:@"Next plant" forState:UIControlStateSelected];
		[beginButton setTitle:@"Next plant" forState:UIControlStateDisabled];
	}
	else {
		[submitAllButton setHidden:YES];
		[beginButton setTitle:@"Begin" forState:UIControlStateNormal];
		[beginButton setTitle:@"Begin" forState:UIControlStateHighlighted];
		[beginButton setTitle:@"Begin" forState:UIControlStateSelected];
		[beginButton setTitle:@"Begin" forState:UIControlStateDisabled];
		beginButton.titleLabel.text = @"Begin";
	}

    [super viewWillAppear:animated];
}

-(void) selectedUserName {
	/*NSDictionary *stupidTestingEntry = [[NSDictionary alloc] initWithObjectsAndKeys:app_delegate.user, @"user_name",
																					@"Loosestrife0", @"plant_number",
										nil];
	NSString *sendable = [stupidTestingEntry JSONRepresentation];
	NSString *magic = [NSString stringWithFormat:@"entry=%@", sendable];
	//[sendable release];
	
	NSData *paramData = [magic dataUsingEncoding:NSUTF8StringEncoding];
	NSLog(@"this is the log: %@", magic);
	
	//connecting to the internet
	NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
	[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_new_loosestrife_entry"]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
	[request setHTTPBody: paramData];
	
	NSURLResponse *urlResponse;	
	NSError *error;
	NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
	if(!data) {
		NSLog(@"%@", [error localizedDescription]);
	}
	NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	NSLog(@"made it to end of addLog");
	//NSLog(@"%@", urlResponse);
	//NSLog(@"%@", data);
	//NSLog(@"%@", tData);
	[tData release];
	[request release];*/
	
	//[app_delegate.currentDataEntry setObject:app_delegate.user forKey:@"user_name"];
	NSLog(@"doing the zebra xing");
	ZXingWidgetController *widController = [[ZXingWidgetController alloc] 
											initWithDelegate:self 
											showCancel:YES 
											OneDMode:NO];
	QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
	NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
	[qrcodeReader release];
	[widController setReaders:readers];
	[readers release];
	// NSBundle *mainBundle = [NSBundle mainBundle];
	//widController.soundToPlay =
	//[NSURL fileURLWithPath:[mainBundle pathForResource:@"beep-beep" ofType:@"aiff"] isDirectory:NO];
	//resultsView.text = resultsToDisplay;
	[self presentModalViewController:widController animated:YES];
	[widController release];
	 
}

-(IBAction) beginButtonPressed: (id) sender {

	UserSelectTable *userSelect = [[UserSelectTable alloc] initWithNibName:@"UserSelectTable" bundle:nil];
	userSelect.isCollectingData = YES;
	userSelect.root = self;
	[self.navigationController pushViewController:userSelect animated:YES];
	/*app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate];
	avgHeight = [[AvgHeight alloc] initWithNibName:@"AvgHeight" bundle:nil]; 
	[app_delegate.navigationController pushViewController:avgHeight animated:YES]; 
	*/
	
	
}
- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)result {
	NSLog(@"scanned result");
	//self.resultsToDisplay = result;
	
	NSLog(@"in outer if");
	if ([result hasPrefix:@"Loosestrife"]) {
		app_delegate.currentDataEntry = [[NSMutableDictionary alloc] init];
		[app_delegate.currentDataEntry setObject:result forKey:@"plantNumber"];
		[app_delegate.currentDataEntry setObject:app_delegate.user forKey:@"user_name"];
		app_delegate.picsArray = [[NSMutableArray alloc] init];
		if ([app_delegate.totalEntries count]<1) {
			app_delegate.totalPics = [[NSMutableArray alloc] init];
			app_delegate.totalEntries =[[NSMutableArray alloc] init];
		}
		//addNew = [[AddNewEntry alloc] initWithNibName:@"AddNewEntry" bundle:nil];
		//app_delegate.currentPlant = result;
		//addNew.nameForLoad = studentName;
		avgHeight = [[AvgHeight alloc] initWithNibName:@"AvgHeight" bundle:nil]; 
		//[app_delegate.navigationController pushViewController:avgHeight animated:YES];
		NSLog(@"going to push: %@", avgHeight);
		
		[app_delegate.navigationController pushViewController:avgHeight animated:YES];
		NSLog(@"It pushed");
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Scanned QR code %@", today, result]; 
		[app_delegate updateLog:logEntry];
		
	}else {
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Scanned wrong QR code %@", today,result]; 
		[app_delegate updateLog:logEntry];
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" 
													   message:@"The ID you entered doesn't exist in our database. Please check your entry and try again!" 
													  delegate:nil 
											 cancelButtonTitle:@"OK" 
											 otherButtonTitles:nil];
		[alert show];
		//[self dismissModalViewControllerAnimated:NO];
	}
	//if we wanted to display some kind of confirmation label or something...
	//[resultsView setText:resultsToDisplay];
	//[resultsView setNeedsDisplay];
	//}
	[self dismissModalViewControllerAnimated:NO];
	
}

- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller {
	[self dismissModalViewControllerAnimated:NO];
}
-(BOOL) connectedToNetwork
{

	//Create zero addy
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	
	//Recover reachability flags
	SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr*)&zeroAddress);
	SCNetworkReachabilityFlags flags;
	
	BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
	CFRelease(defaultRouteReachability);
	
	if (!didRetrieveFlags) {
		printf("Error. Could not recover network reachability flags\n");
		return 0;
	}
	
	BOOL isReachable = flags & kSCNetworkFlagsReachable;
	BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
	return (isReachable && !needsConnection) ? YES : NO;
}

-(IBAction) submitAllButtonPressed: (id) sender{
	NSLog(@"Stack is %d long", [app_delegate.totalEntries count]);
	
	//time to submit
	if ([self connectedToNetwork]) {
		for (int i = 0; i<[app_delegate.totalEntries count]; i++) {
			//creating the data we actually want to upload
			NSString *pleasepleaseplease = [[app_delegate.totalEntries objectAtIndex:i] JSONRepresentation];
			NSString *paramDataString = [NSString stringWithFormat:@"entry=%@", pleasepleaseplease];
			NSData *paramData = [paramDataString dataUsingEncoding:NSUTF8StringEncoding];
			NSLog(@"this is the log: %@", paramDataString);
			
			//connecting to the internet
			NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
			[request setURL:[NSURL URLWithString:@"http://flowerpowerwebapp.appspot.com/put_new_loosestrife_entry"]];
			[request setHTTPMethod:@"POST"];
			[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
			[request setHTTPBody: paramData];
			
			NSURLResponse *urlResponse;	
			NSError *error;
			NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
			if(!data) {
				NSLog(@"%@", [error localizedDescription]);
			}
			NSString *tData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
			NSLog(@"made it to end of addLog");
			//NSLog(@"%@", urlResponse);
			//NSLog(@"%@", data);
			//NSLog(@"%@", tData);
			[tData release];
			[request release];
			
			
		}
		
		//next, flickr
		
		OFFlickrAPIContext *context = [[OFFlickrAPIContext alloc] initWithAPIKey:@"0bd9015e52e52197849db03aadd270ef" sharedSecret:@"484dcfc7bb8ea324"];
	
		OFFlickrAPIRequest *request = [[OFFlickrAPIRequest alloc] initWithAPIContext:context];
		
		
		// set the delegate, here we assume it's the controller that's creating the request object
		[request setDelegate:self];
		
		if ([context.authToken length]<1) {
			//app_delegate.flickrContext.key = NULL; 
			[self authorizeAction];
		}
		NSString *authToken;
		if (authToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"FlickrAuthToken"]) {
			app_delegate.flickrContext.authToken = authToken;
		}
		NSLog(@"auth token is %@", app_delegate.flickrContext.authToken);
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:app_delegate.flickrContext];
		flickrRequest.delegate = self;
		flickrRequest.requestTimeoutInterval = 60.0;
		
		NSLog(@"going to upload all pics");
		NSLog(@"%d", [app_delegate.totalPics count]);
		int count = 0;
		app_delegate.uploadingPics = app_delegate.totalPics;
		app_delegate.totalPics = [[NSMutableArray alloc] init];
		for (int i = 0; i<[app_delegate.uploadingPics count]; i++) {
			for (int j = 0; j<[[app_delegate.uploadingPics objectAtIndex:i] count]; j++) {
				[self performSelector: @selector(_startUpload:) withObject:[NSArray arrayWithObjects:[NSNumber numberWithInt:i], [NSNumber numberWithInt:j], [[app_delegate.totalEntries objectAtIndex:i] objectForKey:@"plantNumber"], nil] afterDelay:20.0+10.0*count];
				count++;
				//NSLog(@"i = %u",i); 
				//NSLog(@" j = %u",j); 

			}
		}
		//some last-minute setup-type stuff
		[submitAllButton setHidden:YES];
		[beginButton setTitle:@"Begin" forState:UIControlStateNormal];
		[beginButton setTitle:@"Begin" forState:UIControlStateHighlighted];
		[beginButton setTitle:@"Begin" forState:UIControlStateSelected];
		[beginButton setTitle:@"Begin" forState:UIControlStateDisabled];
		beginButton.titleLabel.text = @"Begin";
		//[app_delegate.totalData release];
		app_delegate.totalEntries = [[NSMutableArray alloc] init];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success!" 
														message:@"Your data has uploaded.  Please leave the app running so that the pictures can finish uploading." 
													   delegate:nil 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles:nil];
		[alert show];
		[alert release];
		
	}else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No WiFi!" 
														message:@"Seems like there is no internet. Try again when you see that you have wifi." 
													   delegate:nil 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles:nil];
		[alert show]; 
		[alert release];
	}

	
}

- (void)_startUpload:(NSArray *)image
{
	int i = [[image objectAtIndex: 0] intValue];
	
	int j = [[image objectAtIndex:1] intValue];
	NSLog(@"going to start upload");
	//for (int j = 0; j<[[app_delegate.totalPics objectAtIndex:i] count]; j++) {
	if ([[app_delegate.uploadingPics objectAtIndex:i]objectAtIndex:j]==[UIImage imageNamed:@"cameraicon.png"]) {
		NSLog(@"it's a camera, not uploading");
	}
	else {
		NSData *JPEGData = UIImageJPEGRepresentation([[app_delegate.uploadingPics objectAtIndex:i] objectAtIndex:j], 1.0);
		
		//snapPictureButton.enabled = NO;
		//snapPictureDescriptionLabel.text = @"Uploading";
		
		self.flickrRequest.sessionInfo = @"kUploadImageStep";
		[self.flickrRequest uploadImageStream:[NSInputStream inputStreamWithData:JPEGData] 
							suggestedFilename:@"Demo" MIMEType:@"image/jpeg" 
									arguments:[NSDictionary dictionaryWithObjectsAndKeys:[image objectAtIndex:2], @"tags", @"1", @"is_public", nil]];
		
		
		
		NSLog(@"upload?");
		[UIApplication sharedApplication].idleTimerDisabled = YES;
	}

	//}
    
	
	//[self updateUserInterface:nil];
}
- (IBAction)authorizeAction
{	
	//authorizeButton.enabled = NO;
	//authorizeDescriptionLabel.text = @"Logging in...";
    
	[app_delegate.flickrContext setAuthToken:nil];
    NSURL *loginURL = [app_delegate.flickrContext loginURLFromFrobDictionary:nil requestedPermission:OFFlickrWritePermission];
    [[UIApplication sharedApplication] openURL:loginURL];
}

#pragma mark OFFlickrAPIRequest delegate methods
- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	NSLog(@"Hi!");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inResponseDictionary);
    
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//snapPictureDescriptionLabel.text = @"Setting properties...";
		
        //NSLog(@"Hi 2");
        NSLog(@"%@", inResponseDictionary);
        NSString *photoID = [[inResponseDictionary valueForKeyPath:@"photoid"] textContent];
		
        flickrRequest.sessionInfo = @"kSetImagePropertiesStep";
        [flickrRequest callAPIMethodWithPOST:@"flickr.photos.setMeta" arguments:[NSDictionary dictionaryWithObjectsAndKeys:photoID, @"photo_id", @"Loosestrife", @"title", @"WCBG", @"description", nil]];        		        
	}
    else if ([inRequest.sessionInfo isEqualToString: @"kSetImagePropertiesStep"]) {
		//[self updateUserInterface:nil];		
		//snapPictureDescriptionLabel.text = @"Done";
        
		[UIApplication sharedApplication].idleTimerDisabled = NO;		
        
    }
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didFailWithError:(NSError *)inError
{
	NSLog(@"Hi 3");
    NSLog(@"%s %@ %@", __PRETTY_FUNCTION__, inRequest.sessionInfo, inError);
	if ([inRequest.sessionInfo isEqualToString: @"kUploadImageStep"]) {
		//[self updateUserInterface:nil];
		//snapPictureDescriptionLabel.text = @"Failed";		
		[UIApplication sharedApplication].idleTimerDisabled = NO;
		
		//[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
		
	}
	else {
		//[[[[UIAlertView alloc] initWithTitle:@"API Failed" message:[inError description] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil] autorelease] show];
	}
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest imageUploadSentBytes:(NSUInteger)inSentBytes totalBytes:(NSUInteger)inTotalBytes
{
	if (inSentBytes == inTotalBytes) {
		//snapPictureDescriptionLabel.text = @"Waiting for Flickr...";
	}
	else {
		//snapPictureDescriptionLabel.text = [NSString stringWithFormat:@"%lu/%lu (KB)", inSentBytes / 1024, inTotalBytes / 1024];
	}
}

-(IBAction) dataTestButtonPressed: (id) sender {
	NSLog(@"trying to get data");
	if ([self connectedToNetwork]) {
		NSString *urlString = @"http://flowerpowerwebapp.appspot.com/get_new_loosestrife_entries";
		NSURL *url = [NSURL URLWithString:urlString];
		NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
		[request setHTTPMethod:@"GET"];
		[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"content-type"];
		NSURLConnection *connector = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
		/*NSURLResponse *urlResponse;	
		 NSError *error;
		 NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
		 if(!data) {
			NSLog(@"%@", [error localizedDescription]);
		 }
		 //NSLog(@"data is %@"), data;
		 NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		 NSLog(@"json string is %@", jsonString);
		 NSDictionary *results = [jsonString JSONValue];
		 NSLog(@"results are %@", results);*/
		PlantSelectTable *detail = [[PlantSelectTable alloc] initWithNibName:@"PlantSelectTable" bundle:nil];
		[self.navigationController pushViewController:detail animated:YES];
		NSLog(@"finished button pressed method");
	} else {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil 
															message:@"You aren't connected to WiFi right now.  Please try again when in range of WiFi."
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
		[alertView show];
		[alertView release];
	}

}

-(void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	NSLog(@"got a response!");
	[receivedInfoData release];
	receivedInfoData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	NSLog(@"received data");
	[receivedInfoData appendData:data];
	/*NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	NSLog(@"json string is %@", jsonString);
	NSDictionary *results = [jsonString JSONValue];
	NSLog(@"results are %@", results);*/
}

-(void) connection:(NSURLConnection *)connection didFailWithError: (NSError *)error {
	NSLog(@"failed; %@", error);
}

-(void) connectionDidFinishLoading:(NSURLConnection *)connection {
	NSLog(@"finished loading!");
	NSString *jsonString = [[NSString alloc] initWithData:receivedInfoData encoding:NSUTF8StringEncoding];
	NSLog(@"json string is %@", jsonString);
	NSArray *results = [jsonString JSONValue];
	//NSLog(@"results are %@", results);
	app_delegate.currentFetchedData = results;
	[connection release];
} 
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */

/*
- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    
    NSManagedObject *managedObject = [self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.textLabel.text = [[managedObject valueForKey:@"timeStamp"] description];
}


#pragma mark -
#pragma mark Add a new object

- (void)insertNewObject {
    
    // Create a new instance of the entity managed by the fetched results controller.
    NSManagedObjectContext *context = [self.fetchedResultsController managedObjectContext];
    NSEntityDescription *entity = [[self.fetchedResultsController fetchRequest] entity];
    NSManagedObject *newManagedObject = [NSEntityDescription insertNewObjectForEntityForName:[entity name] inManagedObjectContext:context];
    
    // If appropriate, configure the new managed object.
    [newManagedObject setValue:[NSDate date] forKey:@"timeStamp"];
    
    // Save the context.
    NSError *error = nil;
    if (![context save:&error]) {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. If it is not possible to recover from the error, display an alert panel that instructs the user to quit the application by pressing the Home button.
         
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
}



- (void)setEditing:(BOOL)editing animated:(BOOL)animated {

    // Prevent new objects being added when in editing mode.
    [super setEditing:(BOOL)editing animated:(BOOL)animated];
    self.navigationItem.rightBarButtonItem.enabled = !editing;
}
*/ 


#pragma mark -
#pragma mark Table view data source
/*
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [[self.fetchedResultsController sections] count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
    return [sectionInfo numberOfObjects];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell.
    [self configureCell:cell atIndexPath:indexPath];
    
    return cell;
}
 */ 



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the managed object for the given index path
        NSManagedObjectContext *context = [self.fetchedResultsController managedObjectContext];
        [context deleteObject:[self.fetchedResultsController objectAtIndexPath:indexPath]];
        
        // Save the context.
        NSError *error = nil;
        if (![context save:&error]) {
            /*
             Replace this implementation with code to handle the error appropriately.
             
             abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. If it is not possible to recover from the error, display an alert panel that instructs the user to quit the application by pressing the Home button.
             
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }   
}
*/ 
/*
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // The table view should not be re-orderable.
    return NO;
}
 */ 


#pragma mark -
#pragma mark Table view delegate

/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here -- for example, create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     NSManagedObject *selectedObject = [[self fetchedResultsController] objectAtIndexPath:indexPath];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
	
}
*/ 


#pragma mark -
#pragma mark Fetched results controller
/*
- (NSFetchedResultsController *)fetchedResultsController {
    
    if (fetchedResultsController_ != nil) {
        return fetchedResultsController_;
    }
    
    /*
     Set up the fetched results controller.
    // Create the fetch request for the entity.
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    // Edit the entity name as appropriate.
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    
    // Set the batch size to a suitable number.
    [fetchRequest setFetchBatchSize:20];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"timeStamp" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    // Edit the section name key path and cache name if appropriate.
    // nil for section name key path means "no sections".
    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:@"Root"];
    aFetchedResultsController.delegate = self;
    self.fetchedResultsController = aFetchedResultsController;
    
    [aFetchedResultsController release];
    [fetchRequest release];
    [sortDescriptor release];
    [sortDescriptors release];
    
    NSError *error = nil;
    if (![fetchedResultsController_ performFetch:&error]) {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. If it is not possible to recover from the error, display an alert panel that instructs the user to quit the application by pressing the Home button.
		
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return fetchedResultsController_;
}  
*/ 


#pragma mark -
#pragma mark Fetched results controller delegate

/*
- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    [self.tableView beginUpdates];
}


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath {
    
    UITableView *tableView = self.tableView;
    
    switch(type) {
            
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
            
        case NSFetchedResultsChangeMove:
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath]withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    [self.tableView endUpdates];
}
*/ 

/*
// Implementing the above methods to update the table view in response to individual changes may have performance implications if a large number of changes are made simultaneously. If this proves to be an issue, you can instead just implement controllerDidChangeContent: which notifies the delegate that all section and object changes have been processed. 
 
 - (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // In the simplest, most efficient, case, reload the table view.
    [self.tableView reloadData];
}
 */


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}


- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
//    [fetchedResultsController_ release];
//    [managedObjectContext_ release];
    [super dealloc];
}


@end

