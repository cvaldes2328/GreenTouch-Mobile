//
//  PlantPhoto.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Condition.h"
#import "LoosestrifeAppDelegate.h"



@interface PlantPhoto : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>{

	UIButton *cameraButton;
	UIButton *nextButton; 
	UITextView *text; 
	NSString *directions;
	
	UIViewController *nextController;
	int nextVC;
	LoosestrifeAppDelegate *app_delegate;
}

@property (nonatomic) int nextVC;
@property (nonatomic, retain) IBOutlet UIButton *cameraButton; 
@property (nonatomic, retain) IBOutlet UIButton *nextButton; 
@property (nonatomic, retain) IBOutlet UITextView *text; 
@property (nonatomic, retain) UIViewController *nextController;

@property (nonatomic, retain) NSString *directions;
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;

-(IBAction) cameraButtonPressed: (id) sender;
-(IBAction) nextButtonPressed: (id) sender;


@end
