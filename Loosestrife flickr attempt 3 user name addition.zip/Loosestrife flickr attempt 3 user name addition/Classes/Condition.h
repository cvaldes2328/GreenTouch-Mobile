//
//  Condition.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoosestrifeAppDelegate.h"
//#import "PlantPhoto.h"

@class PlantPhoto;
@interface Condition : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>{

	UIPickerView *picker;
	UITextView *text;
	
	NSArray *array;
	UIScrollView *infoView;

	
	LoosestrifeAppDelegate *app_delegate;
	
	PlantPhoto *photo;
}

@property (nonatomic, retain) IBOutlet UIScrollView *infoView;

@property (nonatomic, retain) IBOutlet UIPickerView *picker;
@property (nonatomic, retain) IBOutlet UITextView *text;

@property (nonatomic, retain) NSArray *array;
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) PlantPhoto *photo;

-(IBAction) nextButtonPressed: (id)sender;
-(IBAction) showInfoPressed: (id)sender;
-(IBAction) hideInfoPressed: (id)sender;

@end
