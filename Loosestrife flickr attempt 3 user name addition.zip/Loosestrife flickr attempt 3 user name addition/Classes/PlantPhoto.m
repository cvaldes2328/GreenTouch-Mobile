//
//  PlantPhoto.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "PlantPhoto.h"
#import "PlantCondition.h"
#import "Condition.h"

@implementation PlantPhoto

@synthesize nextButton, cameraButton, text, app_delegate, directions, nextVC, nextController; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (LoosestrifeAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.title = @"Plant Photo";
	switch (nextVC) {
		case 0:
			nextController = [[Condition alloc] init];
			break;
		case 1:
			nextController = [[PlantCondition alloc] init];
			break;

		default:
			break;
	}
	if(directions)
		text.text = directions;
	
    [super viewDidLoad];
}

-(void) viewWillAppear:(BOOL)animated {
	switch (nextVC) {
		case 0:
			nextButton.titleLabel.text = @"Next";
			[nextButton setTitle:@"Next" forState:UIControlStateNormal];
			[nextButton setTitle:@"Next" forState:UIControlStateHighlighted];
			[nextButton setTitle:@"Next" forState:UIControlStateSelected];
			[nextButton setTitle:@"Next" forState:UIControlStateDisabled];
			break;
		case 1:
			nextButton.titleLabel.text = @"Next";
			[nextButton setTitle:@"Next" forState:UIControlStateNormal];
			[nextButton setTitle:@"Next" forState:UIControlStateHighlighted];
			[nextButton setTitle:@"Next" forState:UIControlStateSelected];
			[nextButton setTitle:@"Next" forState:UIControlStateDisabled];
			break;
		case 2:
			nextButton.titleLabel.text = @"Done";
			break;

		default:
			break;
	}
	/*if (self.nextVC==2) {
		nextButton.titleLabel.text = @"Done";
	}*/
	[super viewWillAppear:animated];
}
-(IBAction) nextButtonPressed: (id) sender {
	if ([app_delegate.picsArray count]>nextVC) {
		[app_delegate.picsArray replaceObjectAtIndex:nextVC withObject:cameraButton.imageView.image];
	} else {
		NSLog(@"adding");
		[app_delegate.picsArray addObject:cameraButton.imageView.image];
		NSLog(@"pics array is %@", app_delegate.picsArray);
	}

	NSLog(@"total entries is %@", app_delegate.totalEntries);
	//Condition *condition;
	//PlantCondition *plantCondition;
	switch (nextVC) {
		case 0:
			[app_delegate.navigationController pushViewController:nextController animated:YES];
			break;
		case 1:
			[app_delegate.navigationController pushViewController:nextController animated:YES];
			break;
		case 2:
			[app_delegate.totalEntries addObject:app_delegate.currentDataEntry];
			[app_delegate.currentDataEntry release];
			[app_delegate.totalPics addObject:app_delegate.picsArray];
			app_delegate.picsArray =[[NSMutableArray alloc] init];
			[app_delegate.navigationController popToRootViewControllerAnimated:YES];
			break;

		default:
			break;
	}
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Next button pressed in PlantPhoto", today]; 
	[app_delegate updateLog:logEntry];
	
}

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in plant photo", today]; 
		[app_delegate updateLog:logEntry];
	}
}

-(IBAction) cameraButtonPressed: (id) sender {
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
	imagePicker.delegate = self;
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	} else {
		return;
	}
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Camera button pressed for plant photo%@", today]; 
	[app_delegate updateLog:logEntry];
	
	[self presentModalViewController:imagePicker animated:YES];
}

#ifndef __IPHONE_3_0
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
	//  NSDictionary *editingInfo = info;
#else
	- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
	{
#endif
		//[viewHere setHidden:YES];
		[self dismissModalViewControllerAnimated:YES];
		
		cameraButton.imageView.image = image;
		[cameraButton setImage:image forState:UIControlStateNormal];
		[cameraButton setImage:image forState:UIControlStateSelected];
		[cameraButton setImage:image forState:UIControlStateHighlighted];
		[cameraButton setImage:image forState:UIControlStateDisabled];
		//[pictureImageViews addObject:newView];
		//snapPictureDescriptionLabel.text = @"Preparing...";
		
		// we schedule this call in run loop because we want to dismiss the modal view first
		//[self performSelector:@selector(_startUpload:) withObject:image afterDelay:0.0];
}
	

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
