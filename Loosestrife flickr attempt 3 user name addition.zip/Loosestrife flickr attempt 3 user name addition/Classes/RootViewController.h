//
//  RootViewController.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "LoosestrifeAppDelegate.h"
#import "AvgHeight.h"

@class LoosestrifeAppDelegate;
@class UserSelectTable;

//@interface RootViewController : UITableViewController <NSFetchedResultsControllerDelegate> {

@interface RootViewController : UIViewController <OFFlickrAPIRequestDelegate>{ 

//@private
  //  NSFetchedResultsController *fetchedResultsController_;
  //  NSManagedObjectContext *managedObjectContext_;
	UIButton *beginButton;
	UIButton *submitAllButton; 
	AvgHeight *avgHeight; 
	LoosestrifeAppDelegate *app_delegate;
	NSMutableData *receivedInfoData;
	
	OFFlickrAPIRequest *flickrRequest;
}

//@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
//@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) IBOutlet UIButton *beginButton; 
@property (nonatomic, retain) IBOutlet UIButton *submitAllButton; 
@property (nonatomic, retain) AvgHeight *avgHeight; 
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate; 
@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;
@property (nonatomic, retain) NSMutableData *receivedInfoData;

-(IBAction) beginButtonPressed: (id) sender ;
-(IBAction) submitAllButtonPressed: (id) sender;
-(BOOL) connectedToNetwork;
- (IBAction)authorizeAction;
-(IBAction) dataTestButtonPressed: (id) sender;
- (void)_startUpload:(NSArray *)image;
-(void) selectedUserName;

@end
