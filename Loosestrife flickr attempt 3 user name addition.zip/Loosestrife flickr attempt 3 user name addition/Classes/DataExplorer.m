//
//  DataExplorer.m
//  Loosestrife
//
//  Created by HCI Lab on 9/5/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "DataExplorer.h"
#import "LoosestrifeAppDelegate.h"
#import "SimpleDataViewer.h"

@implementation DataExplorer
@synthesize app_delegate, picsArray, currentPlant, flickrContext, flickrRequest, picsView, loadingLabel;

//NSString *kStoredAuthTokenKeyName = @"FlickrAuthToken";

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = [[UIApplication sharedApplication] delegate];
	
	if (!flickrContext) {
        flickrContext = [[OFFlickrAPIContext alloc] initWithAPIKey:@"0bd9015e52e52197849db03aadd270ef" sharedSecret:@"484dcfc7bb8ea324"];
        
        NSString *authToken;
        if (authToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"FlickrAuthToken"]) {
            flickrContext.authToken = authToken;
        }
    }
	
	if (!flickrRequest) {
		flickrRequest = [[OFFlickrAPIRequest alloc] initWithAPIContext:self.flickrContext];
		flickrRequest.delegate = self;		
	}
	
	
	self.title = currentPlant;
	[self loadPics];
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

-(void) loadPics {
	[flickrRequest callAPIMethodWithGET:@"flickr.photos.search" arguments:[NSDictionary dictionaryWithObjectsAndKeys: currentPlant, @"tags", @"wellesleyhcilab1", @"user", nil]];
	NSLog(@"well, it thinks it's finding pictures.");
}

- (void)flickrAPIRequest:(OFFlickrAPIRequest *)inRequest didCompleteWithResponse:(NSDictionary *)inResponseDictionary
{
	NSLog(@"Hi!");
	NSMutableArray *alreadySeenDates = [[NSMutableArray alloc] init];
	for (int i = 0; i<[[inResponseDictionary valueForKeyPath:@"photos.photo"] count]; i++) {
		NSDictionary *photoDict = [[inResponseDictionary valueForKeyPath:@"photos.photo"] objectAtIndex:i];
		
		NSString *title = [photoDict objectForKey:@"title"];
		if (![title length]) {
			title = @"No title";
		}
		
		//NSURL *photoSourcePage = [flickrContext photoWebPageURLFromDictionary:photoDict];
		//NSDictionary *linkAttr = [NSDictionary dictionaryWithObjectsAndKeys:photoSourcePage, NSLinkAttributeName, nil];
		//NSMutableAttributedString *attrString = [[[NSMutableAttributedString alloc] initWithString:title attributes:linkAttr] autorelease];	
		//[[textView textStorage] setAttributedString:attrString];
		
		NSURL *photoURL = [flickrContext photoSourceURLFromDictionary:photoDict size:OFFlickrSmallSize];
		/*NSString *htmlSource = [NSString stringWithFormat:
		 @"<html>"
		 @"<head>"
		 @"  <style>body { margin: 0; padding: 0; } </style>"
		 @"</head>"
		 @"<body>"
		 @"  <table border=\"0\" align=\"center\" valign=\"center\" cellspacing=\"0\" cellpadding=\"0\" height=\"240\">"
		 @"    <tr><td><img src=\"%@\" /></td></tr>"
		 @"  </table>"
		 @"</body>"
		 @"</html>"
		 , photoURL];*/
		NSLog(@"URL is %@", [photoURL absoluteURL]);
		UIImage *image = [UIImage imageWithData: [NSData dataWithContentsOfURL:photoURL]];
		UIButton *imageButton = [[UIButton alloc] initWithFrame:CGRectMake(200*i, 0, 200, 250)];
		[imageButton setImage:image forState: UIControlStateNormal];
		[imageButton setImage:image forState:UIControlStateHighlighted];
		[imageButton setImage:image forState:UIControlStateSelected];
		
		[imageButton addTarget:self action:@selector(plantButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[picsView addSubview:imageButton];
		[picsView setContentSize:CGSizeMake(200*i+200, 256)];
	}
    [loadingLabel setHidden:YES];
	
}

-(IBAction) plantButtonPressed: (id) sender {
	NSLog(@"pushed the button");
	SimpleDataViewer *viewer = [[SimpleDataViewer alloc] initWithNibName:@"SimpleDataViewer" bundle:nil];
	viewer.leftImage = ((UIButton *)sender).imageView.image;
	viewer.data = [NSString stringWithFormat:@"%@",[app_delegate.currentFetchedData objectAtIndex:0]];
	[self.navigationController pushViewController:viewer animated:YES];
	
}
- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
