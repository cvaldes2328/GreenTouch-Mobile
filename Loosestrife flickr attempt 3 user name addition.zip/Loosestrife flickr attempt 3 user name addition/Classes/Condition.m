//
//  Condition.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "Condition.h"
#import "PlantPhoto.h"

@implementation Condition

@synthesize picker, text,array, app_delegate, photo, infoView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	app_delegate = (LoosestrifeAppDelegate *)[[UIApplication sharedApplication] delegate];
	[self setTitle:@"Damage"];
	array = [[NSArray alloc] initWithObjects:@" no damage", @"<10%", @"10-25%", @"25-40%", @"40-60%", @">60%", nil];
	[text setFont:[UIFont fontWithName:@"Helvetica" size:24.0]];
	photo = [[PlantPhoto alloc] init];
	photo.directions = @"Take a picture of the entire leaf.  Remember to be consistent.";
	photo.nextVC = 1;
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}

-(IBAction) nextButtonPressed: (id) sender {
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Next button pressed in Condition", today]; 
	[app_delegate updateLog:logEntry];
	
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:[picker selectedRowInComponent:0]] forKey:@"leafDamage"];
	[app_delegate.navigationController pushViewController:photo animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in condition", today]; 
		[app_delegate updateLog:logEntry];
	}
}

-(IBAction) showInfoPressed: (id)sender{
	
	infoView.hidden = NO;
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Looked at Condition reference", today]; 
	[app_delegate updateLog:logEntry];
}

-(IBAction) hideInfoPressed: (id)sender{
	infoView.hidden = YES;
	
	NSDate *today;
	today = [NSDate date];
	NSString *logEntry = [NSString stringWithFormat:@"%@ - Closed condition reference", today]; 
	[app_delegate updateLog:logEntry];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
