//
//  SimpleDataViewer.h
//  Loosestrife
//
//  Created by HCI Lab on 9/5/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LoosestrifeAppDelegate;
@interface SimpleDataViewer : UIViewController {

	LoosestrifeAppDelegate *app_delegate;
	NSString *data;
	UITextView *dataViewer;
	UIImageView *leftImageView;
	UIImageView *rightImageView;
	UIImage *leftImage;
	UIImage *rightImage;
}
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) NSString *data;
@property (nonatomic, retain) IBOutlet UITextView *dataViewer;
@property (nonatomic, retain) IBOutlet UIImageView *leftImageView;
@property (nonatomic, retain) IBOutlet UIImageView *rightImageView;
@property (nonatomic, retain) UIImage *leftImage;
@property (nonatomic, retain) UIImage *rightImage;

@end
