//
//  DataExplorer.h
//  Loosestrife
//
//  Created by HCI Lab on 9/5/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ObjectiveFlickr.h"

@class LoosestrifeAppDelegate ;

@interface DataExplorer : UIViewController <OFFlickrAPIRequestDelegate>{
	LoosestrifeAppDelegate *app_delegate;
	NSArray *picsArray;
	NSString *currentPlant;
	UIScrollView *picsView;
	UILabel *loadingLabel;
	
	OFFlickrAPIContext *flickrContext;
	OFFlickrAPIRequest *flickrRequest;
}
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) NSArray *picsArray;
@property (nonatomic, retain) NSString *currentPlant;
@property (nonatomic, retain) IBOutlet UIScrollView *picsView;
@property (nonatomic, retain) IBOutlet UILabel *loadingLabel;

@property (nonatomic, retain) OFFlickrAPIContext *flickrContext;
@property (nonatomic, retain) OFFlickrAPIRequest *flickrRequest;

-(void) loadPics;

@end
