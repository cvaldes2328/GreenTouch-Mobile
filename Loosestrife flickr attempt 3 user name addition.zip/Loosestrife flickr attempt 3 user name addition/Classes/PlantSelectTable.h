//
//  PlantSelectTable.h
//  Loosestrife
//
//  Created by HCI Lab on 9/5/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoosestrifeAppDelegate;

@interface PlantSelectTable : UITableViewController {
	LoosestrifeAppDelegate *app_delegate;
	NSArray *plants;
	
}

@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) NSArray *plants;

@end
