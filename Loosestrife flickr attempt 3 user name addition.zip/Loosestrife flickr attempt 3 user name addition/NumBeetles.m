//
//  NumBeetles.m
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import "NumBeetles.h"


@implementation NumBeetles

@synthesize array, app_delegate, picker, segControl, text, photo; 

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

- (void)viewWillDisappear:(BOOL)animated {
	NSArray *viewControllers = self.navigationController.viewControllers;
	if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
		// View is disappearing because a new view controller was pushed onto the stack
		NSLog(@"New view controller was pushed");
	} else if ([viewControllers indexOfObject:self] == NSNotFound) {
		// View is disappearing because it was popped from the stack
		NSLog(@"View controller was popped");
		
		NSDate *today;
		today = [NSDate date];
		NSString *logEntry = [NSString stringWithFormat:@"%@ - Went back in num beetles", today]; 
		[app_delegate updateLog:logEntry];
	}
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	app_delegate = (LoosestrifeAppDelegate *) [[UIApplication sharedApplication] delegate]; 
	
	photo = [[PlantPhoto alloc] init];
	photo.directions=@"Take a picture of a beetle (if applicable). Remember to be consistent. "; 
	photo.nextVC = 2;
	array = [[NSArray alloc] initWithObjects:@"0", @"1", @"2-4", @"5+", nil]; 
	[text setFont:[UIFont fontWithName:@"Helvetica" size:20.0]];

	self.title = @"Beetles"; 
	
    [super viewDidLoad];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [array count];  
}
- (NSString *)pickerView:(UIPickerView *)pickerView	titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [array objectAtIndex: row]; 
}

-(IBAction) nextButtonPressed: (id) sender {
	[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:[picker selectedRowInComponent:0]] forKey:@"numBeetles"];
	if ([segControl selectedSegmentIndex]==0) {
		[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:1] forKey:@"othersAreEquallyAffected"];
	} else {
		[app_delegate.currentDataEntry setObject:[NSNumber numberWithInt:0] forKey:@"othersAreEquallyAffected"];
	}

	
	
	[app_delegate.navigationController pushViewController:photo animated:YES]; 
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
