//
//  NumBeetles.h
//  Loosestrife
//
//  Created by HCI Lab on 6/13/11.
//  Copyright 2011 Wellesley College. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoosestrifeAppDelegate.h"
#import "PlantPhoto.h"




@interface NumBeetles : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {

	PlantPhoto *photo;
	LoosestrifeAppDelegate *app_delegate;
	NSArray *array; 
	UIPickerView *picker;
	UITextView	 *text; 
	UISegmentedControl *segControl; 
	
}
@property (nonatomic, retain) LoosestrifeAppDelegate *app_delegate;
@property (nonatomic, retain) PlantPhoto *photo;
@property (nonatomic, retain) NSArray *array; 
@property (nonatomic, retain) IBOutlet UIPickerView *picker; 
@property (nonatomic, retain) IBOutlet UITextView *text; 
@property (nonatomic, retain) IBOutlet UISegmentedControl *segControl; 

-(IBAction) nextButtonPressed: (id) sender;

@end
